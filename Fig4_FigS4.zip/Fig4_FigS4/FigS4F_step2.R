# DUX
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXKORNAseqData/hisat2file/Duxf3_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXKORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]


WTLevel <- as.numeric(rowMeans(expSignal[,c(5,6,7)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(8,9,10)]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
matchIndexes <- which(WTLevel > 0)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))
colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXKORNAseqData/hisat2file/Duxf3_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# DUX
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/Duxf3_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]


WTLevel <- as.numeric(rowMeans(expSignal[,c(3,4,7,8,11,12)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(1,2,5,6,9,10)]))
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","OE"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))
colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","OE"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/Duxf3_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# ZSCAN4
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/ZSCAN4_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(1,2)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(3,4)]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
matchIndexes <- which(WTLevel > 0)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- c(rep(c("WT","KO"),each=length(WTLevel)))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/ZSCAN4_se_expression_KO.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/ZSCAN4_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(5,6)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(7,8)]))
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- c(rep(c("WT","OE"),each=length(WTLevel)))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","OE"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/ZSCAN4KORNAseqData/hisat2file/ZSCAN4_se_expression_OE.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# NANOG
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/NANOGKORNAseqData/hisat2file/Nanog_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/NANOGKORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(2,4,5,6,7,8,9,10,11,12,14,16,21,25,26,27,28,33,34,35,36)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(1,3,13,15,17,18,19,20,22,23,24,29,30,31,32)]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
rownames(expSignal) <- enhIDs
matchIndexes <- which(WTLevel > 0)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
CLevel <- CLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/NANOGKORNAseqData/hisat2file/NANOG_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.1) + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# POU5F1
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/POU5F1KORNAseqData/hisat2file/POU5F1_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/POU5F1KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(seq(1,9),seq(15,21),seq(32,51),seq(62,67))]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(seq(10,14),seq(22,31),seq(52,61),seq(68,71))]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
rownames(expSignal) <- enhIDs
matchIndexes <- which(WTLevel > 0)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
CLevel <- CLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/POU5F1KORNAseqData/hisat2file/POU5F1_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.2) + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# SOX2
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SOX2KORNAseqData/hisat2file/SOX2_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SOX2KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(seq(1,2),seq(7,8),seq(13,14),seq(19,20),seq(25,26),seq(31,32),seq(37,38),seq(43,44),seq(49,50),seq(55,56),seq(61,62),seq(67,68))]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(seq(3,6),seq(9,12),seq(15,18),seq(21,24),seq(27,30),seq(33,36),seq(39,42),seq(45,48),seq(51,54),seq(57,60),seq(63,66),seq(69,72))]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
rownames(expSignal) <- enhIDs
matchIndexes <- which(WTLevel > 0)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
CLevel <- CLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/SOX2KORNAseqData/hisat2file/SOX2_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.1) + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# KLF2
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KORNAseqData/hisat2file/KLF2_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(1,2)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(3,4)]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
rownames(expSignal) <- enhIDs
matchIndexes <- which(WTLevel > 0.1)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
CLevel <- CLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KORNAseqData/hisat2file/KLF2_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.5) + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# KLF2
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KDRNAseqData/hisat2file/KLF2_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KDRNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(1,2)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(3,4)]))
matchIndexes <- which(WTLevel > 0.1)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KD"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KD"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/KLF2KDRNAseqData/hisat2file/KLF2_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

# FOXD3
enhIDs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/FOXD3KORNAseqData/hisat2file/FOXD3_ses.txt",header=FALSE,stringsAsFactors=FALSE)[,1]
signalData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/FOXD3KORNAseqData/hisat2file/se_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(signalData))
stageNames <- unique(gsub("\\.\\d+","",stageNames))

expSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(signalData))
	if(length(expSignal)==0){
		expSignal <- rowMeans(signalData[,matchIndexes],na.rm=TRUE)
	}else{
		expSignal <- cbind(expSignal,rowMeans(signalData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(expSignal) <- stageNames

enhData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(enhIDs,enhData[,4])
expSignal <- expSignal[matchIndexes,]

WTLevel <- as.numeric(rowMeans(expSignal[,c(1,2)]))
KOLevel <- as.numeric(rowMeans(expSignal[,c(3,4)]))
CLevel <- WTLevel/(KOLevel+0.1)
names(CLevel) <- enhIDs
rownames(expSignal) <- enhIDs
matchIndexes <- which(WTLevel > 0.1)
WTLevel <- WTLevel[matchIndexes]
KOLevel <- KOLevel[matchIndexes]
CLevel <- CLevel[matchIndexes]
res <- wilcox.test(WTLevel,KOLevel,paired=TRUE)
cat(res$p.value,"\n")

exprlevel <- c(WTLevel,KOLevel)
celltype <- rep(c("WT","KO"),each=length(WTLevel))
df <- as.data.frame(cbind(exprlevel,celltype))

colnames(df) <- c("exprlevel","celltype")
df$celltype <- factor(celltype,levels=c("WT","KO"))
df$exprlevel <- as.numeric(exprlevel)

library(ggplot2)
library(ggbeeswarm)

pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/FOXD3KORNAseqData/hisat2file/FOXD3_se_expression.pdf",width=3,height=4)
p <- ggplot(data=df, aes(x=celltype,y=exprlevel)) + geom_quasirandom(aes(color=celltype),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", "#EA1BE5")) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.9) + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()