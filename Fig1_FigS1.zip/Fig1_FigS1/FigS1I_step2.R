library(Rtsne)
expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/enhancer_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(expData) <- expData[,1]
sampInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/run2samplename.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
sampInfo[,3] <- factor(sampInfo[,3],levels=c("MII_oocyte_rep1","MII_oocyte_rep2","zygote_rep1","zygote_rep2","early_2-cell_rep1","early_2-cell_rep2","2-cell_rep1","2-cell_rep2","4-cell_rep1","4-cell_rep2","8-cell_rep1","8-cell_rep2","ICM_rep1","ICM_rep2","ICM_rep5"),ordered=TRUE)
sampInfo <- sampInfo[order(sampInfo[,3]),]
matchIndexes <- match(sampInfo[,1],colnames(expData))
expData <- expData[,matchIndexes]
colnames(expData) <- as.character(sampInfo[,3])
expData <- expData[which(rowSums(expData) > 0),]


set.seed(42) # Sets seed for reproducibility
tsne_out <- Rtsne(as.matrix(t(expData)),perplexity=1.5,dims=3) # Run TSNE

library(ggplot2)
library(wesanderson)
stageNames <- rep(c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM"),c(2,2,2,2,2,2,3))
plotdata <- data.frame(x=tsne_out$Y[,1],y=tsne_out$Y[,2],pointColor=stageNames,pointType=rep(seq(14,20,1),c(2,2,2,2,2,2,3)))
pdf("/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/sample_similarity_based_on_enhancer_tSNE.pdf",width=6,height=5)
p <- ggplot(plotdata,aes(x=x,y=y,label=colnames(expData),colour=factor(pointColor,levels=c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")),shape=factor(pointColor,levels=c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")))) + geom_point(size=3) + scale_shape_manual(values=c(1,2,3,4,5,6,7)) + scale_color_manual(values = c(rev(wes_palette("Zissou1",6,type = "continuous")),"darkslateblue"))
p <- p + xlab("PC1") + ylab("PC2") + geom_text(hjust=0.5,vjust=1,size=2.5)
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()
