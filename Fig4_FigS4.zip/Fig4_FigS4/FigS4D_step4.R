library(ggplot2)
library(RColorBrewer)

BRD4Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
BRD4Data <- BRD4Data[,3:ncol(BRD4Data)]
BRD4SEData <- as.numeric(BRD4Data[1,])
BRD4TEData <- as.numeric(BRD4Data[2,])

yvalues <- as.numeric(c(BRD4SEData,BRD4TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

q4 = brewer.pal(4,'Set1')
pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/BRD4_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

CBPData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
CBPData <- CBPData[,3:ncol(CBPData)]
CBPSEData <- as.numeric(CBPData[5,])
CBPTEData <- as.numeric(CBPData[6,])

yvalues <- as.numeric(c(CBPSEData,CBPTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/CBP_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

MED1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
MED1Data <- MED1Data[,3:ncol(MED1Data)]
MED1SEData <- as.numeric(MED1Data[21,])
MED1TEData <- as.numeric(MED1Data[22,])

yvalues <- as.numeric(c(MED1SEData,MED1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/MED1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()
