#!/usr/bin/perl -w
# before running this script, sorting the bedgraph by "sort -k1,1 -k2,2n $bedgraphfile > $sortedbedgraphfile" and "cat $sortedbedfile | grep "chr" > $chrsortedbedfile"

use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$chrominfo,$help);

GetOptions(
    "inputdir=s" => \$inputdir,
    "chrominfo=s" => \$chrominfo,
	"help!" => \$help,
);
my @bedgraphfiles = `find $inputdir -name "*chr.sorted.bedGraph"`;

foreach my $bedgraphfile (@bedgraphfiles){
    chomp $bedgraphfile;
    my $bwfile = $bedgraphfile;
    $bwfile =~ s/bedGraph/bw/;
    system("/media/yuhua/yuhua_projects/software/bedGraphToBigWig $bedgraphfile $chrominfo $bwfile")==0 or die "$!\n";
}

# perl fig1f_step2_dnameth_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR --chrominfo /media/yuhua/yuhua_projects/enhProj/annodata/mm10.chrom.sizes
