#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$indexdir,$bowtie2dir,$picarddir,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
    "indexdir=s" => \$indexdir,
	"bowtie2dir=s" => \$bowtie2dir,
	"picarddir=s" => \$picarddir,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*sra"`;
print join("\n",@samples)."\n";
foreach my $sample (@samples){
	chomp $sample;
	$sample =~ /.*\/(.*)\.sra/;
	my $sample_id = $1;
    
	if(!-e "$outputdir/$bowtie2dir/$sample_id"){
		mkpath("$outputdir/$bowtie2dir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$bowtie2dir/$sample_id failed:\n$@";
			exit(1);
		}
	}
    
	open(SH,">$outputdir/$bowtie2dir/$sample_id/${sample_id}_mapping.sh") or die "$!\n";
	if(!-e "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "fastq-dump --split-files $sample -O $inputdir/$sample_id\n";
	}
	if(!-e "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.bam" || -z "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.bam"){
		print SH "bowtie2 -x $indexdir -p $threads -t -q -N 1 -L 25 --rg-id $sample_id --rg SM:$sample_id -1 $inputdir/$sample_id/$sample_id\_1.fastq -2 $inputdir/$sample_id/$sample_id\_2.fastq -S $outputdir/$bowtie2dir/$sample_id/accepted_hits.sam\n";
		print SH "samtools view -bS $outputdir/$bowtie2dir/$sample_id/accepted_hits.sam -o $outputdir/$bowtie2dir/$sample_id/accepted_hits.bam\n";
		print SH "samtools sort $outputdir/$bowtie2dir/$sample_id/accepted_hits.bam -o $outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.bam\n";
	}
    
	if(!-e "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam"){
        print SH "java -Xmx15g -jar $picarddir/picard.jar MarkDuplicates I=$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.bam O=$outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam METRICS_FILE=$outputdir/$bowtie2dir/$sample_id/${sample_id}.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n";
        print SH "samtools index $outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
        print SH "rm $outputdir/$bowtie2dir/$sample_id/accepted_hits.sam\n";
		print SH "rm $outputdir/$bowtie2dir/$sample_id/accepted_hits.bam\n";
		print SH "rm $outputdir/$bowtie2dir/$sample_id/accepted_hits.bam.bai\n";
        print SH "rm $outputdir/$bowtie2dir/$sample_id/accepted_hits.sorted.bam\n";
		print SH "rm $inputdir/$sample_id/*fastq\n";
    }   
	close SH;
	
	open OUT,">$outputdir/$bowtie2dir/$sample_id/submit_${sample_id}_mapping.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $sample_id			
#SBATCH -c 4
#SBATCH --mem 100G
#SBATCH -o $outputdir/$bowtie2dir/$sample_id/%j.log
#SBATCH -e $outputdir/$bowtie2dir/$sample_id/%j.err

date
source ~/.bashrc
module load bowtie/2.4.2
module load samtools/1.14
sh $outputdir/$bowtie2dir/$sample_id/${sample_id}_mapping.sh
date
EOF
	close OUT;
	my $sb = `sbatch $outputdir/$bowtie2dir/$sample_id/submit_${sample_id}_mapping.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}