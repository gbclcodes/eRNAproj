# XW
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)

tf.genes <- read.table(file="/media/yuhua/yuhua_projects/enhProj/annodata/AnimalTFDB_mus_musculus_TF.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
tf.genes <- tf.genes[which(tf.genes[,4]=="Homeobox"),]
matchindexes <- match(tf.enh.pairs[,2],tf.genes[,3])
tf.enh.pairs <- tf.enh.pairs[which(!is.na(matchindexes)),]

stageNames <- unique(all.enhancers[,3])
stageNames <- stageNames[1:5]
TFNums <- c()
enhNums <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	enhNums <- c(enhNums,length(unique(tf.enh.pairs[which(!is.na(matchIndexes)),1])))
	TFNums <- c(TFNums,length(unique(tf.enh.pairs[which(!is.na(matchIndexes)),2])))
}

num <- c(TFNums,enhNums)
celltype <- rep(c("MIIOocyte","Zygote","E2C","L2C","M4C"),2)
genetype <- rep(c("G","E"),each=5)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("MIIOocyte","Zygote","E2C","L2C","M4C"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/Homeobox_num_developmental_stage_group_barplot_XW.pdf",width=5,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge()) + scale_fill_manual(values = q4[c(1,2)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()