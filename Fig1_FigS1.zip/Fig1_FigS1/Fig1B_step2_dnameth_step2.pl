#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$chrominfo,$help);

GetOptions(
    "inputdir=s" => \$inputdir,
    "chrominfo=s" => \$chrominfo,
	"help!" => \$help,
);
my @bedgraphfiles = `find $inputdir -name "*chr.sorted.bedGraph"`;

foreach my $bedgraphfile (@bedgraphfiles){
    chomp $bedgraphfile;
    my $bwfile = $bedgraphfile;
    $bwfile =~ s/bedGraph/bw/;
    system("/media/yuhua/yuhua_projects/software/bedGraphToBigWig $bedgraphfile $chrominfo $bwfile")==0 or die "$!\n";
}

# perl trans_bedgraph_to_bw.pl --inputdir /media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR --chrominfo /media/yuhua/yuhua_projects/enhProj/annodata/mm10.chrom.sizes
