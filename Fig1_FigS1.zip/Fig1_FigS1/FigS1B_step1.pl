#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($bedfile,$chromlenfile,$tssfile,$help);
GetOptions(
	"bedfile=s" => \$bedfile,
    "chromlenfile=s" => \$chromlenfile,
    "tssfile=s" => \$tssfile,
	"help!" => \$help,
);

my %chromlen;
open(CL,"<$chromlenfile") or die "$!\n";
while(<CL>){
    my $line = $_;
    chomp $line;
    my @fieldValues = split /\t/,$line;
    $chromlen{$fieldValues[0]} = $fieldValues[1];
}
close CL;

my %enhancerHash;
open(BED,"<$bedfile") or die "$!\n";
while(<BED>){
    my $line = $_;
    chomp $line;
    my @fieldValues = split /\t/,$line;
    $enhancerHash{"$fieldValues[0]--$fieldValues[1]--$fieldValues[2]"} = 1;
}
close BED;

open(TSS,">$tssfile") or die "$!\n";

foreach my $tss (keys %enhancerHash){
    my ($chr,$start,$end) = split /--/,$tss;
    if(($start - 1000) > 0 && ($chromlen{$chr} - $end) >= 1000){
        for(my $upiterer = 1; $upiterer <= 20; $upiterer = $upiterer + 1){
            my $a = $start - 1000 + 50*($upiterer-1);
            my $b = $start - 1000 + 50*$upiterer;
            print TSS "$chr\t$a\t$b\t$tss"."up$upiterer\n";
        }
        print TSS "$chr\t$start\t$end\t$tss\n";
        for(my $downiterer = 1; $downiterer <= 20; $downiterer = $downiterer + 1){
            my $a = $end + 50*($downiterer-1);
            my $b = $end + 50*$downiterer;
            print TSS "$chr\t$a\t$b\t$tss"."down$downiterer\n";
        }
    }
}
close BED;

# perl construct_twogroups_enhancer_tss_bedfile.pl --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific.bed --chromlen /media/yuhua/yuhua_projects/enhProj/annodata/mm10.chrom.sizes --tssfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed 

# perl construct_twogroups_enhancer_tss_bedfile.pl --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown.bed --chromlen /media/yuhua/yuhua_projects/enhProj/annodata/mm10.chrom.sizes --tssfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed