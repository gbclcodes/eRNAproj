library(clusterProfiler)
library(org.Mm.eg.db)
library(enrichplot)

XWNetData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_all.txt",stringsAsFactors=FALSE,header=FALSE)
targetIDs <- XWNetData[which(XWNetData[,1]=="SpEnh0335"),2]
target_gmt <- cbind(rep("TSET",length(targetIDs)),targetIDs)

resdata <- read.csv("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/siENH_vs_siNC_2C.csv",header=TRUE,row.names=1,stringsAsFactors=FALSE)
maxVec <- apply(resdata[,seq(8,11)],1,max)
resdata <- resdata[which(maxVec > 0),]

resdata <- resdata[order(resdata$stat,decreasing=TRUE),]
genenames <- gsub("\\.\\d+","",as.character(rownames(resdata)))
genelist <- resdata$stat
names(genelist) <- genenames
gsea <- GSEA(genelist, TERM2GENE = target_gmt, pvalueCutoff = 1)

pdf("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/Targets_GSEA_2C.pdf")
gseaplot2(gsea,1,title = "Targets", color="red", base_size = 20, subplots = 1:2)
dev.off()

zga_gmt <- read.gmt("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtie/ZGAgenes.gmt")
zga_gmt <- zga_gmt[sample(nrow(zga_gmt),500),]
resdata <- read.csv("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/siENH_vs_siNC_2C.csv",header=TRUE,row.names=1,stringsAsFactors=FALSE)
maxVec <- apply(resdata[,seq(8,11)],1,max)
resdata <- resdata[which(maxVec > 0),]

resdata <- resdata[order(resdata$stat,decreasing=TRUE),]
genenames <- resdata[,1]
genelist <- resdata$stat
names(genelist) <- genenames
gsea <- GSEA(genelist, TERM2GENE = zga_gmt, pvalueCutoff = 1,maxGSSize = 20000)

pdf("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/ZGA_GSEA_2C.pdf")
gseaplot2(gsea,1,title = "ZGA", color="red", base_size = 20, subplots = 1:2)
dev.off()