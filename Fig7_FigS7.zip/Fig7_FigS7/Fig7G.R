library(ggpubr)

expData <- read.csv(file = "/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/siENH_vs_siNC_2C.csv", header = T, row.names = 1)
rownames(expData) <- gsub("\\.\\d+","",rownames(expData))

geneIDs <- read.table(file = "/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/PTHR31647.txt",sep = "\t", header=FALSE)
matchIndexes <- match(geneIDs[,1],rownames(expData))
expData <- t(apply(expData[matchIndexes,c(8,9,10,11)],1,scale))

library(RColorBrewer)
q4 = brewer.pal(4,'Set1')

d <- data.frame(Control = rowMeans(expData[,c(1,2)]), siMZGAe1 = rowMeans(expData[,c(3,4)]))
pdf("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/PTHR31647.pdf",width=4,height=7)
ggpaired(d, cond1 = "Control", cond2 = "siMZGAe1",point.size=4,fill = "condition", palette = c(q4[1], q4[2]))
dev.off()