#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$htseqdir,$gfffile,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"htseqdir=s" => \$htseqdir,
	"gfffile|gff=s" => \$gfffile,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*.bam"`;
print join("\n",@samples)."\n";
foreach my $sample (@samples){
	chomp $sample;
	$sample =~ /.*\/(.*).sorted.unique.bam/;
	my $sample_id = $1;
    
	if(!-e "$outputdir/$htseqdir/$sample_id"){
		mkpath("$outputdir/$htseqdir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$htseqdir/$sample_id failed:\n";
			exit(1);
		}
	}
    
	open(SH,">$outputdir/$htseqdir/$sample_id/${sample_id}_expcal.sh") or die "$!\n";
    if(!-e "$outputdir/$htseqdir/$sample_id/htseq_count.txt" || -z "$outputdir/$htseqdir/$sample_id/htseq_count.txt"){
		print SH "htseq-count -f bam -r pos -s no -i Name -t BED_feature --nonunique all -q $sample $gfffile > $outputdir/$htseqdir/$sample_id/htseq_count.txt\n";
	}
	close SH;
    
    open OUT,">$outputdir/$htseqdir/$sample_id/submit_${sample_id}_expcal.sh";
    print OUT <<EOF;
#!/bin/bash
#SBATCH -p intel-debug
#SBATCH -q debug
#SBATCH -J $sample_id
#SBATCH -c 1
#SBATCH --mem 10G
#SBATCH -o $outputdir/$htseqdir/$sample_id/htseqcount.log
#SBATCH -e $outputdir/$htseqdir/$sample_id/htseqcount.err

date
source ~/.bashrc
module load samtools/1.14
sh $outputdir/$htseqdir/$sample_id/${sample_id}_expcal.sh
date
EOF
	close OUT;
	
	my $sb = `sbatch $outputdir/$htseqdir/$sample_id/submit_${sample_id}_expcal.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl step5_HTSeq_H3K9me3.pl --inputdir /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/result --outputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27acPWK --htseqdir htseqcountfile --gfffile /storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/SuperE3.bed --threads 2 
