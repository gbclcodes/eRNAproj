library(reshape2)
library(ggplot2)
library(RColorBrewer)
q1 = brewer.pal(3,'Set1')
library(wesanderson)

df_ctrl <- read.table(file="/media/yuhua/yuhua_projects/enhProj/phenodata/new/ctrl.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EmbryoNumVec <- rowSums(df_ctrl)
for (i in seq(1,length(EmbryoNumVec))){
	df_ctrl[i,] <- df_ctrl[i,]/EmbryoNumVec[i]
}

plotData <- data.frame(rows=factor(rownames(df_ctrl)[row(df_ctrl)],levels=c("1.5dpc","2.5dpc","3.5dpc","4.5dpc","5.5dpc")), vars=factor(colnames(df_ctrl)[col(df_ctrl)],levels=c("Fragmented","X2C","X3_4C","X5_6C","X7_8C","m","BC")),values=c(as.matrix(df_ctrl)))

stck <- ggplot(plotData,aes(x= rows, y=values, fill=vars)) + geom_bar(stat="identity", width=.7) + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
stck <- stck + scale_fill_manual(values=c(q1[c(2,1)],rev(wes_palette("Zissou1",8,type = "continuous"))[c(2,3,4,5,6)]))
ggsave("/media/yuhua/yuhua_projects/enhProj/phenodata/new/crtl.pdf")

df_siEH10 <- read.table(file="/media/yuhua/yuhua_projects/enhProj/phenodata/new/siEH10.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EmbryoNumVec <- rowSums(df_siEH10)
for (i in seq(1,length(EmbryoNumVec))){
	df_siEH10[i,] <- df_siEH10[i,]/EmbryoNumVec[i]
}

plotData <- data.frame(rows=factor(rownames(df_siEH10)[row(df_siEH10)],levels=c("1.5dpc","2.5dpc","3.5dpc","4.5dpc","5.5dpc")), vars=factor(colnames(df_siEH10)[col(df_siEH10)],levels=c("Fragmented","X2C","X3_4C","X5_6C","X7_8C","m","BC")),values=c(as.matrix(df_siEH10)))

stck <- ggplot(plotData,aes(x= rows, y=values, fill=vars)) + geom_bar(stat="identity", width=.7) + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
stck <- stck + scale_fill_manual(values=c(q1[c(2,1)],rev(wes_palette("Zissou1",8,type = "continuous"))[c(2,3,4,5,6)]))
ggsave("/media/yuhua/yuhua_projects/enhProj/phenodata/new/siEH10.pdf")

df_siEH362 <- read.table(file="/media/yuhua/yuhua_projects/enhProj/phenodata/new/siEH362.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EmbryoNumVec <- rowSums(df_siEH362)
for (i in seq(1,length(EmbryoNumVec))){
	df_siEH362[i,] <- df_siEH362[i,]/EmbryoNumVec[i]
}

plotData <- data.frame(rows=factor(rownames(df_siEH362)[row(df_siEH362)],levels=c("1.5dpc","2.5dpc","3.5dpc","4.5dpc","5.5dpc")), vars=factor(colnames(df_siEH362)[col(df_siEH362)],levels=c("Fragmented","X2C","X3_4C","X5_6C","X7_8C","m","BC")),values=c(as.matrix(df_siEH362)))

stck <- ggplot(plotData,aes(x= rows, y=values, fill=vars)) + geom_bar(stat="identity", width=.7) + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
stck <- stck + scale_fill_manual(values=c(q1[c(2,1)],rev(wes_palette("Zissou1",8,type = "continuous"))[c(2,3,4,5,6)]))
ggsave("/media/yuhua/yuhua_projects/enhProj/phenodata/new/siEH362.pdf")
