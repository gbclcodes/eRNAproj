#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J MD
#SBATCH -c 1
#SBATCH --mem 50G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/MD.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/MD.err

cd /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD
module load samtools/1.14

samtools sort /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR3336430/SRR3336430_mapping.genome1.bam -o SRR3336430.genome1.sorted.bam
samtools index SRR3336430.genome1.sorted.bam
java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=SRR3336430.genome1.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/result/SRR3336430.genome1.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/metrics/SRR3336430.genome1.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate

samtools sort /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR3336430/SRR3336430_mapping.genome2.bam -o SRR3336430.genome2.sorted.bam
samtools index SRR3336430.genome2.sorted.bam
java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=SRR3336430.genome2.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/result/SRR3336430.genome2.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/metrics/SRR3336430.genome2.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate

samtools sort /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR5049346/SRR5049346_mapping.genome1.bam -o SRR5049346.genome1.sorted.bam
samtools index SRR5049346.genome1.sorted.bam
java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=SRR5049346.genome1.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/result/SRR5049346.genome1.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/metrics/SRR5049346.genome1.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate

samtools sort /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR5049346/SRR5049346_mapping.genome2.bam -o SRR5049346.genome2.sorted.bam
samtools index SRR5049346.genome2.sorted.bam
java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=SRR5049346.genome2.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/result/SRR5049346.genome2.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_MD/metrics/SRR5049346.genome2.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate
