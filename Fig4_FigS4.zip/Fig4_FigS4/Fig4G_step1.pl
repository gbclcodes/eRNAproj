#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Path;

my ($enhtarfile,$devgenefile,$outfile,$outfile2,$help);
GetOptions(
	"enhtarfile=s" => \$enhtarfile,
	"devgenefile=s" => \$devgenefile,
	"outfile=s" => \$outfile,
	"outfile2=s" => \$outfile2,
	"help!" => \$help,
);

my (%devHash);
open(DEV,"<$devgenefile") or die "$!\n";
while(<DEV>){
	my $line = $_;
	chomp $line;
	$devHash{$line} = 1;
	
}
close DEV;

open(ET,"<$enhtarfile") or die "$!\n";
open(OUT,">$outfile") or die "$!\n";
open(OUT2,">$outfile2") or die "$!\n";
while(<ET>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\s+/,$line;
	if(exists $devHash{$fieldValues[1]}){
		print OUT "$line\n";
	}else{
		print OUT2 "$line\n";
	}
}
close ET;
close OUT;
close OUT2;

# perl fig4g_step1.pl --enhtarfile /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_GSR_all.txt --devgenefile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/devgenes.txt --outfile /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_GSR_devgenes.txt --outfile2 /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_GSR_nondevgenes.txt

# perl fig4g_step1.pl --enhtarfile /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_all.txt --devgenefile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/devgenes.txt --outfile /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_devgenes.txt --outfile2 /media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_nondevgenes.txt