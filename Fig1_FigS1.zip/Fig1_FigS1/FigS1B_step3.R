# H3K4me1 common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/density_value_common.RData") 

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K4me1 specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/density_value_specific.RData")

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/density_value_common.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/density_value_specific.RData")

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/density_value_common.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/density_value_specific.RData")

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/density_value_common.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/density_value_specific.RData")

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/density_value_common.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/density_value_specific.RData")

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase common
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_common.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*_common.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*_common.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/density_value_common.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_common.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase specific
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_specific.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*_specific.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*_specific.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/density_value_specific.RData")

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_specific.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)
