#!/usr/bin/env python

import os
import shutil
import glob

def mkdir_p(dir):
    '''make a directory (dir) if it doesn't exist'''
    if not os.path.exists(dir):
        os.mkdir(dir)
    
mkdir_p("/storage/gbcl/qiaolu/EpiData/ATAC_mapping/script")
mkdir_p("/storage/gbcl/qiaolu/EpiData/ATAC_mapping/mapping")

job_directory = "/storage/gbcl/qiaolu/EpiData/ATAC_mapping/mapping"
script_directory = "/storage/gbcl/qiaolu/EpiData/ATAC_mapping/script"

os.chdir("/storage/gbcl/qiaolu/EpiData/ATAC")
files = glob.glob("*_1.fastq")

for file in files:
    file_name = file[:10]
    job_file = os.path.join(script_directory,"%s.bash" % file_name)


    with open(job_file, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p amd-ep2\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J %s\n" % file_name)
        fh.writelines("#SBATCH -c 5\n")
        fh.writelines("#SBATCH --mem 100G\n")
        fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/ATAC_mapping/%s.out\n" % file_name)
        fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/ATAC_mapping/%s.err\n" % file_name)
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load bowtie/2.4.2 \n")
        fh.writelines("bowtie2 -t -q -N 1 -L 25 -X 2000 --no-mixed --no-discordant -x DBA_6NJ -1 /storage/gbcl/qiaolu/EpiData/ATAC/%s_1.fastq -2 /storage/gbcl/qiaolu/EpiData/ATAC/%s_2.fastq -S ATAC_%s_mapping.sam \n" % (file_name, file_name, file_name))


