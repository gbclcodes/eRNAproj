library(foreach)
library(doParallel)

calCommTarNum <- function(pair,network){
	Tars1 <- network[grep(pair[1],network[,1]),2]
	Tars2 <- network[grep(pair[2],network[,1]),2]
	return(intersect(Tars1,Tars2))
}

# GSR
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_enh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EnhIDs <- rownames(mapInfo)

# MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="MIIOocyte" & enhancer.stages[matchIndexesEnh2,3]=="MIIOocyte")
enhenhPairsMIIGSR <- enhenhPairs[matchIndexesPairs,]
MIIenhNum <- nrow(enhenhPairsMIIGSR)

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & enhancer.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cellGSR <- enhenhPairs[matchIndexesPairs,]
X2cellenhNum <- nrow(enhenhPairsX2cellGSR)

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X4cell" & enhancer.stages[matchIndexesEnh2,3]=="X4cell")
enhenhPairsX4cellGSR <- enhenhPairs[matchIndexesPairs,]
X4cellenhNum <- nrow(enhenhPairsX4cellGSR)

EnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumMIIGSRTE <- unique(foreach(iter=1:nrow(enhenhPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsMIIGSR[iter,]),EnhTarDataGSR))
RealNumX2cellGSRTE <- unique(foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR))
RealNumX4cellGSRTE <- unique(foreach(iter=1:nrow(enhenhPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX4cellGSR[iter,]),EnhTarDataGSR))

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_spenh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
EnhIDs <- enhancer.stages[,1]

# MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="MIIOocyte" & enhancer.stages[matchIndexesEnh2,3]=="MIIOocyte")
enhenhPairsMIIGSR <- enhenhPairs[matchIndexesPairs,]
MIIspenhNum <- nrow(enhenhPairsMIIGSR)

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & enhancer.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cellGSR <- enhenhPairs[matchIndexesPairs,]
X2cellspenhNum <- nrow(enhenhPairsX2cellGSR)

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X4cell" & enhancer.stages[matchIndexesEnh2,3]=="X4cell")
enhenhPairsX4cellGSR <- enhenhPairs[matchIndexesPairs,]
X4cellspenhNum <- nrow(enhenhPairsX4cellGSR)

EnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumMIIGSRSE <- unique(foreach(iter=1:nrow(enhenhPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsMIIGSR[iter,]),EnhTarDataGSR))
RealNumX2cellGSRSE <- unique(foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR))
RealNumX4cellGSRSE <- unique(foreach(iter=1:nrow(enhenhPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX4cellGSR[iter,]),EnhTarDataGSR))

num <- c(length(RealNumMIIGSRTE)+length(RealNumMIIGSRSE),length(RealNumX2cellGSRTE)+length(RealNumX2cellGSRSE),length(RealNumX4cellGSRTE)+length(RealNumX4cellGSRSE),MIIenhNum+MIIspenhNum,X2cellenhNum+X2cellspenhNum,X4cellenhNum+X4cellspenhNum)
celltype <- rep(c("MIIOocyte","X2cell","X4cell"),2)
genetype <- rep(c("G","E"),each=3)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("MIIOocyte","X2cell","X4cell"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/CommTFNumTESE_GSR.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(2,1)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
print(p)
dev.off()