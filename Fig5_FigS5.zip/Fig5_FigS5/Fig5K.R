library(foreach)
library(doParallel)

calCommTarNum <- function(pair,network){
	Tars1 <- network[grep(pair[1],network[,1]),2]
	Tars2 <- network[grep(pair[2],network[,1]),2]
	return(intersect(Tars1,Tars2))
}

# XW
high.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.xw,median.enhancers.xw,low.enhancers.xw)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_enh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EnhIDs <- rownames(mapInfo)

matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

# Zygote
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="Zygote" & enhancer.stages[matchIndexesEnh2,3]=="Zygote")
enhenhPairsZygoteXW <- enhenhPairs[matchIndexesPairs,]
ZygoteenhNum <- nrow(enhenhPairsZygoteXW)

# Early 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="E2C" & enhancer.stages[matchIndexesEnh2,3]=="E2C")
enhenhPairsE2CXW <- enhenhPairs[matchIndexesPairs,]
E2CenhNum <- nrow(enhenhPairsE2CXW)

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="L2C" & enhancer.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2CXW <- enhenhPairs[matchIndexesPairs,]
L2CenhNum <- nrow(enhenhPairsL2CXW)

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M4C" & enhancer.stages[matchIndexesEnh2,3]=="M4C")
enhenhPairsM4CXW <- enhenhPairs[matchIndexesPairs,]
M4CenhNum <- nrow(enhenhPairsM4CXW)


EnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumZygoteXWTE <- unique(foreach(iter=1:nrow(enhenhPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsZygoteXW[iter,]),EnhTarDataXW))
RealNumE2CXWTE <- unique(foreach(iter=1:nrow(enhenhPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsE2CXW[iter,]),EnhTarDataXW))
RealNumL2CXWTE <- unique(foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW))
RealNumM4CXWTE <- unique(foreach(iter=1:nrow(enhenhPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsM4CXW[iter,]),EnhTarDataXW))

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_spenh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
EnhIDs <- enhancer.stages[,1]

# Zygote
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="Zygote" & enhancer.stages[matchIndexesEnh2,3]=="Zygote")
enhenhPairsZygoteXW <- enhenhPairs[matchIndexesPairs,]
ZygotespenhNum <- nrow(enhenhPairsZygoteXW)

# Early 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="E2C" & enhancer.stages[matchIndexesEnh2,3]=="E2C")
enhenhPairsE2CXW <- enhenhPairs[matchIndexesPairs,]
E2CspenhNum <- nrow(enhenhPairsE2CXW)

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="L2C" & enhancer.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2CXW <- enhenhPairs[matchIndexesPairs,]
L2CspenhNum <- nrow(enhenhPairsL2CXW)

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M4C" & enhancer.stages[matchIndexesEnh2,3]=="M4C")
enhenhPairsM4CXW <- enhenhPairs[matchIndexesPairs,]
M4CspenhNum <- nrow(enhenhPairsM4CXW)

EnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumZygoteXWSE <- unique(foreach(iter=1:nrow(enhenhPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsZygoteXW[iter,]),EnhTarDataXW))
RealNumE2CXWSE <- unique(foreach(iter=1:nrow(enhenhPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsE2CXW[iter,]),EnhTarDataXW))
RealNumL2CXWSE <- unique(foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW))
RealNumM4CXWSE <- unique(foreach(iter=1:nrow(enhenhPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsM4CXW[iter,]),EnhTarDataXW))

num <- c(length(RealNumZygoteXWTE)+length(RealNumZygoteXWSE),length(RealNumE2CXWTE)+length(RealNumE2CXWSE),length(RealNumL2CXWTE)+length(RealNumL2CXWSE),length(RealNumM4CXWTE)+length(RealNumM4CXWSE),ZygoteenhNum+ZygotespenhNum,E2CenhNum+E2CspenhNum,L2CenhNum+L2CspenhNum,M4CenhNum+M4CspenhNum)
celltype <- rep(c("Zygote","E2C","L2C","M4C"),2)
genetype <- rep(c("G","E"),each=4)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("Zygote","E2C","L2C","M4C"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/CommTargetNumTESE_XW.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(2,1)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
print(p)
dev.off()