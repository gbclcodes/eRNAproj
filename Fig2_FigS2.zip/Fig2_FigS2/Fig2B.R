library(igraph)
library(bigSCale)
library(Matrix)

knownTFs <- as.character(read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/knownTFs.csv",sep=",",header=FALSE,stringsAsFactors=FALSE)[,1])
commonTFs <- as.character(read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/commonTFs.csv",sep=",",header=FALSE,stringsAsFactors=FALSE)[,1])

tf.enh.motif.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_core.txt",header=FALSE,stringsAsFactors=FALSE)
tf.enh.motif.pairs.gsr <- tf.enh.motif.pairs.gsr[,c(5,1,3,4)]
tf.enh.motif.pairs.gsr[,1] <- toupper(tf.enh.motif.pairs.gsr[,1])
tf.names <- unique(tf.enh.motif.pairs.gsr[,1])
enh.ids <- unique(tf.enh.motif.pairs.gsr[,2])
tf.row.indexes <- match(tf.enh.motif.pairs.gsr[,1],c(tf.names,enh.ids))
enh.col.indexes <- match(tf.enh.motif.pairs.gsr[,2],c(tf.names,enh.ids))

tf.stages <- c()
for (tf.name in tf.names){
	match.indexes <- which(tf.enh.motif.pairs.gsr[,1]==tf.name)
	if(length(unique(tf.enh.motif.pairs.gsr[match.indexes,4])) == 1){
		tf.stages <- c(tf.stages,paste0(unique(tf.enh.motif.pairs.gsr[match.indexes,4]),collapse="-"))
	}else if(length(unique(tf.enh.motif.pairs.gsr[match.indexes,4])) > 1){
		tf.stages <- c(tf.stages,length(unique(tf.enh.motif.pairs.gsr[match.indexes,4])))
	}
}

enh.stages <- c()
for (enh.id in enh.ids){
	match.index <- which(tf.enh.motif.pairs.gsr[,2]==enh.id)
	enh.stages <- c(enh.stages,paste0(unique(tf.enh.motif.pairs.gsr[match.index,4]),collapse="-"))
}

tf.class <- rep("Other",length(tf.names))
match.known <- match(knownTFs,tf.names)
match.common <- match(commonTFs,tf.names)
tf.class[match.common] <- "Common"
tf.class[match.known] <- "Known"
tf.class <- c(tf.class,rep("Enh",length(enh.ids)))

tf.enh.sp.mat <- sparseMatrix(i=tf.row.indexes,j=enh.col.indexes,x=as.numeric(tf.enh.motif.pairs.gsr[,3]),symmetric=FALSE,dims=c(length(tf.names)+length(enh.ids),length(tf.names)+length(enh.ids)),dimnames=list(c(tf.names,enh.ids),c(tf.names,enh.ids)))
tf.enh.net.graph <- graph.adjacency(tf.enh.sp.mat,mode="directed",weighted=TRUE)
match.indexes <- match(paste(as_edgelist(tf.enh.net.graph)[,1],as_edgelist(tf.enh.net.graph)[,2],sep="\t"),paste(tf.enh.motif.pairs.gsr[,1],tf.enh.motif.pairs.gsr[,2],sep="\t"))
match.indexes <- match.indexes[which(!is.na(match.indexes))]

tf.enh.net.graph <- set_edge_attr(tf.enh.net.graph, E(tf.enh.net.graph), name = "stage", value = tf.enh.motif.pairs.gsr[match.indexes,4])
tf.enh.net.graph <- set_vertex_attr(tf.enh.net.graph, V(tf.enh.net.graph), name = "stage", value = c(tf.stages,enh.stages))
tf.enh.net.graph <- set_vertex_attr(tf.enh.net.graph, V(tf.enh.net.graph), name = "type", value = c(rep("TF",length(tf.stages)),rep("ENH",length(enh.stages))))
tf.enh.net.graph <- set_vertex_attr(tf.enh.net.graph, V(tf.enh.net.graph), name = "class", value = tf.class)
toCytoscape(G = tf.enh.net.graph,file.name = '/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_core.json')