#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J SRR5479508
#SBATCH -c 1
#SBATCH --mem 150G
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479508.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479508.err

cd /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping
module load bowtie/2.4.2 
module load samtools/1.14 
/storage/gbcl/qiaolu/Bismark-0.23.0/bismark --score_min L,0,-0.6 --genome /storage/gbcl/qiaolu/EpiData/METH -1 /storage/gbcl/qiaolu/EpiData/DNAMethData/SRR5479508_1.fastq -2 /storage/gbcl/qiaolu/EpiData/DNAMethData/SRR5479508_2.fastq -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479508 
