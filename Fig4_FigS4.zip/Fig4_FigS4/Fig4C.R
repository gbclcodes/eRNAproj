TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_GSR.bed",header=FALSE,stringsAsFactors=FALSE)
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]
SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)
TENet <- TENet[which(TENet[,3] > 1),]
SENet <- SENet[which(SENet[,3] > 1),]

TENumGSR <- c()
SENumGSR <- c()
stageNames <- unique(TENet[,4])
for (stageName in stageNames){
	stageNet <- TENet[which(TENet[,4]==stageName),]
	TFNum <- length(unique(stageNet[,2]))
	TENumGSR <- c(TENumGSR,TFNum)
	stageNet <- SENet[which(SENet[,4]==stageName),]
	TFNum <- length(unique(stageNet[,2]))
	SENumGSR <- c(SENumGSR,TFNum)
}
names(TENumGSR) <- stageNames
names(SENumGSR) <- stageNames

TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_XW.bed",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
TENet <- TENet[matchIndexes,]
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)
TENet <- TENet[which(TENet[,3] > 1),]
SENet <- SENet[which(SENet[,3] > 1),]

TENumXW <- c()
SENumXW <- c()
stageNames <- unique(TENet[,4])
for (stageName in stageNames){
	stageNet <- TENet[which(TENet[,4]==stageName),]
	TFNum <- length(unique(stageNet[,2]))
	TENumXW <- c(TENumXW,TFNum)
	stageNet <- SENet[which(SENet[,4]==stageName),]
	TFNum <- length(unique(stageNet[,2]))
	SENumXW <- c(SENumXW,TFNum)
}
names(TENumXW) <- stageNames
names(SENumXW) <- stageNames

TENumMII <- TENumGSR[6] + TENumXW[2]
TENumZygote <- TENumXW[5]
TENumE2C <- TENumXW[4]
TENum2C <-  TENumGSR[1] + TENumXW[3]
TENum4C <-  TENumGSR[5] + TENumXW[6]
TENum8C <-  TENumGSR[3] + TENumXW[7]
TENumMorula <-  TENumGSR[4]
TENumICM <-  TENumGSR[2] + TENumXW[1]

SENumMII <- SENumGSR[6] + SENumXW[2]
SENumZygote <- SENumXW[5]
SENumE2C <- SENumXW[4]
SENum2C <-  SENumGSR[1] + SENumXW[3]
SENum4C <-  SENumGSR[5] + SENumXW[6]
SENum8C <-  SENumGSR[3] + SENumXW[7]
SENumMorula <-  SENumGSR[4]
SENumICM <-  SENumGSR[2] + SENumXW[1]


perc <- c(TENumMII,TENumZygote,TENumE2C,TENum2C,TENum4C,TENum8C,TENumMorula,TENumICM,SENumMII,SENumZygote,SENumE2C,SENum2C,SENum4C,SENum8C,SENumMorula,SENumICM)
stage <- c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM","MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM")
type <- c("TE","TE","TE","TE","TE","TE","TE","TE","SE","SE","SE","SE","SE","SE","SE","SE")

statData <- as.data.frame(cbind(perc,stage,type))
colnames(statData) <- c("perc","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("TE","SE"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/TFNumTESE.pdf",width=6,height=5)
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(2,1)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()

wilcox.test(perc[1:8],perc[9:16],paired=TRUE)