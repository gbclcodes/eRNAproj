#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J PWK_6J                          
#SBATCH -c 1
#SBATCH --mem 30G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/PWK_6J/index.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/PWK_6J/index.err


cd /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK
mkdir mapping

cd /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/mapping

module load bowtie/2.4.2

bowtie2-build /storage/gbcl/qiaolu/EpiData/PWK_6J/PWK_PhJ_N-masked/PWK_C57BL_6J.Nmasked.fa PWK_6J