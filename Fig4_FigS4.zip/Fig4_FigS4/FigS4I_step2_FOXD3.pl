#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "accepted_hits.sorted.unique.bam"`;
print join("\n",@samples)."\n";
foreach my $sample (@samples){
	chomp $sample;
	$sample =~ /(SRR.*)\/accepted_hits.sorted.unique.bam/;
	my $sample_id = $1;
	
	open(SH,">$outputdir/$sample_id/${sample_id}_bamtobw.sh") or die "$!\n";
    if(!-e "$outputdir/$sample_id/${sample_id}.bw" || -z "$outputdir/$sample_id/${sample_id}.bw"){
		print SH "bamCoverage -b $outputdir/$sample_id/accepted_hits.sorted.unique.bam -of bigwig --binSize 100 --ignoreDuplicates --normalizeUsing BPM --numberOfProcessors $threads -o $outputdir/$sample_id/${sample_id}.bw\n";
       
    }
    
    open OUT,">$outputdir/$sample_id/submit_${sample_id}_bamtobw.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $sample_id			
#SBATCH -c 2
#SBATCH --mem 30G
#SBATCH -o $outputdir/$sample_id/%j.log
#SBATCH -e $outputdir/$sample_id/%j.err

date
source ~/.bashrc
conda activate py37
sh $outputdir/$sample_id/${sample_id}_bamtobw.sh
date
EOF
	close OUT;
	my $sb = `sbatch $outputdir/$sample_id/submit_${sample_id}_bamtobw.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl FOXD3_sample_bamtobw_pipeline.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/FOXD3KORNAseqData/hisat2file --outputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/FOXD3KORNAseqData/hisat2file --threads 2

