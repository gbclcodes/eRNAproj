library(reshape2)
library(plyr)
library(Matrix)
library(foreach)
library(doParallel)

args <-commandArgs(TRUE)

mapBin <- function(vec,binMat){
   vec <- unlist(strsplit(vec,"\t"))
   binIndexes <- binMat[which(binMat[,1] == vec[1] & ((binMat[,2] >= as.numeric(vec[2]) & (binMat[,2]) <= as.numeric(vec[3])) | (binMat[,3] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])) | (binMat[,2] <= as.numeric(vec[2]) & (binMat[,3]) >= as.numeric(vec[3])) | (binMat[,2] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])))),4]
   return(binIndexes)
}

OEvalueCal <- function(enhenhPair,enhPosInfo,spenhPosInfo,contactMatrix,mapData){
	matchIndexEnh1 <- match(enhenhPair[1],enhPosInfo[,4])
	matchIndexEnh2 <- match(enhenhPair[2],spenhPosInfo[,4])
	if(!is.na(matchIndexEnh1) && !is.na(matchIndexEnh2)){
		enhBins1 <- as.numeric(unlist(sapply(paste(enhPosInfo[matchIndexEnh1,1],enhPosInfo[matchIndexEnh1,2],enhPosInfo[matchIndexEnh1,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
		enhBins2 <- as.numeric(unlist(sapply(paste(spenhPosInfo[matchIndexEnh2,1],spenhPosInfo[matchIndexEnh2,2],spenhPosInfo[matchIndexEnh2,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
		if(length(enhBins1) > 0 && length(enhBins2) > 0){
			matchBins <- which(mapData[,1]==enhPosInfo[matchIndexEnh1,1])
			randomSums <- sum(contactMatrix[sample(matchBins,length(enhBins1)),sample(matchBins,length(enhBins2))] + t(contactMatrix[sample(matchBins,length(enhBins2)),sample(matchBins,length(enhBins1))]))
			return(randomSums)
		}
	}
}

high.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

high.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
spenh.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enhenhPairs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enh_spenh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

# MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],spenh.stages[,1])

# matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="MIIOocyte" & spenh.stages[matchIndexesEnh2,3]=="MIIOocyte")
# enhenhPairsMII <- enhenhPairs[matchIndexesPairs,]

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & spenh.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cell <- enhenhPairs[matchIndexesPairs,]

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X8cell" & spenh.stages[matchIndexesEnh2,3]=="X8cell")
enhenhPairsX8cell <- enhenhPairs[matchIndexesPairs,]

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & spenh.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICM <- enhenhPairs[matchIndexesPairs,]

mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhancerPosInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_annotation_step6_GSR_6column_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
spenhPosInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/SuperE3_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

cl <- makeCluster(10)
registerDoParallel(cl)
# if(!file.exists(paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecMIIGSRIC",args[1],".RData",sep=""))){
	# MIIData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
	# freqMatMII <- sparseMatrix(as.numeric(MIIData[,1]), as.numeric(MIIData[,2]), x = as.numeric(MIIData[,3]))
	# rm(MIIData)
	# try(enhenhPairsOEvecMII <- foreach(iterer=1:nrow(enhenhPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsMII[iterer,]),enhancerPosInfo,spenhPosInfo,freqMatMII,mapData))
	# try(enhenhPairsOEvecMII <- foreach(iterer=1:nrow(enhenhPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsMII[iterer,]),enhancerPosInfo,spenhPosInfo,freqMatMII,mapData))
	# save(enhenhPairsOEvecMII,file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecMIIGSRIC",args[1],".RData",sep=""))
	# rm(freqMatMII)
# }

if(!file.exists(paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecE2CGSRIC",args[1],".RData",sep=""))){
	E2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
	freqMatE2C <- sparseMatrix(as.numeric(E2CData[,1]), as.numeric(E2CData[,2]), x = as.numeric(E2CData[,3]))
	rm(E2CData)
	try(enhenhPairsOEvecE2C <- foreach(iter=1:nrow(enhenhPairsX2cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX2cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatE2C,mapData))
	try(enhenhPairsOEvecE2C <- foreach(iter=1:nrow(enhenhPairsX2cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX2cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatE2C,mapData))
	save(enhenhPairsOEvecE2C,file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecE2CGSRIC",args[1],".RData", sep=""))
	rm(freqMatE2C)
}

if(!file.exists(paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecL2CGSRIC",args[1],".RData",sep=""))){
	L2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
	freqMatL2C <- sparseMatrix(as.numeric(L2CData[,1]), as.numeric(L2CData[,2]), x = as.numeric(L2CData[,3]))
	rm(L2CData)
	try(enhenhPairsOEvecL2C <- foreach(iter=1:nrow(enhenhPairsX2cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX2cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatL2C,mapData))
	try(enhenhPairsOEvecL2C <- foreach(iter=1:nrow(enhenhPairsX2cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX2cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatL2C,mapData))
	save(enhenhPairsOEvecL2C,file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecL2CGSRIC",args[1],".RData", sep=""))
	rm(freqMatL2C)
}

if(!file.exists(paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecM8CGSRIC",args[1],".RData",sep=""))){
	M8CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
	freqMatM8C <- sparseMatrix(as.numeric(M8CData[,1]), as.numeric(M8CData[,2]), x = as.numeric(M8CData[,3]))
	rm(M8CData)
	try(enhenhPairsOEvecM8C <- foreach(iter=1:nrow(enhenhPairsX8cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX8cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatM8C,mapData))
	try(enhenhPairsOEvecM8C <- foreach(iter=1:nrow(enhenhPairsX8cell),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsX8cell[iter,]),enhancerPosInfo,spenhPosInfo,freqMatM8C,mapData))
	save(enhenhPairsOEvecM8C,file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecM8CGSRIC",args[1],".RData", sep=""))
	rm(freqMatM8C)
}

if(!file.exists(paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecICMGSRIC",args[1],".RData",sep=""))){
	ICMData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
	freqMatICM <- sparseMatrix(as.numeric(ICMData[,1]), as.numeric(ICMData[,2]), x = as.numeric(ICMData[,3]))
	rm(ICMData)
	try(enhenhPairsOEvecICM <- foreach(iter=1:nrow(enhenhPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsICM[iter,]),enhancerPosInfo,spenhPosInfo,freqMatICM,mapData))
	try(enhenhPairsOEvecICM <- foreach(iter=1:nrow(enhenhPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsICM[iter,]),enhancerPosInfo,spenhPosInfo,freqMatICM,mapData))
	save(enhenhPairsOEvecICM,file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/enhspenhPairOEvecICMGSRIC",args[1],".RData",sep=""))
	rm(freqMatICM)
}
stopCluster(cl)
