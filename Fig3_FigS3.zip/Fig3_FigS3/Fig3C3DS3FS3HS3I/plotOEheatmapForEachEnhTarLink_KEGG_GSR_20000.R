library(Matrix)
library(pheatmap)

mapBin <- function(vec,binMat){
   vec <- unlist(strsplit(vec,"\t"))
   binIndexes <- binMat[which(binMat[,1] == vec[1] & ((binMat[,2] >= as.numeric(vec[2]) & (binMat[,2]) <= as.numeric(vec[3])) | (binMat[,3] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])) | (binMat[,2] <= as.numeric(vec[2]) & (binMat[,3]) >= as.numeric(vec[3])) | (binMat[,2] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])))),4]
   return(binIndexes)
}

enhtarData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enh_target_pairs_GSR_signalpathgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
geneInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/known_genes_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_annotation_step6_GSR_6column_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
geneStage <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/gene_stage_specific_scores_GSR_subset.txt",sep=" ",header=FALSE,stringsAsFactors=FALSE)
geneStage[,1] <- gsub("\\.\\d+","",geneStage[,1])
enhStage <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/enhancer_stage_specific_scores_stagename_GSR_subset.txt",sep=" ",header=FALSE,stringsAsFactors=FALSE)

matchIndexes_enh <- match(enhtarData[,1],enhStage[,1])
matchIndexes_gene <- match(enhtarData[,3],geneStage[,1])
nonnaIndexes <- which(!is.na(matchIndexes_enh) & !is.na(matchIndexes_gene))
matchIndexes_enh <- matchIndexes_enh[nonnaIndexes]
matchIndexes_gene <- matchIndexes_gene[nonnaIndexes]
commIndexes <- which(enhStage[matchIndexes_enh,3]==geneStage[matchIndexes_gene,3])
enhtarPairs <- cbind(enhStage[matchIndexes_enh[commIndexes],1],geneStage[matchIndexes_gene[commIndexes],1],enhStage[matchIndexes_enh[commIndexes],3])
enhtarPairsMIIOocyte <- enhtarPairs[which(enhtarPairs[,3]=="MIIOocyte"),]
enhtarPairsX2cell <- enhtarPairs[which(enhtarPairs[,3]=="X2cell"),]
enhtarPairsX8cell <- enhtarPairs[which(enhtarPairs[,3]=="X8cell"),]
enhtarPairsICM <- enhtarPairs[which(enhtarPairs[,3]=="ICM"),]

# MIIOocyte
conDataMIIOocyte <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatrixMIIOocyte <- sparseMatrix(as.numeric(conDataMIIOocyte[,1]), as.numeric(conDataMIIOocyte[,2]), x = as.numeric(conDataMIIOocyte[,3]))
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

for (rowindex in seq(1,nrow(enhtarPairsMIIOocyte))){
	matchIndexE <- match(enhtarPairsMIIOocyte[rowindex,1],enhInfo[,4])
	matchIndexT <- match(enhtarPairsMIIOocyte[rowindex,2],geneInfo[,4])
	if(!is.na(matchIndexE) & !is.na(matchIndexT) & enhInfo[matchIndexE,1]==geneInfo[matchIndexT,1]){
		enhVec <- paste(enhInfo[matchIndexE,1],enhInfo[matchIndexE,2],enhInfo[matchIndexE,3],sep="\t")
		tarVec <- paste(geneInfo[matchIndexT,1],geneInfo[matchIndexT,2],geneInfo[matchIndexT,3],sep="\t")
		enhBins <- as.numeric(unlist(sapply(enhVec,mapBin,mapData,simplify=TRUE)))
		tarBins <- as.numeric(unlist(sapply(tarVec,mapBin,mapData,simplify=TRUE)))
		if(length(enhBins) > 0 && length(tarBins) > 0){
			enhBins <- unique(enhBins)
			tarBins <- unique(tarBins)
			freqMatrix <- freqMatrixMIIOocyte
			binNum <- min(abs(max(tarBins)-max(enhBins)),abs(max(tarBins)-min(enhBins)),abs(min(enhBins)-min(tarBins)),abs(min(enhBins)-max(tarBins)))
			if(binNum >= 1){
				if(min(tarBins) > max(enhBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(enhBins)-binNum),(min(enhBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIOocyte20000heatmapGSRKEGG/",enhtarPairsMIIOocyte[rowindex,1],enhtarPairsMIIOocyte[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
				if(min(enhBins) > max(tarBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(tarBins)-binNum),(min(tarBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)					
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIOocyte20000heatmapGSRKEGG/",enhtarPairsMIIOocyte[rowindex,1],enhtarPairsMIIOocyte[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
			}
		}
	}
}
rm(conDataMIIOocyte,freqMatrixMIIOocyte,mapData)

# E2C
conDataE2C <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatrixE2C <- sparseMatrix(as.numeric(conDataE2C[,1]), as.numeric(conDataE2C[,2]), x = as.numeric(conDataE2C[,3]))
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

for (rowindex in seq(1,nrow(enhtarPairsX2cell))){
	matchIndexE <- match(enhtarPairsX2cell[rowindex,1],enhInfo[,4])
	matchIndexT <- match(enhtarPairsX2cell[rowindex,2],geneInfo[,4])
	if(!is.na(matchIndexE) & !is.na(matchIndexT) & enhInfo[matchIndexE,1]==geneInfo[matchIndexT,1]){
		enhVec <- paste(enhInfo[matchIndexE,1],enhInfo[matchIndexE,2],enhInfo[matchIndexE,3],sep="\t")
		tarVec <- paste(geneInfo[matchIndexT,1],geneInfo[matchIndexT,2],geneInfo[matchIndexT,3],sep="\t")
		enhBins <- as.numeric(unlist(sapply(enhVec,mapBin,mapData,simplify=TRUE)))
		tarBins <- as.numeric(unlist(sapply(tarVec,mapBin,mapData,simplify=TRUE)))
		if(length(enhBins) > 0 && length(tarBins) > 0){
			enhBins <- unique(enhBins)
			tarBins <- unique(tarBins)
			freqMatrix <- freqMatrixE2C
			binNum <- min(abs(max(tarBins)-max(enhBins)),abs(max(tarBins)-min(enhBins)),abs(min(enhBins)-min(tarBins)),abs(min(enhBins)-max(tarBins)))
			if(binNum >= 1){
				if(min(tarBins) > max(enhBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(enhBins)-binNum),(min(enhBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1 
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C20000heatmapGSRKEGG/",enhtarPairsX2cell[rowindex,1],enhtarPairsX2cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
				if(min(enhBins) > max(tarBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(tarBins)-binNum),(min(tarBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1 
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C20000heatmapGSRKEGG/",enhtarPairsX2cell[rowindex,1],enhtarPairsX2cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
			}
		}
	}
}
rm(conDataE2C,freqMatrixE2C,mapData)

# L2C
conDataL2C <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatrixL2C <- sparseMatrix(as.numeric(conDataL2C[,1]), as.numeric(conDataL2C[,2]), x = as.numeric(conDataL2C[,3]))
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

for (rowindex in seq(1,nrow(enhtarPairsX2cell))){
	matchIndexE <- match(enhtarPairsX2cell[rowindex,1],enhInfo[,4])
	matchIndexT <- match(enhtarPairsX2cell[rowindex,2],geneInfo[,4])
	if(!is.na(matchIndexE) & !is.na(matchIndexT) & enhInfo[matchIndexE,1]==geneInfo[matchIndexT,1]){
		enhVec <- paste(enhInfo[matchIndexE,1],enhInfo[matchIndexE,2],enhInfo[matchIndexE,3],sep="\t")
		tarVec <- paste(geneInfo[matchIndexT,1],geneInfo[matchIndexT,2],geneInfo[matchIndexT,3],sep="\t")
		enhBins <- as.numeric(unlist(sapply(enhVec,mapBin,mapData,simplify=TRUE)))
		tarBins <- as.numeric(unlist(sapply(tarVec,mapBin,mapData,simplify=TRUE)))
		if(length(enhBins) > 0 && length(tarBins) > 0){
			enhBins <- unique(enhBins)
			tarBins <- unique(tarBins)
			freqMatrix <- freqMatrixL2C
			binNum <- min(abs(max(tarBins)-max(enhBins)),abs(max(tarBins)-min(enhBins)),abs(min(enhBins)-min(tarBins)),abs(min(enhBins)-max(tarBins)))
			if(binNum >= 1){
				if(min(tarBins) > max(enhBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(enhBins)-binNum),(min(enhBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C20000heatmapGSRKEGG/",enhtarPairsX2cell[rowindex,1],enhtarPairsX2cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
				if(min(enhBins) > max(tarBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(tarBins)-binNum),(min(tarBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C20000heatmapGSRKEGG/",enhtarPairsX2cell[rowindex,1],enhtarPairsX2cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
			}
		}
	}
}
rm(conDataL2C,freqMatrixL2C,mapData)

# M8C
conDataM8C <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatrixM8C <- sparseMatrix(as.numeric(conDataM8C[,1]), as.numeric(conDataM8C[,2]), x = as.numeric(conDataM8C[,3]))
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

for (rowindex in seq(1,nrow(enhtarPairsX8cell))){
	matchIndexE <- match(enhtarPairsX8cell[rowindex,1],enhInfo[,4])
	matchIndexT <- match(enhtarPairsX8cell[rowindex,2],geneInfo[,4])
	if(!is.na(matchIndexE) & !is.na(matchIndexT) & enhInfo[matchIndexE,1]==geneInfo[matchIndexT,1]){
		enhVec <- paste(enhInfo[matchIndexE,1],enhInfo[matchIndexE,2],enhInfo[matchIndexE,3],sep="\t")
		tarVec <- paste(geneInfo[matchIndexT,1],geneInfo[matchIndexT,2],geneInfo[matchIndexT,3],sep="\t")
		enhBins <- as.numeric(unlist(sapply(enhVec,mapBin,mapData,simplify=TRUE)))
		tarBins <- as.numeric(unlist(sapply(tarVec,mapBin,mapData,simplify=TRUE)))
		if(length(enhBins) > 0 && length(tarBins) > 0){
			enhBins <- unique(enhBins)
			tarBins <- unique(tarBins)
			freqMatrix <- freqMatrixM8C
			binNum <- min(abs(max(tarBins)-max(enhBins)),abs(max(tarBins)-min(enhBins)),abs(min(enhBins)-min(tarBins)),abs(min(enhBins)-max(tarBins)))
			if(binNum >= 1){
				if(min(tarBins) > max(enhBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(enhBins)-binNum),(min(enhBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C20000heatmapGSRKEGG/",enhtarPairsX8cell[rowindex,1],enhtarPairsX8cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
				if(min(enhBins) > max(tarBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(tarBins)-binNum),(min(tarBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C20000heatmapGSRKEGG/",enhtarPairsX8cell[rowindex,1],enhtarPairsX8cell[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
			}
		}
	}
}
rm(conDataM8C,freqMatrixM8C,mapData)

# ICM
conDataICM <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatrixICM <- sparseMatrix(as.numeric(conDataICM[,1]), as.numeric(conDataICM[,2]), x = as.numeric(conDataICM[,3]))
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

for (rowindex in seq(1,nrow(enhtarPairsICM))){
	matchIndexE <- match(enhtarPairsICM[rowindex,1],enhInfo[,4])
	matchIndexT <- match(enhtarPairsICM[rowindex,2],geneInfo[,4])
	if(!is.na(matchIndexE) & !is.na(matchIndexT) & enhInfo[matchIndexE,1]==geneInfo[matchIndexT,1]){
		enhVec <- paste(enhInfo[matchIndexE,1],enhInfo[matchIndexE,2],enhInfo[matchIndexE,3],sep="\t")
		tarVec <- paste(geneInfo[matchIndexT,1],geneInfo[matchIndexT,2],geneInfo[matchIndexT,3],sep="\t")
		enhBins <- as.numeric(unlist(sapply(enhVec,mapBin,mapData,simplify=TRUE)))
		tarBins <- as.numeric(unlist(sapply(tarVec,mapBin,mapData,simplify=TRUE)))
		if(length(enhBins) > 0 && length(tarBins) > 0){
			enhBins <- unique(enhBins)
			tarBins <- unique(tarBins)
			freqMatrix <- freqMatrixICM
			binNum <- min(abs(max(tarBins)-max(enhBins)),abs(max(tarBins)-min(enhBins)),abs(min(enhBins)-min(tarBins)),abs(min(enhBins)-max(tarBins)))
			if(binNum >= 1){
				if(min(tarBins) > max(enhBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(enhBins)-binNum),(min(enhBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)				
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM20000heatmapGSRKEGG/",enhtarPairsICM[rowindex,1],enhtarPairsICM[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
				if(min(enhBins) > max(tarBins)){
					if(length(enhBins) > 1 && length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(enhBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(enhBins)-1),],colMeans(freqMatrix[enhBins,]),freqMatrix[(max(enhBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(enhBins)-1)],rowMeans(freqMatrix[,enhBins]),freqMatrix[,(max(enhBins)+1):ncol(freqMatrix)])
					}else if(length(tarBins) > 1){
						freqMatrix <- rbind(freqMatrix[1:(min(tarBins)-1),],colMeans(freqMatrix[tarBins,]),freqMatrix[(max(tarBins)+1):nrow(freqMatrix),])
						freqMatrix <- cbind(freqMatrix[,1:(min(tarBins)-1)],rowMeans(freqMatrix[,tarBins]),freqMatrix[,(max(tarBins)+1):ncol(freqMatrix)])
					}
					plotBins <- seq((min(tarBins)-binNum),(min(tarBins)+2*binNum))
					plotBins[which(plotBins <= 0)] <- 1
					plotBins[which(plotBins > nrow(freqMatrix))] <- nrow(freqMatrix)
					plotData <- freqMatrix[plotBins,plotBins] + t(freqMatrix[plotBins,plotBins])
					rownames(plotData) <- paste("Bin",plotBins,sep="")
					colnames(plotData) <- paste("Bin",plotBins,sep="")
					pdf(file=paste("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM20000heatmapGSRKEGG/",enhtarPairsICM[rowindex,1],enhtarPairsICM[rowindex,2],".pdf",sep=""),width=10,height=10)
					pheatmap(plotData,scale="none",cluster_rows=FALSE,cluster_cols=FALSE,breaks = c(seq(0,2,0.02)),color = colorRampPalette(c("white","#FF3333","magenta"))(100),border_color="NA",fontsize=4,show_rownames=FALSE,show_colnames=FALSE)
					dev.off()
				}
			}
		}
	}
}
rm(conDataICM,freqMatrixICM,mapData)
