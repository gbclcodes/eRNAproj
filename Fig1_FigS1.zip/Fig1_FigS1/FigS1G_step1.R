library(foreach)
library(doParallel)
library(pheatmap)

expValNormalization <- function(expVec){
	expVec <- log2(expVec+1)/sum(log2(expVec+1))
	return(expVec)
}

scaleNorm <- function(x){
    x <- as.numeric(x)
    return((x-mean(x))/(sd(x)))
}

maxvalue <- function(x){
    max_value <- max(x)
}

JSscoreCal <- function(probVec,stdMat,stageNames){
	HscoreVec <- c()
	probVec[which(probVec < 2e-100)] <- runif(length(which(probVec < 2e-100)),min=1e-100,max=2e-100)
	for(colIndex in seq(1,ncol(stdMat))){
		meanProb <- (probVec+stdMat[,colIndex])/2
		meanH <- -sum(meanProb*log2(meanProb))
		pop1H <- -sum(probVec*log2(probVec))
		pop2H <- -sum(stdMat[,colIndex]*log2(stdMat[,colIndex]))
		HscoreVec <- c(HscoreVec,(1-sqrt(meanH-(pop1H+pop2H)/2)))
	}
	JSscore <- max(HscoreVec)
    stageName <- stageNames[which(HscoreVec==max(HscoreVec))]
	return(c(JSscore,stageName))
}

cl <- makeCluster(20)
registerDoParallel(cl)
geneExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/gene_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(geneExpData) <- geneExpData[,1]
geneInfo <- read.table(file="/media/yuhua/yuhua_projects/genomeanno/gencode.vM17.genetype.tab",sep="\t",header=FALSE,stringsAsFactors=FALSE)

stageNames <- c("MIIOocyte","X2cell","X4cell","X8cell","morula","ICM","TE","EpiE65","ExeE65")
matchIndexes <- match(stageNames,colnames(geneExpData))
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
geneExpData <- geneExpData[,matchIndexes]

bgMatrix <- matrix(0,nrow=length(stageNames),ncol=length(stageNames))
cat("The stage number:",length(stageNames),"\n")
for(stageIter in seq(1,length(stageNames))){
	randomNum <- runif(length(stageNames),min=1e-100,max=2e-100)
	bgMatrix[stageIter,stageIter] <- 1
	bgMatrix[,stageIter] <- bgMatrix[,stageIter] + randomNum
}

# JS score calculation
geneExpDataNorm <- t(apply(geneExpData,1,expValNormalization))
geneJSscoreVec <- foreach(iter=1:nrow(geneExpDataNorm),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% JSscoreCal(geneExpDataNorm[iter,],bgMatrix,stageNames)
rownames(geneJSscoreVec) <- rownames(geneExpDataNorm)
genenonaIndexes <- which(!is.na(geneJSscoreVec[,1]))
geneJSscoreVec <- geneJSscoreVec[genenonaIndexes,]
geneJSscoreVec <- as.data.frame(geneJSscoreVec)
colnames(geneJSscoreVec) <- c("JSscore","StageName")
geneJSscoreVec <- geneJSscoreVec[which(geneJSscoreVec[,1]!="NaN"),]
write.table(geneJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_GSR.txt",row.names=T,col.names=F,quote=F)
geneJSscoreVec <- geneJSscoreVec[which(geneJSscoreVec[,1] >= 0.7),]
geneJSscoreVec[,2] <- factor(geneJSscoreVec[,2],levels=rev(c("MIIOocyte","X2cell","X4cell","X8cell","morula","ICM","TE","EpiE65","ExeE65")),ordered=TRUE)
geneJSscoreVec <- geneJSscoreVec[order(geneJSscoreVec[,2],geneJSscoreVec[,1],decreasing=TRUE),]

pcmatchIndexes <- grep('protein_coding',geneInfo[,2])
pcmatchIndexes <- match(geneInfo[pcmatchIndexes,1],rownames(geneJSscoreVec))
pcmatchIndexes <- pcmatchIndexes[which(!is.na(pcmatchIndexes))]
pcJSscoreVec <- geneJSscoreVec[pcmatchIndexes,]
pcJSscoreVec <- pcJSscoreVec[order(pcJSscoreVec[,2],pcJSscoreVec[,1],decreasing=TRUE),]
write.table(pcJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_highscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(pcJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_u0.7_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()

lncRNAmatchIndexes <- grep('processed_transcript|lincRNA|3prime_overlapping_ncrna|antisense|non_coding|sense_intronic|sense_overlapping|TEC|known_ncrna|macro_lncRNA|bidirectional_promoter_lncrna',geneInfo[,2])
lncRNAmatchIndexes <- match(geneInfo[lncRNAmatchIndexes,1],rownames(geneJSscoreVec))
lncRNAmatchIndexes <- lncRNAmatchIndexes[which(!is.na(lncRNAmatchIndexes))]
lncRNAJSscoreVec <- geneJSscoreVec[lncRNAmatchIndexes,]
lncRNAJSscoreVec <- lncRNAJSscoreVec[order(lncRNAJSscoreVec[,2],lncRNAJSscoreVec[,1],decreasing=TRUE),]
write.table(lncRNAJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_highscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(lncRNAJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_u0.7_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()

geneJSscoreVec <- foreach(iter=1:nrow(geneExpDataNorm),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% JSscoreCal(geneExpDataNorm[iter,],bgMatrix,stageNames)
rownames(geneJSscoreVec) <- rownames(geneExpDataNorm)
enhnonaIndexes <- which(!is.na(geneJSscoreVec[,1]))
geneJSscoreVec <- geneJSscoreVec[enhnonaIndexes,]
geneJSscoreVec <- as.data.frame(geneJSscoreVec)
colnames(geneJSscoreVec) <- c("JSscore","StageName")
geneJSscoreVec <- geneJSscoreVec[which(geneJSscoreVec[,1] < 0.7 & geneJSscoreVec[,1] >= 0.3),]
geneJSscoreVec[,2] <- factor(geneJSscoreVec[,2],levels=rev(c("MIIOocyte","X2cell","X4cell","X8cell","morula","ICM","TE","EpiE65","ExeE65")),ordered=TRUE)
geneJSscoreVec <- geneJSscoreVec[order(geneJSscoreVec[,2],geneJSscoreVec[,1],decreasing=TRUE),]

pcmatchIndexes <- grep('protein_coding',geneInfo[,2])
pcmatchIndexes <- match(geneInfo[pcmatchIndexes,1],rownames(geneJSscoreVec))
pcmatchIndexes <- pcmatchIndexes[which(!is.na(pcmatchIndexes))]
pcJSscoreVec <- geneJSscoreVec[pcmatchIndexes,]
pcJSscoreVec <- pcJSscoreVec[order(pcJSscoreVec[,2],pcJSscoreVec[,1],decreasing=TRUE),]
write.table(pcJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_medianscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(pcJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_l0.7u0.3_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()

lncRNAmatchIndexes <- grep('processed_transcript|lincRNA|3prime_overlapping_ncrna|antisense|non_coding|sense_intronic|sense_overlapping|TEC|known_ncrna|macro_lncRNA|bidirectional_promoter_lncrna',geneInfo[,2])
lncRNAmatchIndexes <- match(geneInfo[lncRNAmatchIndexes,1],rownames(geneJSscoreVec))
lncRNAmatchIndexes <- lncRNAmatchIndexes[which(!is.na(lncRNAmatchIndexes))]
lncRNAJSscoreVec <- geneJSscoreVec[lncRNAmatchIndexes,]
lncRNAJSscoreVec <- lncRNAJSscoreVec[order(lncRNAJSscoreVec[,2],lncRNAJSscoreVec[,1],decreasing=TRUE),]
write.table(lncRNAJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_medianscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(lncRNAJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_l0.7u0.3_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()

geneJSscoreVec <- foreach(iter=1:nrow(geneExpDataNorm),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% JSscoreCal(geneExpDataNorm[iter,],bgMatrix,stageNames)
rownames(geneJSscoreVec) <- rownames(geneExpDataNorm)
enhnonaIndexes <- which(!is.na(geneJSscoreVec[,1]))
geneJSscoreVec <- geneJSscoreVec[enhnonaIndexes,]
geneJSscoreVec <- as.data.frame(geneJSscoreVec)
colnames(geneJSscoreVec) <- c("JSscore","StageName")
geneJSscoreVec <- geneJSscoreVec[which( geneJSscoreVec[,1] < 0.3),]
geneJSscoreVec[,2] <- factor(geneJSscoreVec[,2],levels=rev(c("MIIOocyte","X2cell","X4cell","X8cell","morula","ICM","TE","EpiE65","ExeE65")),ordered=TRUE)
geneJSscoreVec <- geneJSscoreVec[order(geneJSscoreVec[,2],geneJSscoreVec[,1],decreasing=TRUE),]

pcmatchIndexes <- grep('protein_coding',geneInfo[,2])
pcmatchIndexes <- match(geneInfo[pcmatchIndexes,1],rownames(geneJSscoreVec))
pcmatchIndexes <- pcmatchIndexes[which(!is.na(pcmatchIndexes))]
pcJSscoreVec <- geneJSscoreVec[pcmatchIndexes,]
pcJSscoreVec <- pcJSscoreVec[order(pcJSscoreVec[,2],pcJSscoreVec[,1],decreasing=TRUE),]
write.table(pcJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_lowscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(pcJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/proteincoding_stage_specific_l0.3_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()

lncRNAmatchIndexes <- grep('processed_transcript|lincRNA|3prime_overlapping_ncrna|antisense|non_coding|sense_intronic|sense_overlapping|TEC|known_ncrna|macro_lncRNA|bidirectional_promoter_lncrna',geneInfo[,2])
lncRNAmatchIndexes <- match(geneInfo[lncRNAmatchIndexes,1],rownames(geneJSscoreVec))
lncRNAmatchIndexes <- lncRNAmatchIndexes[which(!is.na(lncRNAmatchIndexes))]
lncRNAJSscoreVec <- geneJSscoreVec[lncRNAmatchIndexes,]
lncRNAJSscoreVec <- lncRNAJSscoreVec[order(lncRNAJSscoreVec[,2],lncRNAJSscoreVec[,1],decreasing=TRUE),]
write.table(lncRNAJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_lowscores_GSR.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(rownames(lncRNAJSscoreVec),rownames(geneExpData))
expData <- geneExpData[matchIndexes,]
plotData <- t(apply(expData,1,scaleNorm))
colnames(plotData) <- colnames(expData)
library(pheatmap)
library(RColorBrewer)
pdf(file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_l0.3_heatmap_GSR.pdf",width=10,height=15)
pheatmap(plotData,scale="row",cluster_rows=FALSE,cluster_cols=FALSE,show_rownames=FALSE,show_colnames=TRUE,color = colorRampPalette(c("#1E90FF","#FFFFF0","#FF00FF"))(100),fontsize=4)
dev.off()
