#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J bismark
#SBATCH -c 1
#SBATCH --mem 100G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/METH/index.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/METH/index.err

cd /storage/gbcl/qiaolu/EpiData/METH

module load bowtie/2.4.2

/storage/gbcl/qiaolu/Bismark-0.23.0/bismark_genome_preparation --verbose /storage/gbcl/qiaolu/SNPsplit_genome_pre/DBA2J-Nmasked