library(pheatmap)
library(wesanderson)
library(dendextend)

expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/enhancer_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(expData) <- expData[,1]
sampInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/run2samplename.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
sampInfo[,3] <- factor(sampInfo[,3],levels=c("MII_oocyte_rep1","MII_oocyte_rep2","zygote_rep1","zygote_rep2","early_2-cell_rep1","early_2-cell_rep2","2-cell_rep1","2-cell_rep2","4-cell_rep1","4-cell_rep2","8-cell_rep1","8-cell_rep2","ICM_rep1","ICM_rep2","ICM_rep5"),ordered=TRUE)
sampInfo <- sampInfo[order(sampInfo[,3]),]
matchIndexes <- match(sampInfo[,1],colnames(expData))
expData <- expData[,matchIndexes]
colnames(expData) <- as.character(sampInfo[,3])
expData <- expData[which(rowSums(expData) > 0),]
seven.colors <- c(rev(wes_palette("Zissou1",6,type = "continuous")),"darkslateblue")

pdf(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/enhancer_expr_sample_cluster_res_XW.pdf",width=10,height=15)
p <- pheatmap(expData,show_rownames=FALSE,scale="row",cluster_rows=FALSE,cluster_cols=TRUE,clustering_distance_cols="correlation",fontsize=10)
p.dend <- as.dendrogram(p$tree_col)
p.dend <- reorder(p.dend,seq(1,45,3),agglo.FUN=mean)
p.dend %>% set("labels_color",c(rep(seven.colors[7],2),rep(seven.colors[6:1],c(2,2,2,2,2,3)))) %>% set("hang") %>% set("branches_k_col", k = 2) %>% plot()
dev.off()
