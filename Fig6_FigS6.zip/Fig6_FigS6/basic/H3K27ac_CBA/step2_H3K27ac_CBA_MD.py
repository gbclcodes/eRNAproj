#!/usr/bin/env python

import os
import shutil
import glob

def mkdir_p(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)
    
# Make top level directories
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/metrics")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/first_sort")

data_directory = "/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_SNP"

os.chdir("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/mapping")
files = glob.glob("*_mapping.bam")

job = ""
for file in files:
    file_name = file[:10]

    job += "samtools sort %s/%s/%s_mapping.genome1.bam > %s.genome1.sorted.bam\n" % (data_directory, file_name, file_name, file_name)
    job += "samtools index %s.genome1.sorted.bam\n" % file_name
    job += "java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=%s.genome1.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result/%s.genome1.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/metrics/%s.genome1.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n" % (file_name, file_name, file_name)
    job += "samtools sort %s/%s/%s_mapping.genome2.bam > %s.genome2.sorted.bam\n" % (data_directory, file_name, file_name, file_name)
    job += "samtools index %s.genome2.sorted.bam\n" % file_name
    job += "java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=%s.genome2.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result/%s.genome2.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/metrics/%s.genome2.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n" % (file_name, file_name, file_name)

with open("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/H3K27ac_CBA_MD.bash", "w") as fh:
    fh.writelines("#!/bin/bash\n")
    fh.writelines("#SBATCH -p amd-ep2\n")
    fh.writelines("#SBATCH -q normal\n")
    fh.writelines("#SBATCH -J MD\n")
    fh.writelines("#SBATCH -c 1\n")
    fh.writelines("#SBATCH --mem 100G\n")
    fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/MD.log\n")
    fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/MD.err\n")
    fh.writelines("cd /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD\n")
    fh.writelines("module load samtools/1.14\n")
    fh.writelines(job)

