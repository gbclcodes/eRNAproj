#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J SRR3336430
#SBATCH -c 1
#SBATCH --mem 100G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/SRR3336430.out
#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/SRR3336430.err
cd /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/mapping

module load bowtie/2.4.2 
bowtie2 -t -q -N 1 -L 25 -X 2000 --no-mixed --no-discordant -x PWK_6J -1 /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/SRR3336430_1.fastq -2 /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/SRR3336430_2.fastq -S SRR3336430_mapping.sam 


