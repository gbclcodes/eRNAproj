#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$hisat2indexdir,$hisat2dir,$picarddir,$stringtiedir,$gfffile,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"stringtiedir=s" => \$stringtiedir,
	"gfffile|gff=s" => \$gfffile,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @sample_p1s = `find $inputdir -name "*_1.clean.fq.gz"`;
print join("\n",@sample_p1s)."\n";
foreach my $sample_p1 (@sample_p1s){
	chomp $sample_p1;
	$sample_p1 =~ /.*\/(.*).fq.gz/;
	my $sample_id = $1;
	my $sample_p2 = $sample_p1;
	$sample_p2 =~ s/_1.clean.fq.gz/_2.clean.fq.gz/;
	
    if(!-e "$outputdir/$stringtiedir/$sample_id"){
		mkpath("$outputdir/$stringtiedir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$stringtiedir/$sample_id failed:\n$@";
			exit(1);
		}
	}
	
	open(SH,">$outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh") or die "$!\n";
	
	if(!-e "$outputdir/$stringtiedir/$sample_id/htseq_count.txt" || -z "$outputdir/$stringtiedir/$sample_id/htseq_count.txt"){
		print SH "stringtie -p $threads -e -B -G $gfffile -A $outputdir/$stringtiedir/$sample_id/gene_abund.tab -o $outputdir/$stringtiedir/$sample_id/transcripts.gtf $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
	}
    
    open OUT,">$outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $sample_id			
#SBATCH -c 4
#SBATCH --mem 20G
#SBATCH -o $outputdir/$hisat2dir/$sample_id/%j.log
#SBATCH -e $outputdir/$hisat2dir/$sample_id/%j.err

date
source ~/.bashrc
module load hisat/2.2.1
module load samtools/1.14
module load stringtie/2.1.5
sh $outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh
date
EOF
	close OUT;
	my $sb = `sbatch $outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl mapping_and_expcal.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/InhouseRNAseqData --outputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/InhouseRNAseqData --hisat2indexdir /storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/mousehisat2Index/GRCm38 --picarddir /storage/gbcl/yuhua/yuhua_projects/enhProj/software/picard-2.18.2 --hisat2dir hisat2file --stringtiedir stringtie --gfffile /storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/gencode.vM17.annotation.gff3 --threads 2
