library(clusterProfiler)
library(org.Mm.eg.db)

# GSR
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])
stageNames <- stageNames[seq(1,3)]
enhNums <- c()
TFNums <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	enhNums <- c(enhNums,length(unique(tf.enh.pairs[which(!is.na(matchIndexes)),1])))
	TFNums <- c(TFNums,length(unique(tf.enh.pairs[which(!is.na(matchIndexes)),2])))
}

num <- c(TFNums,enhNums)
celltype <- rep(c("MIIOocyte","X2cell","X4cell"),2)
genetype <- rep(c("G","E"),each=3)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("MIIOocyte","X2cell","X4cell"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/TF_num_developmental_stage_group_barplot_GSR.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge()) + scale_fill_manual(values = q4[c(1,2)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()