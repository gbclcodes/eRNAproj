library(ggplot2)
library(RColorBrewer)

BRD4Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
BRD4Data <- BRD4Data[,3:ncol(BRD4Data)]
BRD4SEData <- as.numeric(BRD4Data[1,])
BRD4TEData <- as.numeric(BRD4Data[2,])

yvalues <- as.numeric(c(BRD4SEData,BRD4TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

q4 = brewer.pal(4,'Set1')
pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/BRD4_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

BRG1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
BRG1Data <- BRG1Data[,3:ncol(BRG1Data)]
BRG1SEData <- as.numeric(BRG1Data[3,])
BRG1TEData <- as.numeric(BRG1Data[4,])

yvalues <- as.numeric(c(BRG1SEData,BRG1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/BRG1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

CBPData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
CBPData <- CBPData[,3:ncol(CBPData)]
CBPSEData <- as.numeric(CBPData[5,])
CBPTEData <- as.numeric(CBPData[6,])

yvalues <- as.numeric(c(CBPSEData,CBPTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/CBP_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

CHD7Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
CHD7Data <- CHD7Data[,3:ncol(CHD7Data)]
CHD7SEData <- as.numeric(CHD7Data[7,])
CHD7TEData <- as.numeric(CHD7Data[8,])

yvalues <- as.numeric(c(CHD7SEData,CHD7TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/CHD7_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

HDAC1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
HDAC1Data <- HDAC1Data[,3:ncol(HDAC1Data)]
HDAC1SEData <- as.numeric(HDAC1Data[11,])
HDAC1TEData <- as.numeric(HDAC1Data[12,])

HDAC2Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
HDAC2Data <- HDAC2Data[,3:ncol(HDAC2Data)]
HDAC2SEData <- as.numeric(HDAC2Data[13,])
HDAC2TEData <- as.numeric(HDAC2Data[14,])

HDACSEData <- (HDAC1SEData + HDAC2SEData)/2
HDACTEData <- (HDAC1TEData + HDAC2TEData)/2

yvalues <- as.numeric(c(HDACSEData,HDACTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/HDAC_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

LSD1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
LSD1Data <- LSD1Data[,3:ncol(LSD1Data)]
LSD1SEData <- as.numeric(LSD1Data[15,])
LSD1TEData <- as.numeric(LSD1Data[16,])

yvalues <- as.numeric(c(LSD1SEData,LSD1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/LSD1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

MBD3Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
MBD3Data <- MBD3Data[,3:ncol(MBD3Data)]
MBD3SEData <- as.numeric(MBD3Data[17,])
MBD3TEData <- as.numeric(MBD3Data[18,])

yvalues <- as.numeric(c(MBD3SEData,MBD3TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/MBD3_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

MED12Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
MED12Data <- MED12Data[,3:ncol(MED12Data)]
MED12SEData <- as.numeric(MED12Data[19,])
MED12TEData <- as.numeric(MED12Data[20,])

yvalues <- as.numeric(c(MED12SEData,MED12TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/MED12_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

MED1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
MED1Data <- MED1Data[,3:ncol(MED1Data)]
MED1SEData <- as.numeric(MED1Data[21,])
MED1TEData <- as.numeric(MED1Data[22,])

yvalues <- as.numeric(c(MED1SEData,MED1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/MED1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

MI2BData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
MI2BData <- MI2BData[,3:ncol(MI2BData)]
MI2BSEData <- as.numeric(MI2BData[23,])
MI2BTEData <- as.numeric(MI2BData[24,])

yvalues <- as.numeric(c(MI2BSEData,MI2BTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/MI2B_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

NIPBLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
NIPBLData <- NIPBLData[,3:ncol(NIPBLData)]
NIPBLSEData <- as.numeric(NIPBLData[25,])
NIPBLTEData <- as.numeric(NIPBLData[26,])

yvalues <- as.numeric(c(NIPBLSEData,NIPBLTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/NIPBL_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

P300Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
P300Data <- P300Data[,3:ncol(P300Data)]
P300SEData <- as.numeric(P300Data[27,])
P300TEData <- as.numeric(P300Data[28,])

yvalues <- as.numeric(c(P300SEData,P300TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/P300_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

SMC1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
SMC1Data <- SMC1Data[,3:ncol(SMC1Data)]
SMC1SEData <- as.numeric(SMC1Data[29,])
SMC1TEData <- as.numeric(SMC1Data[30,])

yvalues <- as.numeric(c(SMC1SEData,SMC1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/CFCR/SMC1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()
