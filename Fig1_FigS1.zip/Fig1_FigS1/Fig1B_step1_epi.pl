#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$htseqdir,$gfffile,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"htseqdir=s" => \$htseqdir,
	"gfffile|gff=s" => \$gfffile,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*.bam"`;
print join("\n",@samples)."\n";
foreach my $sample (@samples){
	chomp $sample;
	$sample =~ /.*\/(.*).bam/;
	my $sample_id = $1;
    
	if(!-e "$outputdir/$htseqdir/$sample_id"){
		mkpath("$outputdir/$htseqdir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$htseqdir/$sample_id failed:\n";
			exit(1);
		}
	}
    
	open(SH,">$outputdir/$htseqdir/$sample_id/${sample_id}_expcal.sh") or die "$!\n";
    if(!-e "$outputdir/$htseqdir/$sample_id/htseq_count.txt" || -z "$outputdir/$htseqdir/$sample_id/htseq_count.txt"){
		print SH "htseq-count -f bam -s no -i ID -t gene --nonunique all -q $sample $gfffile > $outputdir/$htseqdir/$sample_id/htseq_count.txt\n";
	}
	close SH;
    
    my $taskNum =`ps -aux | grep expcal.sh | wc -l`; 
    while($taskNum > 5){
        print "The num of task remaining $taskNum\n";
        sleep 30;
        print `date`;
        $taskNum = `ps -aux | grep expcal.sh | wc -l`;
    }
    
	my $out = system("sh $outputdir/$htseqdir/$sample_id/${sample_id}_expcal.sh 1>>$outputdir/$htseqdir/$sample_id/std.log 2>>$outputdir/$htseqdir/$sample_id/error.log &");
    
	if($out==0){
		print "The task of $sample_id is successfully submitted\n";
	}
}

# perl fig1f_step1_epi.pl --inputdir /media/yuhua/yuhua_projects/enhProj/XWData/ATACseqData_XW --outputdir /media/yuhua/yuhua_projects/enhProj/ENHData --htseqdir htseqcountfile_XW_ATAC --gfffile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.gff3 --threads 2  

# perl fig1f_step1_epi.pl --inputdir /media/yuhua/yuhua_projects/enhProj/LFData/DNase_LF --outputdir /media/yuhua/yuhua_projects/enhProj/ENHData --htseqdir htseqcountfile_LF_DNase --gfffile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.gff3 --threads 2 

# perl fig1f_step1_epi.pl --inputdir /media/yuhua/yuhua_projects/enhProj/GSRData/H3K9me3_GSR --outputdir /media/yuhua/yuhua_projects/enhProj/ENHData --htseqdir htseqcountfile_GSR_H3K9me3 --gfffile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.gff3 --threads 2

# perl fig1f_step1_epi.pl --inputdir /media/yuhua/yuhua_projects/enhProj/GSRData/H3K27me3_GSR --outputdir /media/yuhua/yuhua_projects/enhProj/ENHData --htseqdir htseqcountfile_GSR_H3K27me3 --gfffile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.gff3 --threads 2 

# perl fig1f_step1_epi.pl --inputdir /media/yuhua/yuhua_projects/enhProj/XWData/H3K27acData_XW --outputdir /media/yuhua/yuhua_projects/enhProj/ENHData --htseqdir htseqcountfile_XW_H3K27ac --gfffile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.gff3 --threads 2 
