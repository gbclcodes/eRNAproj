high.se <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.se <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.se <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.se <- rbind(high.se,median.se,low.se)

enhIDs <- all.se[which(all.se[,3]=="E2C"),1]

expData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/phenodata/superenhancer_expression_Wu_et_al_study.csv",header=TRUE,stringsAsFactors=FALSE)
matchIndexes <- match(toupper(enhIDs),expData[,1])
expData <- expData[matchIndexes,]
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/phenodata/superenhancer_expression_Wu_et_al_study_E2C.csv",col.names=TRUE,row.names=FALSE)