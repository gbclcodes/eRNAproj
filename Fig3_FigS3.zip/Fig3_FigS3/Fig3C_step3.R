library(igraph)
library(bigSCale)
library(Matrix)

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enh.target.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_signalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
enh.target.pairs.gsr <- enh.target.pairs.gsr[which(enh.target.pairs.gsr[,5] > 0),]

path.gene.nums <- table(enh.target.pairs.gsr[,7])
path.gene.nums <- path.gene.nums[which(path.gene.nums >= 3)]
match.indexes <- match(enh.target.pairs.gsr[,7],names(path.gene.nums))
enh.target.pairs.gsr <- enh.target.pairs.gsr[which(!is.na(match.indexes)),]

enh.ids <- unique(enh.target.pairs.gsr[,1])
target.ids <- unique(enh.target.pairs.gsr[,2])
enh.row.indexes <- match(enh.target.pairs.gsr[,1],c(enh.ids,target.ids))
target.col.indexes <- match(enh.target.pairs.gsr[,2],c(enh.ids,target.ids))

enh.stages <- c()
for (enh.id in enh.ids){
	match.index <- which(enhancer.stages[,1]==enh.id)
	enh.stages <- c(enh.stages,paste0("E",enhancer.stages[match.index,3],collapse=""))
}

match.indexes <- match(target.ids,enh.target.pairs.gsr[,2])
tar.stages <- paste("T",enh.target.pairs.gsr[match.indexes,7],sep="")

enh.target.sp.mat <- sparseMatrix(i=enh.row.indexes,j=target.col.indexes,x=as.numeric(enh.target.pairs.gsr[,5]),symmetric=FALSE,dims=c(length(enh.ids)+length(target.ids),length(enh.ids)+length(target.ids)),dimnames=list(c(enh.ids,target.ids),c(enh.ids,target.ids)))
enh.target.net.graph <- graph.adjacency(enh.target.sp.mat,mode="directed",weighted=TRUE)
enh.target.net.graph <- set_vertex_attr(enh.target.net.graph, V(enh.target.net.graph), name = "stage", value = c(enh.stages,tar.stages))
toCytoscape(G = enh.target.net.graph, file.name = '/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_target_network_GSR_signalpathgenes.json')

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enh.target.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_signalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
enh.target.pairs.gsr <- enh.target.pairs.gsr[which(enh.target.pairs.gsr[,5] > 0),]
 
path.gene.nums <- table(enh.target.pairs.gsr[,7])
path.gene.nums <- path.gene.nums[which(path.gene.nums >= 3)]
match.indexes <- match(enh.target.pairs.gsr[,7],names(path.gene.nums))
enh.target.pairs.gsr <- enh.target.pairs.gsr[which(!is.na(match.indexes)),]

enh.ids <- unique(enh.target.pairs.gsr[,1])
target.ids <- unique(enh.target.pairs.gsr[,2])
enh.row.indexes <- match(enh.target.pairs.gsr[,1],c(enh.ids,target.ids))
target.col.indexes <- match(enh.target.pairs.gsr[,2],c(enh.ids,target.ids))

enh.stages <- c()
for (enh.id in enh.ids){
	match.index <- which(enhancer.stages[,1]==enh.id)
	enh.stages <- c(enh.stages,paste0("E",enhancer.stages[match.index,3],collapse=""))
}

match.indexes <- match(target.ids,enh.target.pairs.gsr[,2])
tar.stages <- paste("T",enh.target.pairs.gsr[match.indexes,7],sep="")

enh.target.sp.mat <- sparseMatrix(i=enh.row.indexes,j=target.col.indexes,x=as.numeric(enh.target.pairs.gsr[,4]),symmetric=FALSE,dims=c(length(enh.ids)+length(target.ids),length(enh.ids)+length(target.ids)),dimnames=list(c(enh.ids,target.ids),c(enh.ids,target.ids)))
enh.target.net.graph <- graph.adjacency(enh.target.sp.mat,mode="directed",weighted=TRUE)
enh.target.net.graph <- set_vertex_attr(enh.target.net.graph, V(enh.target.net.graph), name = "stage", value = c(enh.stages,tar.stages))
toCytoscape(G = enh.target.net.graph, file.name = '/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_target_network_XW_signalpathgenes.json')