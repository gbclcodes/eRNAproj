library(pheatmap)
library(colorspace)
library(ggplot2)

DuxData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPBWData/enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
DuxData <- DuxData[,3:ncol(DuxData)]
Dux2CData <- as.numeric(DuxData[1,])
DuxICMData <- as.numeric(DuxData[2,])

yvalues <- as.numeric(c(Dux2CData,DuxICMData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPBWData/enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()


Zscan4Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPBWData/enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
Zscan4Data <- Zscan4Data[,3:ncol(Zscan4Data)]
Zscan42CData <- as.numeric(Zscan4Data[1,])
Zscan4ICMData <- as.numeric(Zscan4Data[2,])

yvalues <- c(Zscan42CData,Zscan4ICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPBWData/enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()


NanogData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Nanog_enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
NanogData <- NanogData[,3:ncol(NanogData)]
Nanog2CData <- as.numeric(NanogData[1,])
NanogICMData <- as.numeric(NanogData[2,])

yvalues <- c(Nanog2CData,NanogICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Nanog_enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()


Oct4Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Oct4_enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
Oct4Data <- Oct4Data[,3:ncol(Oct4Data)]
Oct42CData <- as.numeric(Oct4Data[1,])
Oct4ICMData <- as.numeric(Oct4Data[2,])

yvalues <- c(Oct42CData,Oct4ICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Oct4_enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()


Sox2Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Sox2_enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
Sox2Data <- Sox2Data[,3:ncol(Sox2Data)]
Sox2CData <- as.numeric(Sox2Data[1,])
Sox2ICMData <- as.numeric(Sox2Data[2,])

yvalues <- c(Sox2CData,Sox2ICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPBWData/Sox2_enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()


CTCFData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/2ClikeESCTCFChIPBWData/2CLC_CTCF_enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
CTCFData <- CTCFData[,3:ncol(CTCFData)]
CTCF2CData <- as.numeric(CTCFData[1,])
CTCFICMData <- as.numeric(CTCFData[2,])

yvalues <- c(CTCF2CData,CTCFICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/2ClikeESCTCFChIPBWData/2CLC_CTCF_enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

CTCFData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/2ClikeESCTCFChIPBWData/ESC_CTCF_enhancer_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
CTCFData <- CTCFData[,3:ncol(CTCFData)]
CTCF2CData <- as.numeric(CTCFData[1,])
CTCFICMData <- as.numeric(CTCFData[2,])

yvalues <- c(CTCF2CData,CTCFICMData)
locations <- rep(seq(1,300),times=2)
grouplabels <- rep(c("X2cell","ICM"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=seq(1,300))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("X2cell","ICM"))

q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf(file="/media/yuhua/yuhua_projects/enhProj/2ClikeESCTCFChIPBWData/ESC_CTCF_enhancer_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(2,1)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()