library(reshape2)
library(plyr)
library(Matrix)
library(foreach)
library(doParallel)

mapBin <- function(vec,binMat){
   vec <- unlist(strsplit(vec,"\t"))
   binIndexes <- binMat[which(binMat[,1] == vec[1] & ((binMat[,2] >= as.numeric(vec[2]) & (binMat[,2]) <= as.numeric(vec[3])) | (binMat[,3] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])) | (binMat[,2] <= as.numeric(vec[2]) & (binMat[,3]) >= as.numeric(vec[3])) | (binMat[,2] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])))),4]
   return(binIndexes)
}

OEvalueCal <- function(enhTarPair,genePosInfo,enhPosInfo,contactMatrix,mapData){
	matchIndexEnh <- match(enhTarPair[1],enhPosInfo[,4])
	matchIndexGene <- match(enhTarPair[2],genePosInfo[,4])
	enhBins <- as.numeric(unlist(sapply(paste(enhPosInfo[matchIndexEnh,1],enhPosInfo[matchIndexEnh,2],enhPosInfo[matchIndexEnh,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
	geneBins <- as.numeric(unlist(sapply(paste(genePosInfo[matchIndexGene,1],genePosInfo[matchIndexGene,2],genePosInfo[matchIndexGene,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
	if(length(enhBins) > 0 && length(geneBins) > 0){
		return(c(sum(contactMatrix[enhBins,geneBins] + t(contactMatrix[geneBins,enhBins]))))
	}
}

# Developmental genes
mapData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
genePosInfo <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/known_genes_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhPosInfo <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_annotation_step6_XW_6column_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

high.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancer.gsr,median.enhancer.gsr,low.enhancer.gsr)

target.stages <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/gene_stage_specific_scores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])
enhTarPairs <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enh_target_pairs_XW_devgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

matchIndexesTar <- match(enhTarPairs[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairs[,1],enhancer.gsr[,1])

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.dev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
enhTarPairsE2C.dev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
enhTarPairsL2C.dev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
enhTarPairsM8C.dev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.dev <- enhTarPairs[matchIndexesPairs,]

cl <- makeCluster(20)
registerDoParallel(cl)

MIIData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatMII <- sparseMatrix(as.numeric(MIIData[,1]), as.numeric(MIIData[,2]), x = as.numeric(MIIData[,3]))
rm(MIIData)
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII.dev[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII.dev[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
save(enhTarPairsOEvecMII,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecMIIXW.dev.RData")

E2CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatE2C <- sparseMatrix(as.numeric(E2CData[,1]), as.numeric(E2CData[,2]), x = as.numeric(E2CData[,3]))
rm(E2CData)
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C.dev[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C.dev[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
save(enhTarPairsOEvecE2C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecE2CXW.dev.RData")

L2CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatL2C <- sparseMatrix(as.numeric(L2CData[,1]), as.numeric(L2CData[,2]), x = as.numeric(L2CData[,3]))
rm(L2CData)
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C.dev[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C.dev[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
save(enhTarPairsOEvecL2C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecL2CXW.dev.RData")

M8CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatM8C <- sparseMatrix(as.numeric(M8CData[,1]), as.numeric(M8CData[,2]), x = as.numeric(M8CData[,3]))
rm(M8CData)
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C.dev[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C.dev[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
save(enhTarPairsOEvecM8C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecM8CXW.dev.RData")

ICMData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatICM <- sparseMatrix(as.numeric(ICMData[,1]), as.numeric(ICMData[,2]), x = as.numeric(ICMData[,3]))
rm(ICMData)
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM.dev[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM.dev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM.dev[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
save(enhTarPairsOEvecICM,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecICMXW.dev.RData")
stopCluster(cl)


# Non-developmental genes
mapData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
genePosInfo <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/known_genes_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhPosInfo <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_annotation_step6_XW_6column_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

high.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancer.gsr <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancer.gsr,median.enhancer.gsr,low.enhancer.gsr)

target.stages <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/gene_stage_specific_scores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])
enhTarPairs <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/enh_target_pairs_XW_nondevgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

matchIndexesTar <- match(enhTarPairs[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairs[,1],high.enhancer.gsr[,1])

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.nondev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
enhTarPairsE2C.nondev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
enhTarPairsL2C.nondev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
enhTarPairsM8C.nondev <- enhTarPairs[matchIndexesPairs,]

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.nondev <- enhTarPairs[matchIndexesPairs,]

cl <- makeCluster(20)
registerDoParallel(cl)

MIIData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatMII <- sparseMatrix(as.numeric(MIIData[,1]), as.numeric(MIIData[,2]), x = as.numeric(MIIData[,3]))
rm(MIIData)
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII.nondev[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII.nondev[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
save(enhTarPairsOEvecMII,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecMIIXW.nondev.RData")

E2CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatE2C <- sparseMatrix(as.numeric(E2CData[,1]), as.numeric(E2CData[,2]), x = as.numeric(E2CData[,3]))
rm(E2CData)
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
save(enhTarPairsOEvecE2C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecE2CXW.nondev.RData")

L2CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatL2C <- sparseMatrix(as.numeric(L2CData[,1]), as.numeric(L2CData[,2]), x = as.numeric(L2CData[,3]))
rm(L2CData)
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
save(enhTarPairsOEvecL2C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecL2CXW.nondev.RData")

M8CData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatM8C <- sparseMatrix(as.numeric(M8CData[,1]), as.numeric(M8CData[,2]), x = as.numeric(M8CData[,3]))
rm(M8CData)
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C.nondev[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
save(enhTarPairsOEvecM8C,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecM8CXW.nondev.RData")

ICMData <- read.table(file="/public/ZhangJinLab/project_enhancer/HiCAnal/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatICM <- sparseMatrix(as.numeric(ICMData[,1]), as.numeric(ICMData[,2]), x = as.numeric(ICMData[,3]))
rm(ICMData)
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM.nondev[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM.nondev),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM.nondev[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
save(enhTarPairsOEvecICM,file="/public/ZhangJinLab/project_enhancer/HiCAnal/enhTarPairOEvecICMXW.nondev.RData")
stopCluster(cl)
