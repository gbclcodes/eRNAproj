#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Path;

my ($enhtarfile,$signalpathgenefile,$outfile,$help);
GetOptions(
	"enhtarfile=s" => \$enhtarfile,
	"signalpathgenefile=s" => \$signalpathgenefile,
	"outfile=s" => \$outfile,
	"help!" => \$help,
);

my (%devHash,%spHash);
open(DEV,"<$signalpathgenefile") or die "$!\n";
while(<DEV>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\t/,$line;
	$devHash{$fieldValues[0]} = uc($fieldValues[1]);
	$fieldValues[3] =~ s/\s+//g;
	$spHash{$fieldValues[0]} =$fieldValues[3];
}
close DEV;

open(ET,"<$enhtarfile") or die "$!\n";
open(OUT,">$outfile") or die "$!\n";
while(<ET>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\s+/,$line;
	if(exists $devHash{$fieldValues[1]}){
		print OUT "$fieldValues[0]\t$devHash{$fieldValues[1]}\t$fieldValues[1]\t$fieldValues[2]\t$fieldValues[5]\t$fieldValues[6]\t$spHash{$fieldValues[1]}\n";
	}
}
close ET;
close OUT;

# perl figS3a_step2.pl --enhtarfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt --signalpathgenefile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/genes_within_kegg_signaling_pathway.txt --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_signalpathgenes.txt

# perl figS3b_step2.pl --enhtarfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt --signalpathgenefile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/genes_within_kegg_signaling_pathway.txt --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_signalpathgenes.txt