#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$bedfile,$type,$help);
GetOptions(
	"inputdir=s" => \$inputdir,
    "bedfile=s" => \$bedfile,
	"type=s" => \$type,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*bigWig"`;
foreach my $sample (@samples){
    chomp $sample;
    $sample =~ /.*\/(.*).bigWig/;
    my $sample_id = $1;
    
	if(!-e "$inputdir/${sample_id}_$type.bed" || -z "$inputdir/${sample_id}_$type.bed"){
		open(SH,">$inputdir/${sample_id}_bigWigAverageOverBed.sh") or die "$!\n";
		print SH "/media/yuhua/yuhua_projects/software/bigWigAverageOverBed $sample $bedfile $inputdir/$sample_id\_$type.tab -bedOut=$inputdir/${sample_id}_$type.bed\n";
		close SH;
		
		my $taskNum =`ps -aux | grep bigWigAverageOverBed | wc -l`; 
		while($taskNum > 20){
			print "The num of task remaining $taskNum\n";
			sleep 30;
			print `date`;
			$taskNum = `ps -aux | grep bigWigAverageOverBed | wc -l`;
		}
		
		my $out = system("sh $inputdir/${sample_id}_bigWigAverageOverBed.sh 1>>$inputdir/${sample_id}_bigWigAverageOverBed.log 2>>$inputdir/${sample_id}_bigWigAverageOverBed.err &");
		if($out==0){
			print "The task of $sample_id is successfully submitted\n";
		}
	}
}

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &

# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_M17_specific_tss.bed --type specific &
# nohup perl calTwoGroupEnhancersEpiSignal.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_overlapwithknown_tss.bed --type common &
