#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J CBA_6J                          
#SBATCH -c 1
#SBATCH --mem 30G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/CBA_6J/index.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/CBA_6J/index.err

cd /storage/gbcl/qiaolu/EpiData/CBA_6J/CBA_J_N-masked
cat chr*.fa > CBA_6J.fa


cd /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA
mkdir mapping

cd /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/mapping

module load bowtie/2.4.2

bowtie2-build /storage/gbcl/qiaolu/EpiData/CBA_6J/CBA_J_N-masked/CBA_6J.fa CBA_6J