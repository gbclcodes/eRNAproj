library(ggplot2)

enh.pos <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",sep=" ",header=TRUE,stringsAsFactors=FALSE)
enh.info <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/ENHData/filtered_mm10_allsources_step1_formated.csv",header=FALSE,stringsAsFactors=FALSE)
match.indexes <- match(paste(enh.info[,1],enh.info[,2],enh.info[,3],sep="-"),paste(enh.pos[,2],enh.pos[,3],enh.pos[,4],sep="-"))
match.indexes <- match.indexes[which(!is.na(match.indexes))]
enh.info <- enh.info[match.indexes,]
perc.table <- table(enh.info[,6])/nrow(enh.info)

# create data frame
data <- data.frame("category" = names(perc.table),
                   "amount" = round(as.numeric(perc.table),digits=2))
data <- data[which(data[,2] >= 0.01),]
data$category <- factor(data$category,levels=c("ATAC","DNase","H3K27ac","EnhancerAtlas","whyte","ATAC-DNase","ATAC-H3K27ac","ATAC-EnhancerAtlas","H3K27ac-EnhancerAtlas"))

library(wesanderson)
pdf(file="/media/yuhua/yuhua_projects/enhProj/ENHData/EnhSourceNumDistri.pdf",width=7,height=5)
p <- ggplot(data, aes(x="", y=amount, fill=category)) +
	geom_bar(stat="identity", width=1) +
	coord_polar("y", start=0) +
	geom_text(aes(label = paste0(amount, "%")), position = position_stack(vjust=0.5)) +
	labs(x = NULL, y = NULL, fill = NULL) +
	theme_classic() +
	theme(axis.line = element_blank(),
		axis.text = element_blank(),
		axis.ticks = element_blank()) + scale_fill_manual(values=wes_palette("Zissou1",9,type = "continuous"))
print(p)
dev.off()


enh.pos <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.txt",sep=" ",header=TRUE,stringsAsFactors=FALSE)
enh.info <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/ENHData/filtered_mm10_allsources_step1_formated.csv",header=FALSE,stringsAsFactors=FALSE)
match.indexes <- match(paste(enh.info[,1],enh.info[,2],enh.info[,3],sep="-"),paste(enh.pos[,2],enh.pos[,3],enh.pos[,4],sep="-"))
match.indexes <- match.indexes[which(!is.na(match.indexes))]
enh.info <- enh.info[match.indexes,]
perc.table <- table(enh.info[,6])/nrow(enh.info)

# create data frame
data <- data.frame("category" = names(perc.table),
                   "amount" = round(as.numeric(perc.table),digits=2))
data <- data[which(data[,2] >= 0.01),]
data$category <- factor(data$category,levels=c("ATAC","DNase","H3K27ac","EnhancerAtlas","whyte","ATAC-DNase","ATAC-H3K27ac","ATAC-EnhancerAtlas","H3K27ac-EnhancerAtlas"))

library(wesanderson)
pdf(file="/media/yuhua/yuhua_projects/enhProj/ENHData/EnhSourceNumDistriXW.pdf",width=7,height=5)
p <- ggplot(data, aes(x="", y=amount, fill=category)) +
	geom_bar(stat="identity", width=1) +
	coord_polar("y", start=0) +
	geom_text(aes(label = paste0(amount, "%")), position = position_stack(vjust=0.5)) +
	labs(x = NULL, y = NULL, fill = NULL) +
	theme_classic() +
	theme(axis.line = element_blank(),
		axis.text = element_blank(),
		axis.ticks = element_blank()) + scale_fill_manual(values=wes_palette("Zissou1",9,type = "continuous"))
print(p)
dev.off()
	