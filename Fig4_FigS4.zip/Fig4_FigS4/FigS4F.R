library(Rtsne)
expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/se_TPM_GSR.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(expData) <- expData[,5]
sampInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/run2samplename.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
sampInfo[,2] <- factor(sampInfo[,2],levels=c("MII-Oocyte_1","MII-Oocyte_2","2-cell_1","2-cell_2","2-cell_3","2-cell_4","4-cell_1","4-cell_2","4-cell_3","4-cell_4","8-cell_1","8-cell_2","8-cell_3","morula_1","morula_2","ICM_1","ICM_2","ICM_3","ICM_4","TE_1","TE_2","TE_3","TE_4","E6.5_Epi_1","E6.5_Epi_2","E6.5_Exe_1","E6.5_Exe_2"),ordered=TRUE)
sampInfo <- sampInfo[order(sampInfo[,2]),]
matchIndexes <- match(sampInfo[,1],colnames(expData))
expData <- expData[,matchIndexes]
colnames(expData) <- as.character(sampInfo[,2])
expData <- expData[,c("MII-Oocyte_1","MII-Oocyte_2","2-cell_1","2-cell_2","2-cell_3","2-cell_4","4-cell_1","4-cell_2","4-cell_3","4-cell_4","8-cell_1","8-cell_3","morula_1","morula_2","ICM_1","ICM_4","TE_1","TE_2","E6.5_Epi_1","E6.5_Epi_2","E6.5_Exe_1","E6.5_Exe_2")]
expData <- expData[which(rowSums(expData) > 0),]

set.seed(42) # Sets seed for reproducibility
tsne_out <- Rtsne(as.matrix(t(expData)),perplexity=1.5,dims=3) # Run TSNE

library(ggplot2)
library(wesanderson)
stageNames <- rep(c("MII-Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E6.5_Epi","E6.5_Exe"),c(2,4,4,2,2,2,2,2,2))
plotdata <- data.frame(x=tsne_out$Y[,1],y=tsne_out$Y[,2],pointColor=stageNames,pointType=rep(seq(14,22,1),c(2,4,4,2,2,2,2,2,2)))
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/se_TPM_GSR_tSNE.pdf",width=6,height=5)
p <- ggplot(plotdata,aes(x=x,y=y,label=colnames(expData),colour=factor(pointColor,levels=c("MII-Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E6.5_Epi","E6.5_Exe")),shape=factor(pointColor,levels=c("MII-Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E6.5_Epi","E6.5_Exe")))) + geom_point(size=3) + scale_shape_manual(values=c(1,2,3,4,5,6,7,8,9)) + scale_color_manual(values = c(rev(wes_palette("Zissou1",8,type = "continuous")),"darkslateblue"))
p <- p + xlab("PC1") + ylab("PC2") + geom_text(hjust=0.5,vjust=1,size=2.5)
p <- p + theme(legend.title=element_blank())

p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()


library(Rtsne)
expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/se_TPM_XW.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(expData) <- expData[,1]
sampInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/run2samplename.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
sampInfo[,3] <- factor(sampInfo[,3],levels=c("MII_oocyte_rep1","MII_oocyte_rep2","zygote_rep1","zygote_rep2","early_2-cell_rep1","early_2-cell_rep2","2-cell_rep1","2-cell_rep2","4-cell_rep1","4-cell_rep2","8-cell_rep1","8-cell_rep2","ICM_rep1","ICM_rep2","ICM_rep5"),ordered=TRUE)
sampInfo <- sampInfo[order(sampInfo[,3]),]
matchIndexes <- match(sampInfo[,1],colnames(expData))
expData <- expData[,matchIndexes]
colnames(expData) <- as.character(sampInfo[,3])
expData <- expData[which(rowSums(expData) > 0),]


set.seed(42) # Sets seed for reproducibility
tsne_out <- Rtsne(as.matrix(t(expData)),perplexity=1.5,dims=3) # Run TSNE

library(ggplot2)
library(wesanderson)
stageNames <- rep(c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM"),c(2,2,2,2,2,2,3))
plotdata <- data.frame(x=tsne_out$Y[,1],y=tsne_out$Y[,2],pointColor=stageNames,pointType=rep(seq(14,20,1),c(2,2,2,2,2,2,3)))
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/se_TPM_XW_tSNE.pdf",width=6,height=5)
p <- ggplot(plotdata,aes(x=x,y=y,label=colnames(expData),colour=factor(pointColor,levels=c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")),shape=factor(pointColor,levels=c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")))) + geom_point(size=3) + scale_shape_manual(values=c(1,2,3,4,5,6,7)) + scale_color_manual(values = c(rev(wes_palette("Zissou1",6,type = "continuous")),"darkslateblue"))
p <- p + xlab("PC1") + ylab("PC2") + geom_text(hjust=0.5,vjust=1,size=2.5)
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()