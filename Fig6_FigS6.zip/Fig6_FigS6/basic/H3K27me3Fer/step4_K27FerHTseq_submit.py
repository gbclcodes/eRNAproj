#!/usr/bin/env python


import os
import shutil
import glob

def mkdir_p(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)
    
job_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/result"

os.chdir("/storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/result")
files = glob.glob("*.bam")

with open("HT_enh.bash", "w") as fh:
    fh.writelines("#!/bin/bash\n")
    fh.writelines("#SBATCH -p amd-ep2\n")
    fh.writelines("#SBATCH -q normal\n")
    fh.writelines("#SBATCH -J HT\n")
    fh.writelines("#SBATCH -c 1\n")
    fh.writelines("#SBATCH --mem 50G\n")
    fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/HT.log\n")
    fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/HT.err\n")
    fh.writelines("cd %s \n" % job_directory)
    fh.writelines("module load python \n")

    for file in files:
        job_name = file[:25]

        fh.writelines("htseq-count -c %s.csv -r pos -f bam -s no -i Name -t BED_feature --nonunique all -q %s enhancer_GSR_new.gff3 \n" % (job_name, file))

os.system("sbatch HT_enh.bash")