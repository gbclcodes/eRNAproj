# GSR
TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_GSR.bed",header=FALSE,stringsAsFactors=FALSE)
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

target.stages <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_devsignalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]

matchIndexes <- match(enhancer.gsr[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

TETarNumVecDev <- c() 
for (TEID in TEData[,4]){
	TETarNumVecDev <- c(TETarNumVecDev,length(which(TENet[,1]==TEID)))
} 

matchIndexesTar <- match(TENet[,3],target.stages[,1])
matchIndexesEnh <- match(TENet[,1],enhancer.gsr[,1])

MIINum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
M2CNum <- length(which(enhancer.gsr[,3]=="X2cell"))
M4CNum <- length(which(enhancer.gsr[,3]=="X4cell"))
M8CNum <- length(which(enhancer.gsr[,3]=="X8cell"))
MorulaNum <- length(which(enhancer.gsr[,3]=="morula"))
ICMNum <- length(which(enhancer.gsr[,3]=="ICM"))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
TENetMII <- TENet[matchIndexesPairs,]
TEMIIDev <- nrow(TENetMII)/MIINum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
TENetX2cell <- TENet[matchIndexesPairs,]
TEX2cellDev <- nrow(TENetX2cell)/M2CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
TENetX4cell <- TENet[matchIndexesPairs,]
TEX4cellDev <- nrow(TENetX4cell)/M4CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
TENetX8cell <- TENet[matchIndexesPairs,]
TEX8cellDev <- nrow(TENetX8cell)/M8CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
TENetMorula <- TENet[matchIndexesPairs,]
TEMorulaDev <- nrow(TENetMorula)/MorulaNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
TENetICM <- TENet[matchIndexesPairs,]
TEICMDev <- nrow(TENetICM)/ICMNum

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]

matchIndexesTar <- match(TENet[,2],target.stages[,1])
matchIndexesEnh <- match(TENet[,1],enhancer.gsr[,1])

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
TENetMII <- TENet[matchIndexesPairs,]
TEMIINonDev <- nrow(TENetMII)/MIINum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
TENetX2cell <- TENet[matchIndexesPairs,]
TEX2cellNonDev <- nrow(TENetX2cell)/M2CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
TENetX4cell <- TENet[matchIndexesPairs,]
TEX4cellNonDev <- nrow(TENetX4cell)/M4CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
TENetX8cell <- TENet[matchIndexesPairs,]
TEX8cellNonDev <- nrow(TENetX8cell)/M8CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
TENetMorula <- TENet[matchIndexesPairs,]
TEMorulaNonDev <- nrow(TENetMorula)/MorulaNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
TENetICM <- TENet[matchIndexesPairs,]
TEICMNonDev <- nrow(TENetICM)/ICMNum

TEMIIGSR <- TEMIIDev/TEMIINonDev
TEX2cellGSR <- TEX2cellDev/TEX2cellNonDev
TEX4cellGSR <- TEX4cellDev/TEX4cellNonDev
TEX8cellGSR <- TEX8cellDev/TEX8cellNonDev
TEMorulaGSR <- TEMorulaDev/TEMorulaNonDev
TEICMGSR <- TEICMDev/TEICMNonDev

TETarNumVecNonDev <- c() 
for (TEID in TEData[,4]){
	TETarNumVecNonDev <- c(TETarNumVecNonDev,length(which(TENet[,1]==TEID)))
}
TETarRatio <- (TETarNumVecDev + 1)/(TETarNumVecNonDev + 1)

TETarRatio <- TETarRatio[which(TETarNumVecNonDev > 0)]
TEData <- TEData[which(TETarNumVecNonDev > 0),]
matchIndexes <- match(TEData[,4],enhancer.gsr[,1])

TEStage <- enhancer.gsr[matchIndexes,3]
matchIndexesMII <- which(TEStage=="MIIOocyte")
TEMIIGSRSEM <- sd(TETarRatio[matchIndexesMII])/sqrt(length(matchIndexesMII))
matchIndexesX2cell <- which(TEStage=="X2cell")
TEX2cellGSRSEM <- sd(TETarRatio[matchIndexesX2cell])/sqrt(length(matchIndexesX2cell))
matchIndexesX4cell <- which(TEStage=="X4cell")
TEX4cellGSRSEM <- sd(TETarRatio[matchIndexesX4cell])/sqrt(length(matchIndexesX4cell))
matchIndexesX8cell <- which(TEStage=="X8cell")
TEX8cellGSRSEM <- sd(TETarRatio[matchIndexesX8cell])/sqrt(length(matchIndexesX8cell))
matchIndexesMorula <- which(TEStage=="morula")
TEMorulaGSRSEM <- sd(TETarRatio[matchIndexesMorula])/sqrt(length(matchIndexesMorula))
matchIndexesICM <- which(TEStage=="ICM")
TEICMGSRSEM <- sd(TETarRatio[matchIndexesICM])/sqrt(length(matchIndexesICM))

SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_GSR_devsignalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

matchIndexes <- match(enhancer.gsr[,1],SEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

matchIndexesTar <- match(SENet[,3],target.stages[,1])
matchIndexesEnh <- match(SENet[,1],enhancer.gsr[,1])

MIINum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
M2CNum <- length(which(enhancer.gsr[,3]=="X2cell"))
M4CNum <- length(which(enhancer.gsr[,3]=="X4cell"))
M8CNum <- length(which(enhancer.gsr[,3]=="X8cell"))
MorulaNum <- length(which(enhancer.gsr[,3]=="morula"))
ICMNum <- length(which(enhancer.gsr[,3]=="ICM"))

SETarNumVecDev <- c() 
for (SEID in SEData[,4]){
	SETarNumVecDev <- c(SETarNumVecDev,length(which(SENet[,1]==SEID)))
} 

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
SENetMII <- SENet[matchIndexesPairs,]
SEMIIDev <- nrow(SENetMII)/MIINum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
SENetX2cell <- SENet[matchIndexesPairs,]
SEX2cellDev <- nrow(SENetX2cell)/M2CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
SENetX4cell <- SENet[matchIndexesPairs,]
SEX4cellDev <- nrow(SENetX4cell)/M4CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
SENetX8cell <- SENet[matchIndexesPairs,]
SEX8cellDev <- nrow(SENetX8cell)/M8CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
SENetMorula <- SENet[matchIndexesPairs,]
SEMorulaDev <- nrow(SENetMorula)/MorulaNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
SENetICM <- SENet[matchIndexesPairs,]
SEICMDev <- nrow(SENetICM)/ICMNum

SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_GSR_all.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

matchIndexes <- match(enhancer.gsr[,1],SEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

matchIndexesTar <- match(SENet[,2],target.stages[,1])
matchIndexesEnh <- match(SENet[,1],enhancer.gsr[,1])

MIINum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
M2CNum <- length(which(enhancer.gsr[,3]=="X2cell"))
M4CNum <- length(which(enhancer.gsr[,3]=="X4cell"))
M8CNum <- length(which(enhancer.gsr[,3]=="X8cell"))
MorulaNum <- length(which(enhancer.gsr[,3]=="morula"))
ICMNum <- length(which(enhancer.gsr[,3]=="ICM"))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
SENetMII <- SENet[matchIndexesPairs,]
SEMIINonDev <- nrow(SENetMII)/MIINum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
SENetX2cell <- SENet[matchIndexesPairs,]
SEX2cellNonDev <- nrow(SENetX2cell)/M2CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
SENetX4cell <- SENet[matchIndexesPairs,]
SEX4cellNonDev <- nrow(SENetX4cell)/M4CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
SENetX8cell <- SENet[matchIndexesPairs,]
SEX8cellNonDev <- nrow(SENetX8cell)/M8CNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
SENetMorula <- SENet[matchIndexesPairs,]
SEMorulaNonDev <- nrow(SENetMorula)/MorulaNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
SENetICM <- SENet[matchIndexesPairs,]
SEICMNonDev <- nrow(SENetICM)/ICMNum

SEMIIGSR <- SEMIIDev/SEMIINonDev
SEX2cellGSR <- SEX2cellDev/SEX2cellNonDev
SEX4cellGSR <- SEX4cellDev/SEX4cellNonDev
SEX8cellGSR <- SEX8cellDev/SEX8cellNonDev
SEMorulaGSR <- SEMorulaDev/SEMorulaNonDev
SEICMGSR <- SEICMDev/SEICMNonDev

SETarNumVecNonDev <- c() 
for (SEID in SEData[,4]){
	SETarNumVecNonDev <- c(SETarNumVecNonDev,length(which(SENet[,1]==SEID)))
}
SETarRatio <- (SETarNumVecDev + 1)/(SETarNumVecNonDev + 1)

SETarRatio <- SETarRatio[which(SETarNumVecNonDev > 0)]
SEData <- SEData[which(SETarNumVecNonDev > 0),]
matchIndexes <- match(SEData[,4],enhancer.gsr[,1])

TETarRatio <- TETarRatio[which(!is.na(TETarRatio))]
SETarRatio <- SETarRatio[which(!is.na(SETarRatio))]
res <- wilcox.test(TETarRatio,SETarRatio)
cat(res$p.value,"\n")

SEStage <- enhancer.gsr[matchIndexes,3]
matchIndexesMII <- which(SEStage=="MIIOocyte")
SEMIIGSRSEM <- sd(SETarRatio[matchIndexesMII])/sqrt(length(matchIndexesMII))
matchIndexesX2cell <- which(SEStage=="X2cell")
SEX2cellGSRSEM <- sd(SETarRatio[matchIndexesX2cell])/sqrt(length(matchIndexesX2cell))
matchIndexesX4cell <- which(SEStage=="X4cell")
SEX4cellGSRSEM <- sd(SETarRatio[matchIndexesX4cell])/sqrt(length(matchIndexesX4cell))
matchIndexesX8cell <- which(SEStage=="X8cell")
SEX8cellGSRSEM <- sd(SETarRatio[matchIndexesX8cell])/sqrt(length(matchIndexesX8cell))
matchIndexesMorula <- which(SEStage=="morula")
SEMorulaGSRSEM <- sd(SETarRatio[matchIndexesMorula])/sqrt(length(matchIndexesMorula))
matchIndexesICM <- which(SEStage=="ICM")
SEICMGSRSEM <- sd(SETarRatio[matchIndexesICM])/sqrt(length(matchIndexesICM)) 

# XW
TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_XW.bed",header=FALSE,stringsAsFactors=FALSE)
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

matchIndexes <- match(enhancer.gsr[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

target.stages <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_devsignalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]

TETarNumVecDev <- c() 
for (TEID in TEData[,4]){
	TETarNumVecDev <- c(TETarNumVecDev,length(which(TENet[,1]==TEID)))
}

matchIndexesTar <- match(TENet[,3],target.stages[,1])
matchIndexesEnh <- match(TENet[,1],enhancer.gsr[,1])

MIIDevNum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
ZygoteDevNum <- length(which(enhancer.gsr[,3]=="Zygote"))
E2CDevNum <- length(which(enhancer.gsr[,3]=="E2C"))
M2CDevNum <- length(which(enhancer.gsr[,3]=="L2C"))
M4CDevNum <- length(which(enhancer.gsr[,3]=="M4C"))
M8CDevNum <- length(which(enhancer.gsr[,3]=="M8C"))
ICMDevNum <- length(which(enhancer.gsr[,3]=="ICM")) 

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
TENetMII <- TENet[matchIndexesPairs,]
TEMIIDev <- nrow(TENetMII)/MIIDevNum 

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
TENetZygote <- TENet[matchIndexesPairs,]
TEZygoteDev <- nrow(TENetZygote)/ZygoteDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
TENetE2C <- TENet[matchIndexesPairs,]
TEE2CDev <- nrow(TENetE2C)/E2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
TENetM2C <- TENet[matchIndexesPairs,]
TEM2CDev <- nrow(TENetM2C)/M2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
TENetM4C <- TENet[matchIndexesPairs,]
TEM4CDev <- nrow(TENetM4C)/M4CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
TENetM8C <- TENet[matchIndexesPairs,]
TEM8CDev <- nrow(TENetM8C)/M8CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
TENetICM <- TENet[matchIndexesPairs,]
TEICMDev <- nrow(TENetICM)/ICMDevNum

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]

matchIndexesTar <- match(TENet[,2],target.stages[,1])
matchIndexesEnh <- match(TENet[,1],enhancer.gsr[,1])

MIINonDevNum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
ZygoteNonDevNum <- length(which(enhancer.gsr[,3]=="Zygote"))
E2CNonDevNum <- length(which(enhancer.gsr[,3]=="E2C"))
M2CNonDevNum <- length(which(enhancer.gsr[,3]=="L2C"))
M4CNonDevNum <- length(which(enhancer.gsr[,3]=="M4C"))
M8CNonDevNum <- length(which(enhancer.gsr[,3]=="M8C"))
ICMNonDevNum <- length(which(enhancer.gsr[,3]=="ICM"))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
TENetMII <- TENet[matchIndexesPairs,]
TEMIINonDev <- nrow(TENetMII)/MIINonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
TENetZygote <- TENet[matchIndexesPairs,]
TEZygoteNonDev <- nrow(TENetZygote)/ZygoteNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
TENetE2C <- TENet[matchIndexesPairs,]
TEE2CNonDev <- nrow(TENetE2C)/E2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
TENetM2C <- TENet[matchIndexesPairs,]
TEM2CNonDev <- nrow(TENetM2C)/M2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
TENetM4C <- TENet[matchIndexesPairs,]
TEM4CNonDev <- nrow(TENetM4C)/M4CNonDevNum 

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
TENetM8C <- TENet[matchIndexesPairs,]
TEM8CNonDev <- nrow(TENetM8C)/M8CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
TENetICM <- TENet[matchIndexesPairs,]
TEICMNonDev <- nrow(TENetICM)/ICMNonDevNum

TEMIIXW <- TEMIIDev/TEMIINonDev
TEZygoteXW <- TEZygoteDev/TEZygoteNonDev
TEE2CXW <- TEE2CDev/TEE2CNonDev
TEM2CXW <- TEE2CDev/TEM2CNonDev
TEM4CXW <- TEM4CDev/TEM4CNonDev
TEM8CXW <- TEM8CDev/TEM8CNonDev
TEICMXW <- TEICMDev/TEICMNonDev

TETarNumVecNonDev <- c() 
for (TEID in TEData[,4]){
	TETarNumVecNonDev <- c(TETarNumVecNonDev,length(which(TENet[,1]==TEID)))
}
TETarRatio <- (TETarNumVecDev + 1)/(TETarNumVecNonDev + 1)

TETarRatio <- TETarRatio[which(TETarNumVecNonDev > 0)]
TEData <- TEData[which(TETarNumVecNonDev > 0),]
matchIndexes <- match(TEData[,4],enhancer.gsr[,1])
TEStage <- enhancer.gsr[matchIndexes,3]
matchIndexesMII <- which(TEStage=="MIIOocyte")
TEMIIXWSEM <- sd(TETarRatio[matchIndexesMII])/sqrt(length(matchIndexesMII))
matchIndexesZygote <- which(TEStage=="Zygote")
TEZygoteXWSEM <- sd(TETarRatio[matchIndexesZygote])/sqrt(length(matchIndexesZygote))
matchIndexesE2C <- which(TEStage=="E2C")
TEE2CXWSEM <- sd(TETarRatio[matchIndexesE2C])/sqrt(length(matchIndexesE2C))
matchIndexesL2C <- which(TEStage=="L2C")
TEE2CXWSEM <- sd(TETarRatio[matchIndexesL2C])/sqrt(length(matchIndexesL2C))
matchIndexesM4C <- which(TEStage=="M4C")
TEM4CXWSEM <- sd(TETarRatio[matchIndexesM4C])/sqrt(length(matchIndexesM4C))
matchIndexesM8C <- which(TEStage=="M8C")
TEM8CXWSEM <- sd(TETarRatio[matchIndexesM8C])/sqrt(length(matchIndexesM8C))
matchIndexesICM <- which(TEStage=="ICM")
TEICMXWSEM <- sd(TETarRatio[matchIndexesICM])/sqrt(length(matchIndexesICM)) 

SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_devsignalpathgenes.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

matchIndexes <- match(enhancer.gsr[,1],SEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

SETarNumVecDev <- c() 
for (SEID in SEData[,4]){
	SETarNumVecDev <- c(SETarNumVecDev,length(which(SENet[,1]==SEID)))
} 

matchIndexesTar <- match(SENet[,3],target.stages[,1])
matchIndexesEnh <- match(SENet[,1],enhancer.gsr[,1])

MIIDevNum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
ZygoteDevNum <- length(which(enhancer.gsr[,3]=="Zygote"))
E2CDevNum <- length(which(enhancer.gsr[,3]=="E2C"))
M2CDevNum <- length(which(enhancer.gsr[,3]=="L2C"))
M4CDevNum <- length(which(enhancer.gsr[,3]=="M4C"))
M8CDevNum <- length(which(enhancer.gsr[,3]=="M8C"))
ICMDevNum <- length(which(enhancer.gsr[,3]=="ICM"))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
SENetMII <- SENet[matchIndexesPairs,]
SEMIIDev <- nrow(SENetMII)/MIIDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
SENetZygote <- SENet[matchIndexesPairs,]
SEZygoteDev <- nrow(SENetZygote)/ZygoteDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
SENetE2C <- SENet[matchIndexesPairs,]
SEE2CDev <- nrow(SENetE2C)/E2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
SENetM2C <- SENet[matchIndexesPairs,]
SEM2CDev <- nrow(SENetM2C)/M2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
SENetM4C <- SENet[matchIndexesPairs,]
SEM4CDev <- nrow(SENetM4C)/M4CDevNum 

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
SENetM8C <- SENet[matchIndexesPairs,]
SEM8CDev <- nrow(SENetM8C)/M8CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
SENetICM <- SENet[matchIndexesPairs,]
SEICMDev <- nrow(SENetICM)/ICMDevNum

SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

matchIndexes <- match(enhancer.gsr[,1],SEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
enhancer.gsr <- enhancer.gsr[matchIndexes,]

matchIndexesTar <- match(SENet[,2],target.stages[,1])
matchIndexesEnh <- match(SENet[,1],enhancer.gsr[,1])

MIINonDevNum <- length(which(enhancer.gsr[,3]=="MIIOocyte"))
ZygoteNonDevNum <- length(which(enhancer.gsr[,3]=="Zygote"))
E2CNonDevNum <- length(which(enhancer.gsr[,3]=="E2C"))
M2CNonDevNum <- length(which(enhancer.gsr[,3]=="L2C"))
M4CNonDevNum <- length(which(enhancer.gsr[,3]=="M4C"))
M8CNonDevNum <- length(which(enhancer.gsr[,3]=="M8C"))
ICMNonDevNum <- length(which(enhancer.gsr[,3]=="ICM"))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
SENetMII <- SENet[matchIndexesPairs,]
SEMIINonDev <- nrow(SENetMII)/MIINonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
SENetZygote <- SENet[matchIndexesPairs,]
SEZygoteNonDev <- nrow(SENetZygote)/ZygoteNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
SENetE2C <- SENet[matchIndexesPairs,]
SEE2CNonDev <- nrow(SENetE2C)/E2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
SENetM2C <- SENet[matchIndexesPairs,]
SEM2CNonDev <- nrow(SENetM2C)/M2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
SENetM4C <- SENet[matchIndexesPairs,]
SEM4CNonDev <- nrow(SENetM4C)/M4CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
SENetM8C <- SENet[matchIndexesPairs,]
SEM8CNonDev <- nrow(SENetM8C)/M8CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
SENetICM <- SENet[matchIndexesPairs,]
SEICMNonDev <- nrow(SENetICM)/ICMNonDevNum

SEMIIXW <- SEMIIDev/SEMIINonDev
SEZygoteXW <- SEZygoteDev/SEZygoteNonDev
SEE2CXW <- SEE2CDev/SEE2CNonDev
SEM2CXW <- SEE2CDev/SEM2CNonDev
SEM4CXW <- SEM4CDev/SEM4CNonDev
SEM8CXW <- SEM8CDev/SEM8CNonDev
SEICMXW <- SEICMDev/SEICMNonDev

SETarNumVecNonDev <- c() 
for (SEID in SEData[,4]){
	SETarNumVecNonDev <- c(SETarNumVecNonDev,length(which(SENet[,1]==SEID)))
}
SETarRatio <- (SETarNumVecDev + 1)/(SETarNumVecNonDev + 1)

SETarRatio <- SETarRatio[which(SETarNumVecNonDev > 0)]
SEData <- SEData[which(SETarNumVecNonDev > 0),]

matchIndexes <- match(SEData[,4],enhancer.gsr[,1])
SEStage <- enhancer.gsr[matchIndexes,3]
matchIndexesMII <- which(SEStage=="MIIOocyte")
SEMIIXWSEM <- sd(SETarRatio[matchIndexesMII])/sqrt(length(matchIndexesMII))
matchIndexesZygote <- which(SEStage=="Zygote")
SEZygoteXWSEM <- sd(SETarRatio[matchIndexesZygote])/sqrt(length(matchIndexesZygote))
matchIndexesE2C <- which(SEStage=="E2C")
SEE2CXWSEM <- sd(SETarRatio[matchIndexesE2C])/sqrt(length(matchIndexesE2C))
matchIndexesL2C <- which(SEStage=="L2C")
SEE2CXWSEM <- sd(SETarRatio[matchIndexesL2C])/sqrt(length(matchIndexesL2C))
matchIndexesM4C <- which(SEStage=="M4C")
SEM4CXWSEM <- sd(SETarRatio[matchIndexesM4C])/sqrt(length(matchIndexesM4C))
matchIndexesM8C <- which(SEStage=="M8C")
SEM8CXWSEM <- sd(SETarRatio[matchIndexesM8C])/sqrt(length(matchIndexesM8C))
matchIndexesICM <- which(SEStage=="ICM")
SEICMXWSEM <- sd(SETarRatio[matchIndexesICM])/sqrt(length(matchIndexesICM))

TETarRatio <- TETarRatio[which(!is.na(TETarRatio))] 
SETarRatio <- SETarRatio[which(!is.na(SETarRatio))]
res <- wilcox.test(TETarRatio,SETarRatio)
cat(res$p.value,"\n") 

TEMII <- (TEMIIGSR + TEMIIXW)/2
TEZygote <- TEZygoteXW
TEE2C <- TEE2CXW
TEM2C <- TEX2cellGSR
TEM4C <- (TEX4cellGSR + TEM4CXW)/2
TEM8C <- (TEX8cellGSR + TEM8CXW)/2
TEMorula <- TEMorulaGSR
TEICM <- (TEICMGSR +TEICMXW)/2

SEMII <- (SEMIIGSR + SEMIIXW)/2
SEZygote <- SEZygoteXW
SEE2C <- SEE2CXW
SEM2C <- SEX2cellGSR
SEM4C <- (SEX4cellGSR + SEM4CXW)/2
SEM8C <- (SEX8cellGSR + SEM8CXW)/2
SEMorula <- SEMorulaGSR
SEICM <- (SEICMGSR +SEICMXW)/2

TEMIISEM <- (TEMIIGSRSEM + TEMIIXWSEM)/2
TEZygoteSEM <- TEZygoteXWSEM
TEE2CSEM <- TEE2CXWSEM
TEM2CSEM <- TEX2cellGSRSEM
TEM4CSEM <- (TEX4cellGSRSEM + TEM4CXWSEM)/2
TEM8CSEM <- (TEX8cellGSRSEM + TEM8CXWSEM)/2
TEMorulaSEM <- TEMorulaGSRSEM
TEICMSEM <- (TEICMGSRSEM +TEICMXWSEM)/2

SEMIISEM <- (SEMIIGSRSEM + SEMIIXWSEM)/2
SEZygoteSEM <- SEZygoteXWSEM
SEE2CSEM <- SEE2CXWSEM
SEM2CSEM <- SEX2cellGSRSEM
SEM4CSEM <- (SEX4cellGSRSEM + SEM4CXWSEM)/2
SEM8CSEM <- (SEX8cellGSRSEM + SEM8CXWSEM)/2
SEMorulaSEM <- SEMorulaGSRSEM
SEICMSEM <- (SEICMGSRSEM + SEICMXWSEM)/2

perc <- c(TEMII,TEZygote,TEE2C,TEM2C,TEM4C,TEM8C,TEMorula,TEICM,SEMII,SEZygote,SEE2C,SEM2C,SEM4C,SEM8C,SEMorula,SEICM)
sem <- c(TEMIISEM,TEZygoteSEM,TEE2CSEM,TEM2CSEM,TEM4CSEM,TEM8CSEM,TEMorulaSEM,TEICMSEM,SEMIISEM,SEZygoteSEM,SEE2CSEM,SEM2CSEM,SEM4CSEM,SEM8CSEM,SEMorulaSEM,SEICMSEM)
stage <- c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM","MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM")
type <- c("TE","TE","TE","TE","TE","TE","TE","TE","SE","SE","SE","SE","SE","SE","SE","SE")

statData <- as.data.frame(cbind(perc,sem,stage,type))
colnames(statData) <- c("perc","sem","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$sem <- as.numeric(statData$sem)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("TE","SE"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/DevPathwayRatioTESE.pdf",width=6,height=5)
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
print(p)
dev.off()