# H3K4me1 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/enhancer_density_value.RData") 

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K4me1 lncRNA
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/lncRNA_density_value.RData")

expMeanVec_H3K4me1_lncRNA <- rowMeans(expData)
expMeanMatrix_H3K4me1_lncRNA <- matrix(expMeanVec_H3K4me1_lncRNA,nrow=41)
expMeanMatrix_H3K4me1_lncRNA <- apply(expMeanMatrix_H3K4me1_lncRNA,2,Zscore)
expMeanMatrix_H3K4me1_lncRNA <- expMeanMatrix_H3K4me1_lncRNA[,which(!is.na(colSums(expMeanMatrix_H3K4me1_lncRNA)))]
expPlotVec_H3K4me1_lncRNA <- rowMeans(expMeanMatrix_H3K4me1_lncRNA)
write.table(expPlotVec_H3K4me1_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K4me1 protein coding
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/proteincoding_density_value.RData") 

expMeanVec_H3K4me1_proteincoding <- rowMeans(expData)
expMeanMatrix_H3K4me1_proteincoding <- matrix(expMeanVec_H3K4me1_proteincoding,nrow=41)
expMeanMatrix_H3K4me1_proteincoding <- apply(expMeanMatrix_H3K4me1_proteincoding,2,Zscore)
expMeanMatrix_H3K4me1_proteincoding <- expMeanMatrix_H3K4me1_proteincoding[,which(!is.na(colSums(expMeanMatrix_H3K4me1_proteincoding)))]
expPlotVec_H3K4me1_proteincoding <- rowMeans(expMeanMatrix_H3K4me1_proteincoding)
write.table(expPlotVec_H3K4me1_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac enhancer 
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/enhancer_density_value.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac lncRNA 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/lncRNA_density_value.RData") 

expMeanVec_H3K27ac_lncRNA <- rowMeans(expData)
expMeanMatrix_H3K27ac_lncRNA <- matrix(expMeanVec_H3K27ac_lncRNA,nrow=41)
expMeanMatrix_H3K27ac_lncRNA <- apply(expMeanMatrix_H3K27ac_lncRNA,2,Zscore)
expMeanMatrix_H3K27ac_lncRNA <- expMeanMatrix_H3K27ac_lncRNA[,which(!is.na(colSums(expMeanMatrix_H3K27ac_lncRNA)))]
expPlotVec_H3K27ac_lncRNA <- rowMeans(expMeanMatrix_H3K27ac_lncRNA)
write.table(expPlotVec_H3K27ac_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac proteincoding 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/proteincoding_density_value.RData") 

expMeanVec_H3K27ac_proteincoding <- rowMeans(expData)
expMeanMatrix_H3K27ac_proteincoding <- matrix(expMeanVec_H3K27ac_proteincoding,nrow=41)
expMeanMatrix_H3K27ac_proteincoding <- apply(expMeanMatrix_H3K27ac_proteincoding,2,Zscore)
expMeanMatrix_H3K27ac_proteincoding <- expMeanMatrix_H3K27ac_proteincoding[,which(!is.na(colSums(expMeanMatrix_H3K27ac_proteincoding)))]
expPlotVec_H3K27ac_proteincoding <- rowMeans(expMeanMatrix_H3K27ac_proteincoding)
write.table(expPlotVec_H3K27ac_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/enhancer_density_value.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF lncRNA
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/lncRNA_density_value.RData")

expMeanVec_CTCF_lncRNA <- rowMeans(expData)
expMeanMatrix_CTCF_lncRNA <- matrix(expMeanVec_CTCF_lncRNA,nrow=41)
expMeanMatrix_CTCF_lncRNA <- apply(expMeanMatrix_CTCF_lncRNA,2,Zscore)
expMeanMatrix_CTCF_lncRNA <- expMeanMatrix_CTCF_lncRNA[,which(!is.na(colSums(expMeanMatrix_CTCF_lncRNA)))]
expPlotVec_CTCF_lncRNA <- rowMeans(expMeanMatrix_CTCF_lncRNA)
write.table(expPlotVec_CTCF_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF proteincoding
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/proteincoding_density_value.RData")

expMeanVec_CTCF_proteincoding <- rowMeans(expData)
expMeanMatrix_CTCF_proteincoding <- matrix(expMeanVec_CTCF_proteincoding,nrow=41)
expMeanMatrix_CTCF_proteincoding <- apply(expMeanMatrix_CTCF_proteincoding,2,Zscore)
expMeanMatrix_CTCF_proteincoding <- expMeanMatrix_CTCF_proteincoding[,which(!is.na(colSums(expMeanMatrix_CTCF_proteincoding)))]
expPlotVec_CTCF_proteincoding <- rowMeans(expMeanMatrix_CTCF_proteincoding)
write.table(expPlotVec_CTCF_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/enhancer_density_value.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 lncRNA
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/lncRNA_density_value.RData")

expMeanVec_EP300_lncRNA <- rowMeans(expData)
expMeanMatrix_EP300_lncRNA <- matrix(expMeanVec_EP300_lncRNA,nrow=41)
expMeanMatrix_EP300_lncRNA <- apply(expMeanMatrix_EP300_lncRNA,2,Zscore)
expMeanMatrix_EP300_lncRNA <- expMeanMatrix_EP300_lncRNA[,which(!is.na(colSums(expMeanMatrix_EP300_lncRNA)))]
expPlotVec_EP300_lncRNA <- rowMeans(expMeanMatrix_EP300_lncRNA)
write.table(expPlotVec_EP300_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 proteincoding
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/proteincoding_density_value.RData")

expMeanVec_EP300_proteincoding <- rowMeans(expData)
expMeanMatrix_EP300_proteincoding <- matrix(expMeanVec_EP300_proteincoding,nrow=41)
expMeanMatrix_EP300_proteincoding <- apply(expMeanMatrix_EP300_proteincoding,2,Zscore)
expMeanMatrix_EP300_proteincoding <- expMeanMatrix_EP300_proteincoding[,which(!is.na(colSums(expMeanMatrix_EP300_proteincoding)))]
expPlotVec_EP300_proteincoding <- rowMeans(expMeanMatrix_EP300_proteincoding)
write.table(expPlotVec_EP300_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/enhancer_density_value.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A lncRNA
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/lncRNA_density_value.RData")

expMeanVec_POLR2A_lncRNA <- rowMeans(expData)
expMeanMatrix_POLR2A_lncRNA <- matrix(expMeanVec_POLR2A_lncRNA,nrow=41)
expMeanMatrix_POLR2A_lncRNA <- apply(expMeanMatrix_POLR2A_lncRNA,2,Zscore)
expMeanMatrix_POLR2A_lncRNA <- expMeanMatrix_POLR2A_lncRNA[,which(!is.na(colSums(expMeanMatrix_POLR2A_lncRNA)))]
expPlotVec_POLR2A_lncRNA <- rowMeans(expMeanMatrix_POLR2A_lncRNA)
write.table(expPlotVec_POLR2A_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A proteincoding
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/proteincoding_density_value.RData")

expMeanVec_POLR2A_proteincoding <- rowMeans(expData)
expMeanMatrix_POLR2A_proteincoding <- matrix(expMeanVec_POLR2A_proteincoding,nrow=41)
expMeanMatrix_POLR2A_proteincoding <- apply(expMeanMatrix_POLR2A_proteincoding,2,Zscore)
expMeanMatrix_POLR2A_proteincoding <- expMeanMatrix_POLR2A_proteincoding[,which(!is.na(colSums(expMeanMatrix_POLR2A_proteincoding)))]
expPlotVec_POLR2A_proteincoding <- rowMeans(expMeanMatrix_POLR2A_proteincoding)
write.table(expPlotVec_POLR2A_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_enhancer.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*_enhancer.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-14)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*_enhancer.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-14)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/enhancer_density_value.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_enhancer.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase lncRNA
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_lncRNA.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*_lncRNA.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-12)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*_lncRNA.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-12)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/lncRNA_density_value.RData")

expMeanVec_DNase_lncRNA <- rowMeans(expData)
expMeanMatrix_DNase_lncRNA <- matrix(expMeanVec_DNase_lncRNA,nrow=41)
expMeanMatrix_DNase_lncRNA <- apply(expMeanMatrix_DNase_lncRNA,2,Zscore)
expMeanMatrix_DNase_lncRNA <- expMeanMatrix_DNase_lncRNA[,which(!is.na(colSums(expMeanMatrix_DNase_lncRNA)))]
expPlotVec_DNase_lncRNA <- rowMeans(expMeanMatrix_DNase_lncRNA)
write.table(expPlotVec_DNase_lncRNA,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_lncRNA.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase proteincoding
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_proteincoding.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*_proteincoding.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-19)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*_proteincoding.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-19)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/proteincoding_density_value.RData")

expMeanVec_DNase_proteincoding <- rowMeans(expData)
expMeanMatrix_DNase_proteincoding <- matrix(expMeanVec_DNase_proteincoding,nrow=41)
expMeanMatrix_DNase_proteincoding <- apply(expMeanMatrix_DNase_proteincoding,2,Zscore)
expMeanMatrix_DNase_proteincoding <- expMeanMatrix_DNase_proteincoding[,which(!is.na(colSums(expMeanMatrix_DNase_proteincoding)))]
expPlotVec_DNase_proteincoding <- rowMeans(expMeanMatrix_DNase_proteincoding)
write.table(expPlotVec_DNase_proteincoding,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_proteincoding.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)
