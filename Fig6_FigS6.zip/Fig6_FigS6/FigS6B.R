# XW
C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,6] > 8),6] + 1)/(DBAData[which(AllData[,6] > 8),6] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[which(AllData[,6] > 8),6] + 1),log2(DBAData[which(AllData[,6] > 8),6] + 1),ratioData,classData))
cat(length(which(ratioData > 1))/length(ratioData),"\n")
cat(length(which(ratioData < -1))/length(ratioData),"\n")

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/Oocyte.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,7] + 1)/(DBAData[,7] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,7]+1),log2(DBAData[,7]+1),ratioData,classData))
plotData <- plotData[which(AllData[,7] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/Zygote.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,4] + 1)/(DBAData[,4] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,4]+1),log2(DBAData[,4]+1),ratioData,classData))
plotData <- plotData[which(AllData[,4] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/E2C.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,1] + 1)/(DBAData[,1] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,1]+1),log2(DBAData[,1]+1),ratioData,classData))
plotData <- plotData[which(AllData[,1] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/2C.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,2] + 1)/(DBAData[,2] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,2]+1),log2(DBAData[,2]+1),ratioData,classData))
plotData <- plotData[which(AllData[,2] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/4C.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,3] + 1)/(DBAData[,3] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,3]+1),log2(DBAData[,3]+1),ratioData,classData))
plotData <- plotData[which(AllData[,3] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/8C.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

ratioData <- log2((C57BLData[,5] + 1)/(DBAData[,5] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"
plotData <- as.data.frame(cbind(log2(C57BLData[,5]+1),log2(DBAData[,5]+1),ratioData,classData))
plotData <- plotData[which(AllData[,5] > 8),]

colnames(plotData) <- c("Num1","Num2","Ratio","Class")
plotData$Num1 <- as.numeric(plotData$Num1)
plotData$Num2 <- as.numeric(plotData$Num2)
plotData$Ratio <- as.numeric(plotData$Ratio)
plotData$Class <- factor(plotData$Class,levels=c("Maternal","Both","Paternal"))
cat(length(which(plotData$Ratio > 1))/length(plotData$Ratio),"\n")
cat(length(which(plotData$Ratio < -1))/length(plotData$Ratio),"\n")

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/ICM.pdf",width=8,height=6)
p <- ggplot(plotData,aes(x=Num1,y=Num2)) + geom_point(alpha=0.4,size=6.0,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red"))
p <- p + scale_y_continuous(limits = c(0,10))
p <- p + scale_x_continuous(limits = c(0,10))
p <- p + xlab("Number of Reads") + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()
