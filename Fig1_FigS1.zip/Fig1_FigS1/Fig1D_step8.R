signalData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/lncRNA_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
plotData <- signalData[,2:ncol(signalData)]
plotdata <- data.frame(x=c(rep(seq(1,ncol(plotData)),times=nrow(plotData))),y=as.numeric(c(plotData[1,],plotData[2,],plotData[3,],plotData[4,],plotData[5,],plotData[6,],plotData[7,])),z=c(rep("E2C",ncol(plotData)),rep("ICM",ncol(plotData)),rep("L2C",ncol(plotData)),rep("M4C",ncol(plotData)),rep("M8C",ncol(plotData)),rep("MIIOocyte",ncol(plotData)),rep("Zygote",ncol(plotData))))
plotdata$x <- as.numeric((plotdata$x))
plotdata$y <- as.numeric(plotdata$y)
plotdata$z <- factor(plotdata$z,levels=rev(c("MIIOocyte","Zygote","E2C","L2C","M4C","M8C","ICM")))

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/lncRNA_scaled_profile.pdf")
p <- ggplot(plotdata, aes(x = x, y = y,color=z)) + geom_smooth(method="loess",span=0.5) + scale_color_manual(values = c(rev(wes_palette("Zissou1",6,type = "continuous")),"darkslateblue"))
p <- p + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
print(p)
dev.off()

signalData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/proteincoding_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
plotData <- signalData[,2:ncol(signalData)]
plotdata <- data.frame(x=c(rep(seq(1,ncol(plotData)),times=nrow(plotData))),y=as.numeric(c(plotData[1,],plotData[2,],plotData[3,],plotData[4,],plotData[5,],plotData[6,],plotData[7,])),z=c(rep("E2C",ncol(plotData)),rep("ICM",ncol(plotData)),rep("L2C",ncol(plotData)),rep("M4C",ncol(plotData)),rep("M8C",ncol(plotData)),rep("MIIOocyte",ncol(plotData)),rep("Zygote",ncol(plotData))))
plotdata$x <- as.numeric((plotdata$x))
plotdata$y <- as.numeric(plotdata$y)
plotdata$z <- factor(plotdata$z,levels=rev(c("MIIOocyte","Zygote","E2C","L2C","M4C","M8C","ICM")))

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/proteincoding_scaled_profile.pdf")
p <- ggplot(plotdata, aes(x = x, y = y,color=z)) + geom_smooth(method="loess",span=0.25) + scale_color_manual(values = c(rev(wes_palette("Zissou1",6,type = "continuous")),"darkslateblue"))
p <- p + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
print(p)
dev.off()