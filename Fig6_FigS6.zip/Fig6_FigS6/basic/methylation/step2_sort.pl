#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my ($inputdir,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*pe.bam"`;
print join("\n",@samples)."\n";
foreach my $sample_in (@samples){
	chomp $sample_in;
	$sample_in =~ /.*\/(.*)\/.*pe\.bam/;
	my $sample_id = $1;
	my $sample_out = $sample_in;
	$sample_out =~ s/pe\.bam/pe_sorted\.bam/;
	open(SH,">$inputdir/$sample_id/${sample_id}_sort.sh") or die "$!\n";
    print SH "samtools sort -n -@ $threads -o $sample_out $sample_in\n";
	close SH;
    
    open OUT,">$inputdir/$sample_id/submit_${sample_id}_sort.sh";
    print OUT <<EOF;	
#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J $sample_id
#SBATCH -c $threads
#SBATCH --mem 60G
#SBATCH -o $inputdir/$sample_id/sort.log
#SBATCH -e $inputdir/$sample_id/sort.err

date
source ~/.bashrc
module load samtools/1.14
sh $inputdir/$sample_id/${sample_id}_sort.sh
date
EOF
	close OUT;
	my $sb = `sbatch $inputdir/$sample_id/submit_${sample_id}_sort.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl step2_sort.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping --threads 4