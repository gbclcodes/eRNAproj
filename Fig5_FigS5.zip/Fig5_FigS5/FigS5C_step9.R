randPercVec <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","spenhspenhPairOEvec*RData"))
for (randfile in randfiles){
	enhenhPairOEvec <- load(randfile)
	enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
	randfile2 <- gsub("spenhspenhPairOEvec","enhspenhPairOEvec",randfile)
	if(file.exists(randfile2)){
		enhenhPairOEvec2 <- load(randfile2)
		enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
		enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
	}
	percValue <- quantile(enhenhPairOEvec,probs=0.95)
	randPercVec <- c(randPercVec,percValue)
}
q99 <- median(randPercVec,na.rm=TRUE)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecE2CGSR.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecE2CGSR.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percE2CGSR <- length(which(enhenhPairsOEvecE2C > q99))/length(enhenhPairsOEvecE2C)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecL2CGSR.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecL2CGSR.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percL2CGSR <- length(which(enhenhPairsOEvecL2C > q99))/length(enhenhPairsOEvecL2C)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecM8CGSR.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecM8CGSR.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percM8CGSR <- length(which(enhenhPairsOEvecM8C > q99))/length(enhenhPairsOEvecM8C)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecICMGSR.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecICMGSR.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percICMGSR <- length(which(enhenhPairsOEvecICM > q99))/length(enhenhPairsOEvecICM)
(length(which(enhenhPairsOEvecE2C > q99)) + length(which(enhenhPairsOEvecL2C > q99)) + length(which(enhenhPairsOEvecM8C > q99)) + length(which(enhenhPairsOEvecICM > q99)))/(length(enhenhPairsOEvecE2C) + length(enhenhPairsOEvecL2C) + length(enhenhPairsOEvecM8C) + length(enhenhPairsOEvecICM))

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecE2CXW.RData")
percE2CXW <- length(which(enhenhPairsOEvecE2C > q99))/length(enhenhPairsOEvecE2C)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecL2CXW.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecL2CXW.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percL2CXW <- length(which(enhenhPairsOEvecL2C > q99))/length(enhenhPairsOEvecL2C)

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecM8CXW.RData")
percM8CXW <- length(which(enhenhPairsOEvecM8C > q99))/length(enhenhPairsOEvecM8C)

enhenhPairOEvec <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecICMXW.RData")
enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
enhenhPairOEvec2 <- load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhspenhPairOEvecICMXW.RData")
enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
percICMXW <- length(which(enhenhPairsOEvecICM > q99))/length(enhenhPairsOEvecICM)
(length(which(enhenhPairsOEvecE2C > q99)) + length(which(enhenhPairsOEvecL2C > q99)) + length(which(enhenhPairsOEvecM8C > q99)) + length(which(enhenhPairsOEvecICM > q99)))/(length(enhenhPairsOEvecE2C) + length(enhenhPairsOEvecL2C) + length(enhenhPairsOEvecM8C) + length(enhenhPairsOEvecICM))

percE2C <- (percE2CGSR + percE2CXW)/2
percL2C <- (percL2CGSR + percL2CXW)/2
percM8C <- (percM8CGSR + percM8CXW)/2
percICM <- (percICMGSR + percICMXW)/2
RealPerc <- c(percE2C,percL2C,percM8C,percICM)  

randPercVecE2C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","spenhspenhPairOEvecE2C*RData"))
for (randfile in randfiles){
	enhenhPairOEvec <- load(randfile)
	enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
	randfile2 <- gsub("spenhspenhPairOEvec","enhspenhPairOEvec",randfile)
	if(file.exists(randfile2)){
		enhenhPairOEvec2 <- load(randfile2)
		enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
		enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
	}
	percValue <- length(which(enhenhPairOEvec > q99))/length(enhenhPairOEvec)
	randPercVecE2C <- c(randPercVecE2C,percValue)
}

randPercVecL2C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","spenhspenhPairOEvecL2C*RData"))
for (randfile in randfiles){
	enhenhPairOEvec <- load(randfile)
	enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
	randfile2 <- gsub("spenhspenhPairOEvec","enhspenhPairOEvec",randfile)
	if(file.exists(randfile2)){
		enhenhPairOEvec2 <- load(randfile2)
		enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
		enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
	}
	percValue <- length(which(enhenhPairOEvec > q99))/length(enhenhPairOEvec)
	randPercVecL2C <- c(randPercVecL2C,percValue)
}

randPercVecM8C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","spenhspenhPairOEvecM8C*RData"))
for (randfile in randfiles){
	enhenhPairOEvec <- load(randfile)
	enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
	randfile2 <- gsub("spenhspenhPairOEvec","enhspenhPairOEvec",randfile)
	if(file.exists(randfile2)){
		enhenhPairOEvec2 <- load(randfile2)
		enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
		enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
	}
	percValue <- length(which(enhenhPairOEvec > q99))/length(enhenhPairOEvec)
	randPercVecM8C <- c(randPercVecM8C,percValue)
}

randPercVecICM <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","spenhspenhPairOEvecICM*RData"))
for (randfile in randfiles){
	enhenhPairOEvec <- load(randfile)
	enhenhPairOEvec <- eval(parse(text = enhenhPairOEvec))
	randfile2 <- gsub("spenhspenhPairOEvec","enhspenhPairOEvec",randfile)
	if(file.exists(randfile2)){
		enhenhPairOEvec2 <- load(randfile2)
		enhenhPairOEvec2 <- eval(parse(text = enhenhPairOEvec2))
		enhenhPairOEvec <- c(enhenhPairOEvec,enhenhPairOEvec2)
	}
	percValue <- length(which(enhenhPairOEvec > q99))/length(enhenhPairOEvec)
	randPercVecICM <- c(randPercVecICM,percValue)
}
RandPerc <- c(mean(randPercVecE2C),mean(randPercVecL2C),mean(randPercVecM8C),mean(randPercVecICM))

condition <- rep(c("Real","Random"),c(4,4))
type <- rep(c("E2C","L2C","M8C","ICM"),2)
percvalue <- c(as.numeric(RealPerc),as.numeric(RandPerc))
plotData <- as.data.frame(cbind(percvalue,type,condition))
colnames(plotData) <- c("percvalue","type","condition")
plotData$percvalue <- as.numeric(percvalue)
plotData$type <- factor(type,levels=c("E2C","L2C","M8C","ICM"))
plotData$condition <- factor(condition,levels=c("Real","Random"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/SpEnhSpEnhHiCSupportedPerc.pdf",width=8,height=5)
p <- ggplot(data=plotData, aes(x=type, y=percvalue, fill=condition)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()
