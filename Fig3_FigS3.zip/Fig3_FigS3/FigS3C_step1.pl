#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Path;

my ($devgenefile,$keggfile,$outfile,$help);
GetOptions(
	"keggfile=s" => \$keggfile,
	"outfile=s" => \$outfile,
	"help!" => \$help,
);

open(OUT,">$outfile") or die "$!\n";
open(KEGG,"<$keggfile") or die "$!\n";
while(<KEGG>){
	my $line = $_;
	chomp $line;
	if($line =~ /signaling pathway/){
		my @fieldValues = split /\t/,$line;
		print OUT "$line\n";
	}
}
close OUT;
close KEGG;

# perl figS3a_step1.pl --keggfile /media/yuhua/yuhua_projects/enhProj/annodata/mousekegg_pathways.txt --outfile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/genes_within_kegg_signaling_pathway.txt
# perl figS3a_step1.pl --keggfile /media/yuhua/yuhua_projects/enhProj/annodata/mousekegg_pathways.txt --outfile /media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/genes_within_kegg_signaling_pathway.txt