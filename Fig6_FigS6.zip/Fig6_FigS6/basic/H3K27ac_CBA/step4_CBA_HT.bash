#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J HT
#SBATCH -c 1
#SBATCH --mem 20G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result/HT.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result/HT.err

cd /storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/H3K27ac_CBA_MD/result

ls *.bam | while read file; do (htseq-count -c ${file:0:18}.csv -r pos -f bam -s no -i Name -t BED_feature --nonunique all -q $file enhancer_XW_new.gff3); done

ls *.bam | while read file; do (htseq-count -c ${file:0:18}_genome.csv -r pos -f bam -s no --nonunique all -q $file /storage/gbcl/qiaolu/new_gencode.vM17.annotation.gff3); done
