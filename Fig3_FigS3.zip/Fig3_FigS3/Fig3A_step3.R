enhTarPairsGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_signalpathgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhTarPairsXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_signalpathgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
pathData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/genes_within_kegg_signaling_pathway.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
pathFreq <- table(pathData[,4])

matchIndexes <- match(unique(c(enhTarPairsGSR[,3],enhTarPairsXW[,3])),pathData[,1])
geneFreq <- table(pathData[matchIndexes,4])
matchIndexes <- match(names(pathFreq),names(geneFreq))
genePerc <- geneFreq[matchIndexes]/pathFreq
genePerc <- sort(genePerc,decreasing=TRUE)

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllMIIGSR.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllE2CGSR.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllL2CGSR.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllM8CGSR.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllICMGSR.kegg.signal.RData")
enhTarPairsOEvecGSR <- rbind(enhTarPairsOEvecMII,enhTarPairsOEvecE2C,enhTarPairsOEvecL2C,enhTarPairsOEvecM8C,enhTarPairsOEvecICM)

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllMIIXW.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllE2CXW.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllL2CXW.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllM8CXW.kegg.signal.RData")
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecAllICMXW.kegg.signal.RData")
enhTarPairsOEvecXW <- rbind(enhTarPairsOEvecMII,enhTarPairsOEvecE2C,enhTarPairsOEvecL2C,enhTarPairsOEvecM8C,enhTarPairsOEvecICM)

enhTarPairsOEvec <- rbind(enhTarPairsOEvecGSR,enhTarPairsOEvecXW)
totalFreq <- table(enhTarPairsOEvec[,7])
enhTarPairsOEvec <- enhTarPairsOEvec[which(as.numeric(enhTarPairsOEvec[,8]) > 0.8994216),]
HiCFreq <- table(enhTarPairsOEvec[,7])
matchIndexes <- match(gsub("\\s+","",names(totalFreq)),names(HiCFreq))
HiCPerc <- HiCFreq[matchIndexes]/(totalFreq)

genePerc <- genePerc[1:10]
matchIndexes <- match(gsub("\\s+","",names(genePerc)),names(HiCPerc))
HiCPerc <- HiCPerc[matchIndexes]

type <- names(genePerc)
percvalue <- c(as.numeric(genePerc))
plotData <- as.data.frame(cbind(percvalue,type))
colnames(plotData) <- c("percvalue","type")
plotData$percvalue <- as.numeric(percvalue)
plotData$type <- factor(type,levels=names(genePerc))

library(ggplot2)
library(colorspace)
q4 <- qualitative_hcl(4, palette = "Pastel 1")
pdf("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/top10KEGGpathwaysPerc.pdf",width=16,height=5)
p <- ggplot(data=plotData, aes(x=type, y=percvalue,fill="#FFC5D0")) + geom_bar(stat="identity",width = 0.4)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()
