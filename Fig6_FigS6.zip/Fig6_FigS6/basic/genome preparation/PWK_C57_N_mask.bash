#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J SNPsplit_genome_pre                          
#SBATCH -c 1
#SBATCH --mem 100G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27me3_SNP/pre.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27me3_SNP/pre.err



/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit_genome_preparation --vcf /storage/gbcl/qiaolu/ATAC/mgp.v5.merged.snps_all.dbSNP142.vcf.gz --reference_genome /storage/gbcl/qiaolu/SNPsplit_genome_pre/mm10_ref --strain PWK_PhJ