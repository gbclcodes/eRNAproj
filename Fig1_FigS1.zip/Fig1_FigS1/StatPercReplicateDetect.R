expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/enhancer_TPM.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
mapData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/run2samplename.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)

stageNames <- c("MII-Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E6.5_Epi","E6.5_Exe")

total <- 0
count <- 0
for (rowi in seq(1,nrow(expData))){
	expvec <- as.numeric(expData[rowi,match(mapData[,1],colnames(expData))])
	if(sum(expvec) > 0){
		total <- total + 1
		for (stageName in stageNames){
			mapindexes <- grep(stageName,mapData[,2])
			srrindexes <- match(mapData[mapindexes,1],colnames(expData))
			expvec <- as.numeric(expData[rowi,srrindexes])
			if(length(which(expvec > 0)) >= 2){
				count <- count + 1
				break
			}
		}
	}
}

expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/gene_TPM.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
mapData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/run2samplename.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)

stageNames <- c("MII-Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E6.5_Epi","E6.5_Exe")

total <- 0
count <- 0
for (rowi in seq(1,nrow(expData))){
	expvec <- as.numeric(expData[rowi,match(mapData[,1],colnames(expData))])
	if(sum(expvec) > 0){
		total <- total + 1
		for (stageName in stageNames){
			mapindexes <- grep(stageName,mapData[,2])
			srrindexes <- match(mapData[mapindexes,1],colnames(expData))
			expvec <- as.numeric(expData[rowi,srrindexes])
			if(length(which(expvec > 0)) >= 2){
				count <- count + 1
				break
			}
		}
	}
}

expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/enhancer_TPM.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
mapData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/run2samplename.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)

stageNames <- c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")

total <- 0
count <- 0
for (rowi in seq(1,nrow(expData))){
	expvec <- as.numeric(expData[rowi,match(mapData[,1],colnames(expData))])
	if(sum(expvec) > 0){
		total <- total + 1
		for (stageName in stageNames){
			mapindexes <- grep(stageName,mapData[,3])
			srrindexes <- match(mapData[mapindexes,1],colnames(expData))
			expvec <- as.numeric(expData[rowi,srrindexes])
			if(length(which(expvec > 0)) >= 2){
				count <- count + 1
				break
			}
		}
	}
}

expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/gene_TPM.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
mapData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/SRRexprfiles/run2samplename.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)

stageNames <- c("MII-Oocyte","zygote","early_2-cell","2-cell","4-cell","8-cell","ICM")

total <- 0
count <- 0
for (rowi in seq(1,nrow(expData))){
	expvec <- as.numeric(expData[rowi,match(mapData[,1],colnames(expData))])
	if(sum(expvec) > 0){
		total <- total + 1
		for (stageName in stageNames){
			mapindexes <- grep(stageName,mapData[,3])
			srrindexes <- match(mapData[mapindexes,1],colnames(expData))
			expvec <- as.numeric(expData[rowi,srrindexes])
			if(length(which(expvec > 0)) >= 2){
				count <- count + 1
				break
			}
		}
	}
}


