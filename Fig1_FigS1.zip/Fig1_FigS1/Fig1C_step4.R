library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(2,'Set1')

# H3K4me1
H3K4me1_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K4me1_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/nonexpPlotVec_H3K4me1_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K4me1_enhancerData <- c(median(H3K4me1_enhancerData[1:10]),median(H3K4me1_enhancerData[11:20]),H3K4me1_enhancerData[21],median(H3K4me1_enhancerData[22:31]),median(H3K4me1_enhancerData[32:41]))
H3K4me1_nonenhancerData <- c(median(H3K4me1_nonenhancerData[1:10]),median(H3K4me1_nonenhancerData[11:20]),H3K4me1_nonenhancerData[21],median(H3K4me1_nonenhancerData[22:31]),median(H3K4me1_nonenhancerData[32:41]))
H3K4me1_enhancerData <- approx(H3K4me1_enhancerData, n=41)$y
H3K4me1_nonenhancerData <- approx(H3K4me1_nonenhancerData, n=41)$y
yvalues <- c(H3K4me1_enhancerData,H3K4me1_nonenhancerData)

yvalues <- c(H3K4me1_enhancerData,H3K4me1_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/H3K4me1_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# H3K27ac
H3K27ac_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K27ac_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/nonexpPlotVec_H3K27ac_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K27ac_enhancerData <- c(median(H3K27ac_enhancerData[1:10]),median(H3K27ac_enhancerData[11:20]),H3K27ac_enhancerData[21],median(H3K27ac_enhancerData[22:31]),median(H3K27ac_enhancerData[32:41]))
H3K27ac_nonenhancerData <- c(median(H3K27ac_nonenhancerData[1:10]),median(H3K27ac_nonenhancerData[11:20]),H3K27ac_nonenhancerData[21],median(H3K27ac_nonenhancerData[22:31]),median(H3K27ac_nonenhancerData[32:41]))
H3K27ac_enhancerData <- approx(H3K27ac_enhancerData, n=41)$y
H3K27ac_nonenhancerData <- approx(H3K27ac_nonenhancerData, n=41)$y
yvalues <- c(H3K27ac_enhancerData,H3K27ac_nonenhancerData)

yvalues <- c(H3K27ac_enhancerData,H3K27ac_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/H3K27ac_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# CTCF
CTCF_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
CTCF_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/nonexpPlotVec_CTCF_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
CTCF_enhancerData <- c(median(CTCF_enhancerData[1:10]),median(CTCF_enhancerData[11:20]),CTCF_enhancerData[21],median(CTCF_enhancerData[22:31]),median(CTCF_enhancerData[32:41]))
CTCF_nonenhancerData <- c(median(CTCF_nonenhancerData[1:10]),median(CTCF_nonenhancerData[11:20]),CTCF_nonenhancerData[21],median(CTCF_nonenhancerData[22:31]),median(CTCF_nonenhancerData[32:41]))
CTCF_enhancerData <- approx(CTCF_enhancerData, n=41)$y
CTCF_nonenhancerData <- approx(CTCF_nonenhancerData, n=41)$y

yvalues <- c(CTCF_enhancerData,CTCF_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/CTCF_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# EP300
EP300_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
EP300_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/nonexpPlotVec_EP300_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
EP300_enhancerData <- c(median(EP300_enhancerData[1:10]),median(EP300_enhancerData[11:20]),EP300_enhancerData[21],median(EP300_enhancerData[22:31]),median(EP300_enhancerData[32:41]))
EP300_nonenhancerData <- c(median(EP300_nonenhancerData[1:10]),median(EP300_nonenhancerData[11:20]),EP300_nonenhancerData[21],median(EP300_nonenhancerData[22:31]),median(EP300_nonenhancerData[32:41]))
EP300_enhancerData <- approx(EP300_enhancerData, n=41)$y
EP300_nonenhancerData <- approx(EP300_nonenhancerData, n=41)$y

yvalues <- c(EP300_enhancerData,EP300_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/EP300_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# POLR2A
POLR2A_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
POLR2A_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/nonexpPlotVec_POLR2A_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
POLR2A_enhancerData <- c(median(POLR2A_enhancerData[1:10]),median(POLR2A_enhancerData[11:20]),POLR2A_enhancerData[21],median(POLR2A_enhancerData[22:31]),median(POLR2A_enhancerData[32:41]))
POLR2A_nonenhancerData <- c(median(POLR2A_nonenhancerData[1:10]),median(POLR2A_nonenhancerData[11:20]),POLR2A_nonenhancerData[21],median(POLR2A_nonenhancerData[22:31]),median(POLR2A_nonenhancerData[32:41]))
POLR2A_enhancerData <- approx(POLR2A_enhancerData, n=41)$y
POLR2A_nonenhancerData <- approx(POLR2A_nonenhancerData, n=41)$y
yvalues <- c(POLR2A_enhancerData,POLR2A_nonenhancerData)

yvalues <- c(POLR2A_enhancerData,POLR2A_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/POLR2A_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# DNase
DNase_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
DNase_nonenhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/nonexpPlotVec_DNase_enhancer_ES.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
DNase_enhancerData <- c(median(DNase_enhancerData[1:10]),median(DNase_enhancerData[11:20]),DNase_enhancerData[21],median(DNase_enhancerData[22:31]),median(DNase_enhancerData[32:41]))
DNase_nonenhancerData <- c(median(DNase_nonenhancerData[1:10]),median(DNase_nonenhancerData[11:20]),DNase_nonenhancerData[21],median(DNase_nonenhancerData[22:31]),median(DNase_nonenhancerData[32:41]))
DNase_enhancerData <- approx(DNase_enhancerData, n=41)$y
DNase_nonenhancerData <- approx(DNase_nonenhancerData, n=41)$y

yvalues <- c(DNase_enhancerData,DNase_nonenhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("E","NE"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("E","NE"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/DNase_density_plot_ICM.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.8) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()