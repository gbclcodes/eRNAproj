#!/usr/bin/env python


import os
import shutil
import glob

def mkdir_p(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)
    
job_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/result"

os.chdir("/storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/result")
files = glob.glob("*.bam")

with open("HT_genome.bash", "w") as fh:
    fh.writelines("#!/bin/bash\n")
    fh.writelines("#SBATCH -p amd-ep2\n")
    fh.writelines("#SBATCH -q normal\n")
    fh.writelines("#SBATCH -J HT\n")
    fh.writelines("#SBATCH -c 1\n")
    fh.writelines("#SBATCH --mem 50G\n")
    fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/HT_genome.log\n")
    fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/HT_genome.err\n")
    fh.writelines("cd %s \n" % job_directory)
    fh.writelines("module load python \n")

    for file in files:
        job_name = file[:25]

        fh.writelines("htseq-count -c %s_genome.csv -r pos -f bam -s no --nonunique all -q %s /storage/gbcl/qiaolu/new_gencode.vM17.annotation.gff3 \n" % (job_name, file))

os.system("sbatch HT_genome.bash")