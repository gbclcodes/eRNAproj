expData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3Fer/htseqcountfile/enhancer_counts.txt",sep='\t',header=TRUE,row.names=1,stringsAsFactors=FALSE) 
rownames(expData) <- expData[,1]
expData[,1] <- NULL
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3Fer/htseqcountfile/H3K27me3Fer_run2samplename.txt",sep="\t")

expData.m <- expData[,grep("genome1",colnames(expData))]
colnames(expData.m) <- gsub(".genome1","",colnames(expData.m))
combData.m <- c()
stageNames <- c("MII oocyte","PWK sperm","PN5 zygote","2-cell","8-cell","ICM")
for (stagename in stageNames){
	matchIndexes <- grep(stagename,mapData[,3])
	cat(matchIndexes,"\n")
	matchIndexes <- match(mapData[matchIndexes,1],colnames(expData.m))
	if(length(matchIndexes) > 1){
		if(length(combData.m)==0){
			combData.m <- rowSums(expData.m[,matchIndexes])
		}else{
			combData.m <- cbind(combData.m,rowSums(expData.m[,matchIndexes]))
		}
	}else{
		if(length(combData.m)==0){
			combData.m <- expData.m[,matchIndexes]
		}else{
			combData.m <- cbind(combData.m,expData.m[,matchIndexes])
		}
	}
}
combData.m <- combData.m[1:(nrow(combData.m)-5),]
colnames(combData.m) <-c("Oocyte","sperm","zygote","2-cell","8-cell","ICM")
write.table(combData.m,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3Fer/htseqcountfile/enhancer_counts_m.txt",row.names=TRUE,col.names=TRUE,quote=FALSE)

expData.p <- expData[,grep("genome2",colnames(expData))]
colnames(expData.p) <- gsub(".genome2","",colnames(expData.m))
combData.p <- c()
stageNames <- c("MII oocyte","PWK sperm","PN5 zygote","2-cell","8-cell","ICM")
for (stagename in stageNames){
	matchIndexes <- grep(stagename,mapData[,3])
	cat(matchIndexes,"\n")
	matchIndexes <- match(mapData[matchIndexes,1],colnames(expData.p))
	if(length(matchIndexes) > 1){
		if(length(combData.p)==0){
			combData.p <- rowSums(expData.p[,matchIndexes])
		}else{
			combData.p <- cbind(combData.p,rowSums(expData.p[,matchIndexes]))
		}
	}else{
		if(length(combData.m)==0){
			combData.p <- expData.p[,matchIndexes]
		}else{
			combData.p <- cbind(combData.p,expData.p[,matchIndexes])
		}
	}
}
combData.p <- combData.p[1:(nrow(combData.p)-5),]
colnames(combData.p) <-c("Oocyte","sperm","zygote","2-cell","8-cell","ICM")
write.table(combData.p,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3Fer/htseqcountfile/enhancer_counts_p.txt",row.names=TRUE,col.names=TRUE,quote=FALSE)