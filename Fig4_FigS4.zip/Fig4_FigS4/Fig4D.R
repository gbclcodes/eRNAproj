TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_GSR.bed",header=FALSE,stringsAsFactors=FALSE)
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- which(!is.na(matchIndexes))
TENet <- TENet[matchIndexes,]
SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)

TENet <- TENet[which(TENet[,3] > 20),]
SENet <- SENet[which(SENet[,3] > 20),]

TERegRatioGSR <- c()
SERegRatioGSR <- c()
TERegRatioGSRSEM <- c()
SERegRatioGSRSEM <- c()
stageNames <- unique(TENet[,4])
for (stageName in stageNames){
	stageNet <- TENet[which(TENet[,4]==stageName),]
	enhNum <- length(unique(stageNet[,1]))
	TERegRatioGSR <- c(TERegRatioGSR,nrow(stageNet)/enhNum)
	TERegRatioGSRSEM <- c(TERegRatioGSRSEM,sd(table(stageNet[,1]))/sqrt(enhNum))
	stageNet <- SENet[which(SENet[,4]==stageName),]
	enhNum <- length(unique(stageNet[,1]))
	SERegRatioGSR <- c(SERegRatioGSR,nrow(stageNet)/enhNum)
	SERegRatioGSRSEM <- c(SERegRatioGSRSEM,sd(table(stageNet[,1]))/sqrt(enhNum))
}
names(TERegRatioGSR) <- stageNames
names(SERegRatioGSR) <- stageNames
names(TERegRatioGSRSEM) <- stageNames
names(SERegRatioGSRSEM) <- stageNames


TEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/typic_enhancers_XW.bed",header=FALSE
,stringsAsFactors=FALSE)
matchIndexes <- match(TENet[,1],TEData[,4])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
TENet <- TENet[matchIndexes,]
SEData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/SuperE3.bed",header=FALSE,stringsAsFactors=FALSE)

TENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
SENet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)

TENet <- TENet[which(TENet[,3] > 20),]

SENet <- SENet[which(SENet[,3] > 20),]
wilcox.test(as.numeric(rowSums(table(TENet[,c(1,2)]))),as.numeric(rowSums(table(SENet[,c(1,2)]))))

TERegRatioXW <- c()
SERegRatioXW <- c()
TERegRatioXWSEM <- c()
SERegRatioXWSEM <- c()
stageNames <- unique(TENet[,4])
for (stageName in stageNames){
	stageNet <- TENet[which(TENet[,4]==stageName),]
	enhNum <- length(unique(stageNet[,1]))
	TERegRatioXW <- c(TERegRatioXW,nrow(stageNet)/enhNum)
	TERegRatioXWSEM <- c(TERegRatioXWSEM,sd(table(stageNet[,1]))/sqrt(enhNum))
	stageNet <- SENet[which(SENet[,4]==stageName),]
	enhNum <- length(unique(stageNet[,1]))
	SERegRatioXW <- c(SERegRatioXW,nrow(stageNet)/enhNum)
	SERegRatioXWSEM <- c(SERegRatioXWSEM,sd(table(stageNet[,1]))/sqrt(enhNum))
}
names(TERegRatioXW) <- stageNames
names(SERegRatioXW) <- stageNames
names(TERegRatioXWSEM) <- stageNames
names(SERegRatioXWSEM) <- stageNames


TERegRatioMII <- TERegRatioGSR[6] + TERegRatioXW[2]
TERegRatioZygote <- TERegRatioXW[5]
TERegRatioE2C <- TERegRatioXW[4]
TERegRatio2C <-  TERegRatioGSR[1] + TERegRatioXW[3]
TERegRatio4C <-  TERegRatioGSR[5] + TERegRatioXW[6]
TERegRatio8C <-  TERegRatioGSR[3] + TERegRatioXW[7]
TERegRatioMorula <-  TERegRatioGSR[4]
TERegRatioICM <-  TERegRatioGSR[2] + TERegRatioXW[1]

SERegRatioMII <- SERegRatioGSR[6] + SERegRatioXW[2]
SERegRatioZygote <- SERegRatioXW[5]
SERegRatioE2C <- SERegRatioXW[4]
SERegRatio2C <-  SERegRatioGSR[1] + SERegRatioXW[3]
SERegRatio4C <-  SERegRatioGSR[5] + SERegRatioXW[6]
SERegRatio8C <-  SERegRatioGSR[3] + SERegRatioXW[7]
SERegRatioMorula <-  SERegRatioGSR[4]
SERegRatioICM <-  SERegRatioGSR[2] + SERegRatioXW[1]

TERegRatioMIISEM <- TERegRatioGSRSEM[6] + TERegRatioXWSEM[2]
TERegRatioZygoteSEM <- TERegRatioXWSEM[5]
TERegRatioE2CSEM <- TERegRatioXWSEM[4]
TERegRatio2CSEM <-  TERegRatioGSRSEM[1] + TERegRatioXWSEM[3]
TERegRatio4CSEM <-  TERegRatioGSRSEM[5] + TERegRatioXWSEM[6]
TERegRatio8CSEM <-  TERegRatioGSRSEM[3] + TERegRatioXWSEM[7]
TERegRatioMorulaSEM <-  TERegRatioGSRSEM[4]
TERegRatioICMSEM <-  TERegRatioGSRSEM[2] + TERegRatioXWSEM[1]

SERegRatioMIISEM <- SERegRatioGSRSEM[6] + SERegRatioXWSEM[2]
SERegRatioZygoteSEM <- SERegRatioXWSEM[5]
SERegRatioE2CSEM <- SERegRatioXWSEM[4]
SERegRatio2CSEM <-  SERegRatioGSRSEM[1] + SERegRatioXWSEM[3]
SERegRatio4CSEM <-  SERegRatioGSRSEM[5] + SERegRatioXWSEM[6]
SERegRatio8CSEM <-  SERegRatioGSRSEM[3] + SERegRatioXWSEM[7]
SERegRatioMorulaSEM <-  SERegRatioGSRSEM[4]
SERegRatioICMSEM <-  SERegRatioGSRSEM[2] + SERegRatioXWSEM[1]


perc <- c(TERegRatioMII,TERegRatioZygote,TERegRatioE2C,TERegRatio2C,TERegRatio4C,TERegRatio8C,TERegRatioMorula,TERegRatioICM,SERegRatioMII,SERegRatioZygote,SERegRatioE2C,SERegRatio2C,SERegRatio4C,SERegRatio8C,SERegRatioMorula,SERegRatioICM)
sem <- c(TERegRatioMIISEM,TERegRatioZygoteSEM,TERegRatioE2CSEM,TERegRatio2CSEM,TERegRatio4CSEM,TERegRatio8CSEM,TERegRatioMorulaSEM,TERegRatioICMSEM,SERegRatioMIISEM,SERegRatioZygoteSEM,SERegRatioE2CSEM,SERegRatio2CSEM,SERegRatio4CSEM,SERegRatio8CSEM,SERegRatioMorulaSEM,SERegRatioICMSEM)
stage <- c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM","MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM")
type <- c("TE","TE","TE","TE","TE","TE","TE","TE","SE","SE","SE","SE","SE","SE","SE","SE")

statData <- as.data.frame(cbind(perc,stage,type))
colnames(statData) <- c("perc","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("TE","SE"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/TFRegRatioTESE.pdf",width=6,height=5)
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(2,1)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + geom_errorbar(aes(x=stage, ymin=perc-sem, ymax=perc+sem), width=0.4, colour="black", alpha=0.9, size=1.3,position=position_dodge(.9))
print(p)
dev.off()
