#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*genome1.bam"`;
print join("\n",@samples)."\n";

foreach my $sample_in (@samples){
	chomp $sample_in;
	$sample_in =~ /.*\/(.*)\/.*genome1.bam/;
	my $sample_id = $1;
	
	if(!-e "$outputdir/$sample_id"){
		mkpath("$outputdir/$sample_id/genome1",0644);
		if($@){
			print "Make path $outputdir/$sample_id/genome1 failed:\n";
			exit(1);
		}
	}
	
	open(SH,">$inputdir/$sample_id/${sample_id}_extractor_genome1.sh") or die "$!\n";
	print SH "module load samtools/1.14\n";
    	print SH "/storage/gbcl/qiaolu/Bismark-0.23.0/bismark_methylation_extractor --bedGraph --merge_non_CpG --comprehensive $sample_in -o $outputdir/$sample_id/genome1\n";
	close SH;
    
    open OUT,">$inputdir/$sample_id/submit_${sample_id}_extractor_genome1.sh";
    print OUT <<EOF;
#!/bin/bash
#SBATCH -p intel-debug
#SBATCH -q debug
#SBATCH -J $sample_id
#SBATCH -c 1
#SBATCH --mem 10G
#SBATCH -o $outputdir/$sample_id/genome1/extractor.log
#SBATCH -e $outputdir/$sample_id/genome1/extractor.err

date
source ~/.bashrc
sh $inputdir/$sample_id/${sample_id}_extractor_genome1.sh
date
EOF
	close OUT;
	
	my $sb = `sbatch $inputdir/$sample_id/submit_${sample_id}_extractor_genome1.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

my @samples = `find $inputdir -name "*genome2.bam"`;
print join("\n",@samples)."\n";

foreach my $sample_in (@samples){
	chomp $sample_in;
	$sample_in =~ /.*\/(.*)\/.*genome2.bam/;
	my $sample_id = $1;
	
	if(!-e "$outputdir/$sample_id"){
		mkpath("$outputdir/$sample_id/genome2",0644);
		if($@){
			print "Make path $outputdir/$sample_id/genome2 failed:\n";
			exit(1);
		}
	}
	
	open(SH,">$inputdir/$sample_id/${sample_id}_extractor_genome2.sh") or die "$!\n";
	print SH "module load samtools/1.14\n";
    	print SH "/storage/gbcl/qiaolu/Bismark-0.23.0/bismark_methylation_extractor --bedGraph --merge_non_CpG --comprehensive $sample_in -o $outputdir/$sample_id/genome2\n";
	close SH;
    
    open OUT,">$inputdir/$sample_id/submit_${sample_id}_extractor_genome2.sh";
    print OUT <<EOF;
#!/bin/bash
#SBATCH -p intel-debug
#SBATCH -q debug
#SBATCH -J $sample_id
#SBATCH -c 1
#SBATCH --mem 10G
#SBATCH -o $outputdir/$sample_id/genome2/extractor.log
#SBATCH -e $outputdir/$sample_id/genome2/extractor.err

date
source ~/.bashrc
sh $inputdir/$sample_id/${sample_id}_extractor_genome2.sh
date
EOF
	close OUT;
	
	my $sb = `sbatch $inputdir/$sample_id/submit_${sample_id}_extractor_genome2.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl step5_extractor.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping --outputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/quantifying
