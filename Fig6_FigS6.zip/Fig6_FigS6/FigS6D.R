corCal <- function(x,y){
	matchIndexes <- which(x > 100 | y > 100)
	corvalue <- cor(x[matchIndexes],y[matchIndexes],method="pearson")
	res <- cor.test(x[matchIndexes],y[matchIndexes],method="pearson")
	pvalue <- res$p.value
	return(c(corvalue,pvalue))
}

corCal2 <- function(x,y){
	matchIndexes <- which(x > 100 | y > 30)
	corvalue <- cor(x[matchIndexes],y[matchIndexes],method="pearson")
	res <- cor.test(x[matchIndexes],y[matchIndexes],method="pearson")
	pvalue <- res$p.value
	return(c(corvalue,pvalue))
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# maternal
C57BLDataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
C57BLDataH3K9me3 <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K9me3/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
C57BLDataH3K9me3 <- C57BLDataH3K9me3[,c(1,seq(5,12))]
matchIndexes <- match(rownames(C57BLDataH3K9me3),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataH3K9me3 <- C57BLDataH3K9me3[which(!is.na(matchIndexes)),]
C57BLCorDataH3K9me3 <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K9me3[,iterer])
C57BLCorDataH3K9me3 <- cbind(C57BLCorDataH3K9me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K9me3",9))

C57BLDataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
C57BLDataH3K27me3 <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
matchIndexes <- match(rownames(C57BLDataH3K27me3),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataH3K27me3 <- C57BLDataH3K27me3[which(!is.na(matchIndexes)),]
C57BLCorDataH3K27me3 <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K27me3[,iterer])
C57BLCorDataH3K27me3 <- cbind(C57BLCorDataH3K27me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K27me3",9))

C57BLDataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,seq(2,9)]
C57BLDataDNAMeth <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/quantifying/SE_TPM.tab",sep=" ",header=TRUE,row.names=1)
C57BLDataDNAMeth <- C57BLDataDNAMeth[which(!is.na(rowSums(C57BLDataDNAMeth))),]
C57BLDataDNAMeth <- C57BLDataDNAMeth[,c(5,7,9,11,13,15,17,19)]
matchIndexes <- match(rownames(C57BLDataDNAMeth),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataDNAMeth <- C57BLDataDNAMeth[which(!is.na(matchIndexes)),]
C57BLCorDataDNAMeth <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal2(C57BLDataExpr[,iterer],C57BLDataDNAMeth[,iterer])
C57BLCorDataDNAMeth <- cbind(C57BLCorDataDNAMeth,c("2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("DNAMeth",8))

C57BLDataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,c(3,4,5,6,7)]
C57BLDataATAC <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/ATAC/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
matchIndexes <- match(rownames(C57BLDataATAC),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataATAC <- C57BLDataATAC[which(!is.na(matchIndexes)),]
C57BLCorDataATAC <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataATAC[,iterer])
C57BLCorDataATAC <- cbind(C57BLCorDataATAC,c("Early 2-cell","2-cell","4-cell","8-cell","ICM"),rep("ATAC",5))

# C57BLDataExpr <- read.csv(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
# C57BLDataExpr <- C57BLDataExpr[,c(1,4,6)]
# C57BLDataH3K27ac2C <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27acPWK/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
# C57BLDataH3K27ac <- read.csv(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27acCBA/htseqcountfile//enhancer_counts_m.txt",header=TRUE,row.names=1)
# matchIndexes <- match(rownames(C57BLDataH3K27ac2C),rownames(C57BLDataH3K27ac))
# C57BLDataH3K27ac <- C57BLDataH3K27ac[matchIndexes[which(!is.na(matchIndexes))],]
# EnhIDs <- rownames(C57BLDataH3K27ac)
# C57BLDataH3K27ac2C <- C57BLDataH3K27ac2C[which(!is.na(matchIndexes)),]
# C57BLDataH3K27ac <- cbind(C57BLDataH3K27ac[,1],C57BLDataH3K27ac2C,C57BLDataH3K27ac[,2])
# rownames(C57BLDataH3K27ac) <- EnhIDs
# matchIndexes <- match(rownames(C57BLDataH3K27ac),rownames(C57BLDataExpr))
# C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
# C57BLDataH3K27ac <- C57BLDataH3K27ac[which(!is.na(matchIndexes)),]
# C57BLCorDataH3K27ac <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K27ac[,iterer])
# C57BLCorDataH3K27ac <- cbind(C57BLCorDataH3K27ac,c("Oocyte","2-cell","8-cell"),rep("H3K27ac",3))

statData <- as.data.frame(rbind(C57BLCorDataH3K9me3,C57BLCorDataH3K27me3,C57BLCorDataDNAMeth,C57BLCorDataATAC))
colnames(statData) <- c("corValue","pValue","stageName","epiName")
statData$corValue <- as.numeric(statData$corValue)
statData$pValue <- as.numeric(statData$pValue)
statData$pValue <- -log10(p.adjust(statData$pValue))
statData$epiName <- factor(statData$epiName,levels=c("ATAC","H3K9me3","H3K27me3","DNAMeth"))
statData$stageName <- factor(statData$stageName,levels=c("Oocyte","Early 2-cell","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"))

library(ggplot2)
pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/MaternalEnhancerExprAndEpiSignalCorr.pdf",width=6,height=2.5)
p <- ggplot(statData, aes(x=stageName, y=epiName, size=pValue, color=corValue)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()

# paternal
DBADataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
DBADataH3K9me3 <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K9me3/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
DBADataH3K9me3 <- DBADataH3K9me3[,c(1,seq(5,12))]
matchIndexes <- match(rownames(DBADataH3K9me3),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataH3K9me3 <- DBADataH3K9me3[which(!is.na(matchIndexes)),]
DBACorDataH3K9me3 <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(DBADataExpr[,iterer],DBADataH3K9me3[,iterer])
DBACorDataH3K9me3 <- cbind(DBACorDataH3K9me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K9me3",9))

DBADataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
DBADataH3K27me3 <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBADataH3K27me3),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataH3K27me3 <- DBADataH3K27me3[which(!is.na(matchIndexes)),]
DBACorDataH3K27me3 <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(DBADataExpr[,iterer],DBADataH3K27me3[,iterer])
DBACorDataH3K27me3 <- cbind(DBACorDataH3K27me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K27me3",9))

DBADataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/GSR/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,seq(2,9)]
DBADataDNAMeth <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/quantifying/SE_TPM.tab",sep=" ",header=TRUE,row.names=1)
DBADataDNAMeth <- DBADataDNAMeth[which(!is.na(rowSums(DBADataDNAMeth))),]
DBADataDNAMeth <- DBADataDNAMeth[,c(5,7,9,11,13,15,17,19)]
matchIndexes <- match(rownames(DBADataDNAMeth),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataDNAMeth <- DBADataDNAMeth[which(!is.na(matchIndexes)),]
DBACorDataDNAMeth <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal2(DBADataExpr[,iterer],DBADataDNAMeth[,iterer])
DBACorDataDNAMeth <- cbind(DBACorDataDNAMeth,c("2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("DNAMeth",8))

DBADataExpr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,c(3,4,5,6,7)]
DBADataATAC <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/ATAC/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBADataATAC),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataATAC <- DBADataATAC[which(!is.na(matchIndexes)),]
DBACorDataATAC <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal2(DBADataExpr[,iterer],DBADataATAC[,iterer])
DBACorDataATAC <- cbind(DBACorDataATAC,c("Early 2-cell","2-cell","4-cell","8-cell","ICM"),rep("ATAC",5))

statData <- as.data.frame(rbind(DBACorDataH3K9me3,DBACorDataH3K27me3,DBACorDataDNAMeth,DBACorDataATAC))
colnames(statData) <- c("corValue","pValue","stageName","epiName")
statData$corValue <- as.numeric(statData$corValue)
statData$pValue <- as.numeric(statData$pValue)
statData$pValue <- -log10(p.adjust(statData$pValue))
statData$epiName <- factor(statData$epiName,levels=c("ATAC","H3K9me3","H3K27me3","DNAMeth"))
statData$stageName <- factor(statData$stageName,levels=c("Oocyte","Early 2-cell","2-cell", "4-cell", "8-cell","Morula","ICM","TE","E65Epi","E65Exe"))

library(ggplot2)
pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/PaternalEnhancerExprAndEpiSignalCorr.pdf",width=6,height=2.5)
p <- ggplot(statData, aes(x=stageName, y=epiName, size=pValue, color=corValue)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()