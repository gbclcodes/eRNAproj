library(reshape2)
library(plyr)
library(Matrix)
library(foreach)
library(doParallel)

mapBin <- function(vec,binMat){
   vec <- unlist(strsplit(vec,"\t"))
   binIndexes <- binMat[which(binMat[,1] == vec[1] & ((binMat[,2] >= as.numeric(vec[2]) & (binMat[,2]) <= as.numeric(vec[3])) | (binMat[,3] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])) | (binMat[,2] <= as.numeric(vec[2]) & (binMat[,3]) >= as.numeric(vec[3])) | (binMat[,2] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])))),4]
   return(binIndexes)
}

OEvalueCal <- function(enhTarPair,spenhPosInfo,contactMatrix,mapData){
	matchIndexEnh1 <- match(enhTarPair[1],spenhPosInfo[,4])
	matchIndexEnh2 <- match(enhTarPair[2],spenhPosInfo[,4])
	if(!is.na(matchIndexEnh1) && !is.na(matchIndexEnh2)){
		enhBins1 <- as.numeric(unlist(sapply(paste(spenhPosInfo[matchIndexEnh1,1],spenhPosInfo[matchIndexEnh1,2],spenhPosInfo[matchIndexEnh1,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
		enhBins2 <- as.numeric(unlist(sapply(paste(spenhPosInfo[matchIndexEnh2,1],spenhPosInfo[matchIndexEnh2,2],spenhPosInfo[matchIndexEnh2,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
		if(length(enhBins1) > 0 && length(enhBins2) > 0){
			return(c(sum(contactMatrix[enhBins1,enhBins2] + t(contactMatrix[enhBins2,enhBins1]))))
		}
	}
}

high.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
spenh.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enhenhPairs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/spenh_spenh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

# # MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],spenh.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],spenh.stages[,1])
# matchIndexesPairs <- which(spenh.stages[matchIndexesEnh1,3]=="MIIOocyte" & spenh.stages[matchIndexesEnh2,3]=="MIIOocyte")
# enhenhPairsMII <- enhenhPairs[matchIndexesPairs,]

# Early 2-cell
matchIndexesPairs <- which(spenh.stages[matchIndexesEnh1,3]=="E2C" & spenh.stages[matchIndexesEnh2,3]=="E2C")
enhenhPairsE2C <- enhenhPairs[matchIndexesPairs,]

# Late 2-cell
matchIndexesPairs <- which(spenh.stages[matchIndexesEnh1,3]=="L2C" & spenh.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2C <- enhenhPairs[matchIndexesPairs,]

# 8-cell
matchIndexesPairs <- which(spenh.stages[matchIndexesEnh1,3]=="M8C" & spenh.stages[matchIndexesEnh2,3]=="M8C")
enhenhPairsM8C <- enhenhPairs[matchIndexesPairs,]

# ICM
matchIndexesPairs <- which(spenh.stages[matchIndexesEnh1,3]=="ICM" & spenh.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICM <- enhenhPairs[matchIndexesPairs,]

mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
spenhPosInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/SuperE3_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

cl <- makeCluster(20)
registerDoParallel(cl)

# MIIData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
# freqMatMII <- sparseMatrix(as.numeric(MIIData[,1]), as.numeric(MIIData[,2]), x = as.numeric(MIIData[,3]))
# rm(MIIData)
# try(enhenhPairsOEvecMII <- foreach(iterer=1:nrow(enhenhPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsMII[iterer,]),spenhPosInfo,freqMatMII,mapData))
# try(enhenhPairsOEvecMII <- foreach(iterer=1:nrow(enhenhPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsMII[iterer,]),spenhPosInfo,freqMatMII,mapData))
# save(enhenhPairsOEvecMII,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecMIIXW.RData")

E2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatE2C <- sparseMatrix(as.numeric(E2CData[,1]), as.numeric(E2CData[,2]), x = as.numeric(E2CData[,3]))
rm(E2CData)
try(enhenhPairsOEvecE2C <- foreach(iter=1:nrow(enhenhPairsE2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsE2C[iter,]),spenhPosInfo,freqMatE2C,mapData))
try(enhenhPairsOEvecE2C <- foreach(iter=1:nrow(enhenhPairsE2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsE2C[iter,]),spenhPosInfo,freqMatE2C,mapData))
save(enhenhPairsOEvecE2C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecE2CXW.RData")

L2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatL2C <- sparseMatrix(as.numeric(L2CData[,1]), as.numeric(L2CData[,2]), x = as.numeric(L2CData[,3]))
rm(L2CData)
try(enhenhPairsOEvecL2C <- foreach(iter=1:nrow(enhenhPairsL2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsL2C[iter,]),spenhPosInfo,freqMatL2C,mapData))
try(enhenhPairsOEvecL2C <- foreach(iter=1:nrow(enhenhPairsL2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsL2C[iter,]),spenhPosInfo,freqMatL2C,mapData))
save(enhenhPairsOEvecL2C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecL2CXW.RData")

M8CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatM8C <- sparseMatrix(as.numeric(M8CData[,1]), as.numeric(M8CData[,2]), x = as.numeric(M8CData[,3]))
rm(M8CData)
try(enhenhPairsOEvecM8C <- foreach(iter=1:nrow(enhenhPairsM8C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsM8C[iter,]),spenhPosInfo,freqMatM8C,mapData))
try(enhenhPairsOEvecM8C <- foreach(iter=1:nrow(enhenhPairsM8C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsM8C[iter,]),spenhPosInfo,freqMatM8C,mapData))
save(enhenhPairsOEvecM8C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecM8CXW.RData")

ICMData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatICM <- sparseMatrix(as.numeric(ICMData[,1]), as.numeric(ICMData[,2]), x = as.numeric(ICMData[,3]))
rm(ICMData)
try(enhenhPairsOEvecICM <- foreach(iter=1:nrow(enhenhPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsICM[iter,]),spenhPosInfo,freqMatICM,mapData))
try(enhenhPairsOEvecICM <- foreach(iter=1:nrow(enhenhPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhenhPairsICM[iter,]),spenhPosInfo,freqMatICM,mapData))
save(enhenhPairsOEvecICM,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhspenhPairOEvecICMXW.RData")
stopCluster(cl)
