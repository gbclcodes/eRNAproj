#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J SRR3336430 
#SBATCH -c 1
#SBATCH --mem 150G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR3336430.out
#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR3336430.err
cd /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP 
module load samtools/1.14 
/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit -o /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/H3K27ac_PWK_SNP/SRR3336430 --paired --snp_file /storage/gbcl/qiaolu/EpiData/PWK_6J/all_SNPs_PWK_PhJ_GRCm38.txt.gz /storage/gbcl/qiaolu/EpiData/H3K27ac_PWK/mapping/SRR3336430_mapping.sam
