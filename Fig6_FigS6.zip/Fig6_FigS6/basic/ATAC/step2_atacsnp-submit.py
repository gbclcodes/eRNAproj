#!/usr/bin/env python


import os
import shutil
import glob

def mkdir_p(dir):
    '''make a directory (dir) if it doesn't exist'''
    if not os.path.exists(dir):
        os.mkdir(dir)

Epiname = "ATAC"
# Make top level directories
mkdir_p("/storage/gbcl/qiaolu/EpiData/%s_SNP" % Epiname)
mkdir_p("/storage/gbcl/qiaolu/EpiData/%s_SNP/script" % Epiname)

job_directory = "/storage/gbcl/qiaolu/EpiData/%s_SNP" % Epiname
script_directory = "/storage/gbcl/qiaolu/EpiData/%s_SNP/script" % Epiname
data_directory = "/storage/gbcl/qiaolu/EpiData/%s_mapping/mapping" % Epiname

os.chdir(data_directory)
files = glob.glob("*am")

for file in files:
    file_name = file[:15]
    job_file = os.path.join(script_directory,"%s_SNP.bash" % file_name)

    with open(job_file, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p amd-ep2\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J %s \n" % file_name)
        fh.writelines("#SBATCH -c 1\n")
        fh.writelines("#SBATCH --mem 100G\n")
        fh.writelines("#SBATCH -o %s/%s.out\n" % (job_directory, file_name))
        fh.writelines("#SBATCH -e %s/%s.err\n" % (job_directory, file_name))
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load samtools/1.14 \n")
        fh.writelines("/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit -o %s/%s --paired --snp_file /storage/gbcl/qiaolu/EpiData/DBA_6NJ/all_C57BL_6NJ_SNPs_DBA_2J_reference.based_on_GRCm38.txt %s/" % (job_directory, file_name, data_directory) + file )

    # os.system("sbatch %s" %job_file)