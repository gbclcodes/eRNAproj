# GSR
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enh.target.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt",header=FALSE,stringsAsFactors=FALSE)

stageNames <- unique(enhancer.stages[,3])
stageNames <- stageNames[seq(1,3)]
enhNums <- c()
TarNums <- c()
for (stageName in stageNames){
	matchIndexes <- match(enh.target.pairs.gsr[,1],enhancer.stages[which(enhancer.stages[,3]==stageName),1])
	enhNums <- c(enhNums,length(unique(enh.target.pairs.gsr[which(!is.na(matchIndexes)),1])))
	TarNums <- c(TarNums,length(unique(enh.target.pairs.gsr[which(!is.na(matchIndexes)),2])))
}

num <- c(TarNums,enhNums)
celltype <- rep(c("MIIOocyte","X2cell","X4cell"),2)
genetype <- rep(c("G","E"),each=3)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("MIIOocyte","X2cell","X4cell"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/Target_num_developmental_stage_group_barplot_GSR.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
print(p)
dev.off()

# XW
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
stageNames <- unique(enhancer.stages[,3])

enh.target.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)

stageNames <- stageNames[seq(1,5)]
enhNums <- c()
TarNums <- c()
for (stageName in stageNames){
	matchIndexes <- match(enh.target.pairs.gsr[,1],enhancer.stages[which(enhancer.stages[,3]==stageName),1])
	enhNums <- c(enhNums,length(unique(enh.target.pairs.gsr[which(!is.na(matchIndexes)),1])))
	TarNums <- c(TarNums,length(unique(enh.target.pairs.gsr[which(!is.na(matchIndexes)),2])))
}

num <- c(TarNums,enhNums)
celltype <- rep(c("MIIOocyte","Zygote","E2C","L2C","M4C"),2)
genetype <- rep(c("G","E"),each=5)
df <- as.data.frame(cbind(num,celltype,genetype))
colnames(df) <- c("num","celltype","genetype")
df$celltype <- factor(celltype,levels=c("MIIOocyte","Zygote","E2C","L2C","M4C"))
df$genetype <- factor(genetype,levels=c("G","E"))
df$num <- as.numeric(num)

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/Target_num_developmental_stage_group_barplot_XW.pdf",width=8,height=5)
p <- ggplot(data=df, aes(x=celltype, y=num, fill=genetype)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)]) + geom_text(aes(label=num), color="black", size=5)
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()