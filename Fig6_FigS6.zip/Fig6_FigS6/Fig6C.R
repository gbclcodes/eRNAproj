C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Epigenome/ATAC_C57BL_6J_enhancer.csv",header=TRUE,row.names=1)
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Epigenome/ATAC_DBA_2J_enhancer.csv",header=TRUE,row.names=1)
C57BLDataG <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Epigenome/ATAC_C57BL_6J_gene.csv",header=TRUE,row.names=1)
DBADataG <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/ATAC_DBA_2J_gene.csv",header=TRUE,row.names=1)
AllDataG <- C57BLDataG + DBADataG

matchIndexes <- which(rowSums(C57BLData) > 8)
C57BLData <- C57BLData[matchIndexes,]
for (iterer in seq(1,ncol(C57BLData))){
	C57BLData[,iterer] <- (C57BLData[,iterer]/sum(AllDataG[,iterer]))*1000000
}

matchIndexes <- which(rowSums(DBAData) > 8)
DBAData <- DBAData[matchIndexes,]
for (iterer in seq(1,ncol(DBAData))){
	DBAData[,iterer] <- (DBAData[,iterer]/sum(AllDataG[,iterer]))*1000000
}

C57BLData <- C57BLData[,c(4,1,2,3,5)]
DBAData <- DBAData[,c(4,1,2,3,5)]
colnames(C57BLData) <- c("E2C","M2C","M4C","M8C","ICM")
colnames(DBAData) <- c("E2C","M2C","M4C","M8C","ICM")

e2c.v <- sum(DBAData[,1])/sum(C57BLData[,1])
m2c.v <- sum(DBAData[,2])/sum(C57BLData[,2])
m4c.v <- sum(DBAData[,3])/sum(C57BLData[,3])
m8c.v <- sum(DBAData[,4])/sum(C57BLData[,4])
icm.v <- sum(DBAData[,5])/sum(C57BLData[,5])

stage <- c("E2C","M2C","M4C","M8C","ICM")
ratio <- c(e2c.v,m2c.v,m4c.v,m8c.v,icm.v)

statData <- as.data.frame(cbind(stage,ratio))
colnames(statData) <- c("stage","ratio")
statData$ratio <- as.numeric(statData$ratio)
statData$stage <- factor(statData$stage,levels=c("E2C","M2C","M4C","M8C","ICM"))

library(ggplot2)
library(RColorBrewer)
q5 = brewer.pal(5,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/Fig6Data/Epigenome/ATACRatio.pdf",width=7,height=5)
p <- ggplot(data=statData, aes(x=stage, y=ratio, group=1, fill=stage)) + geom_bar(stat="identity", width = 0.5) + scale_fill_manual(values = q5) 
p <- p + geom_line() 
p <- p + geom_point()
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + coord_cartesian(ylim = c(0.8,1))
print(p)
dev.off()

C57BLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/ATAC/htseqcountfile/enhancer_counts_m.txt",header=TRUE,row.names=1)
DBAData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/ATAC/htseqcountfile/enhancer_counts_p.txt",header=TRUE,row.names=1)
AllData <- C57BLData + DBAData

colnames(C57BLData) <- c("E2C","M2C","M4C","M8C","ICM")
colnames(DBAData) <- c("E2C","M2C","M4C","M8C","ICM")

TotalNum <- c(3244472,3697163,4586870,4575218,3894494)
matchIndexes <- which(rowSums(C57BLData) > 8)
C57BLData <- C57BLData[matchIndexes,]
for (iterer in seq(1,ncol(C57BLData))){
	C57BLData[,iterer] <- (C57BLData[,iterer]/TotalNum[iterer])*1000000
}

matchIndexes <- which(rowSums(DBAData) > 8)
DBAData <- DBAData[matchIndexes,]
for (iterer in seq(1,ncol(DBAData))){
	DBAData[,iterer] <- (DBAData[,iterer]/TotalNum[iterer])*1000000
}

C57BLData <- C57BLData[,c(4,1,2,3,5)]
DBAData <- DBAData[,c(4,1,2,3,5)]
colnames(C57BLData) <- c("E2C","M2C","M4C","M8C","ICM")
colnames(DBAData) <- c("E2C","M2C","M4C","M8C","ICM")

e2c.v <- sum(DBAData[,1])/sum(C57BLData[,1])
m2c.v <- sum(DBAData[,2])/sum(C57BLData[,2])
m4c.v <- sum(DBAData[,3])/sum(C57BLData[,3])
m8c.v <- sum(DBAData[,4])/sum(C57BLData[,4])
icm.v <- sum(DBAData[,5])/sum(C57BLData[,5])
stage <- c("E2C","M2C","M4C","M8C","ICM")
ratio <- c(e2c.v,m2c.v,m4c.v,m8c.v,icm.v)

statData <- as.data.frame(cbind(stage,ratio))
colnames(statData) <- c("stage","ratio")
statData$ratio <- as.numeric(statData$ratio)
statData$stage <- factor(statData$stage,levels=c("E2C","M2C","M4C","M8C","ICM"))

library(ggplot2)
library(RColorBrewer)
q5 = brewer.pal(5,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/ATAC/htseqcountfile/ATACRatio.pdf",width=7,height=5)
p <- ggplot(data=statData, aes(x=stage, y=ratio, group=1, fill=stage)) + geom_bar(stat="identity", width = 0.5) + scale_fill_manual(values = q5) 
p <- p + geom_line() 
p <- p + geom_point()
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + coord_cartesian(ylim = c(1,1.4))
print(p)
dev.off()
