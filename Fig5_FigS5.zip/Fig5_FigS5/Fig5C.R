DevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/devgenes.txt",header=FALSE,stringsAsFactors=FALSE)
NonDevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/nondevgenes.txt",header=FALSE,stringsAsFactors=FALSE)

library(foreach)
library(doParallel)

calDevScore <- function(pair,network,DevGenes,NonDevGenes){
	browser()
	Tars1 <- network[grep(pair[1],network[,1]),2]
	Tars2 <- network[grep(pair[2],network[,1]),2]
	commTars <- intersect(Tars1,Tars2)	
	DevTars <- intersect(commTars,DevGenes)
	NonDevTars <- intersect(commTars,NonDevGenes)
	if(length(commTars) > 0){
		if(length(DevTars) > 0){
			Ratio <- (length(DevTars)+1)/(length(NonDevTars)+1)
			return(Ratio)
		}else{
			return(0)
		}
	}else{
		return(NaN)
	}
}

calRandScore <- function(pair,network,DevGenes,NonDevGenes){
	browser()
	Tars1 <- network[grep(pair[1],network[,1]),2]
	Tars2 <- network[grep(pair[2],network[,1]),2]
	commTars <- intersect(Tars1,Tars2)
	AllGenes <- c(DevGenes,NonDevGenes)
	randTars <- AllGenes[sample(length(AllGenes),length(commTars))]
	DevTars <- intersect(randTars,DevGenes)
	NonDevTars <- intersect(randTars,NonDevGenes)
	if(length(commTars) > 0){
		if(length(DevTars) > 0){
			Ratio <- (length(DevTars)+1)/(length(NonDevTars)+1)
			return(Ratio)
		}else{
			return(0)
		}
	}else{
		return(NaN)
	}
}

# GSR
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_enh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EnhIDs <- rownames(mapInfo)

# MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="MIIOocyte" & enhancer.stages[matchIndexesEnh2,3]=="MIIOocyte")
enhenhPairsMIIGSR <- enhenhPairs[matchIndexesPairs,]

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & enhancer.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cellGSR <- enhenhPairs[matchIndexesPairs,]

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X4cell" & enhancer.stages[matchIndexesEnh2,3]=="X4cell")
enhenhPairsX4cellGSR <- enhenhPairs[matchIndexesPairs,]

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X8cell" & enhancer.stages[matchIndexesEnh2,3]=="X8cell")
enhenhPairsX8cellGSR <- enhenhPairs[matchIndexesPairs,]

# Morula
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="morula" & enhancer.stages[matchIndexesEnh2,3]=="morula")
enhenhPairsMorulaGSR <- enhenhPairs[matchIndexesPairs,]

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & enhancer.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMGSR <- enhenhPairs[matchIndexesPairs,]

EnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumMIIGSR <- foreach(iter=1:nrow(enhenhPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsMIIGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumMIIGSR <- foreach(iter=1:nrow(enhenhPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsMIIGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumX2cellGSR <- foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumX2cellGSR <- foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumX4cellGSR <- foreach(iter=1:nrow(enhenhPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsX4cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumX4cellGSR <- foreach(iter=1:nrow(enhenhPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsX4cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumX8cellGSR <- foreach(iter=1:nrow(enhenhPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsX8cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumX8cellGSR <- foreach(iter=1:nrow(enhenhPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsX8cellGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumMorulaGSR <- foreach(iter=1:nrow(enhenhPairsMorulaGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsMorulaGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumMorulaGSR <- foreach(iter=1:nrow(enhenhPairsMorulaGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsMorulaGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumICMGSR <- foreach(iter=1:nrow(enhenhPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsICMGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])
RandNumICMGSR <- foreach(iter=1:nrow(enhenhPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsICMGSR[iter,]),EnhTarDataGSR,DevGenesData[,1],NonDevGenesData[,1])

RealNumMIIGSR <- RealNumMIIGSR[which(!is.na(RealNumMIIGSR))]
RandNumMIIGSR <- RandNumMIIGSR[which(!is.na(RandNumMIIGSR))]

RealNumX2cellGSR <- RealNumX2cellGSR[which(!is.na(RealNumX2cellGSR))]
RandNumX2cellGSR <- RandNumX2cellGSR[which(!is.na(RandNumX2cellGSR))]

RealNumX4cellGSR <- RealNumX4cellGSR[which(!is.na(RealNumX4cellGSR))]
RandNumX4cellGSR <- RandNumX4cellGSR[which(!is.na(RandNumX4cellGSR))]

RealNumX8cellGSR <- RealNumX8cellGSR[which(!is.na(RealNumX8cellGSR))]
RandNumX8cellGSR <- RandNumX8cellGSR[which(!is.na(RandNumX8cellGSR))]

RealNumMorulaGSR <- RealNumMorulaGSR[which(!is.na(RealNumMorulaGSR))]
RandNumMorulaGSR <- RandNumMorulaGSR[which(!is.na(RandNumMorulaGSR))]

RealNumICMGSR <- RealNumICMGSR[which(!is.na(RealNumICMGSR))]
RandNumICMGSR <- RandNumICMGSR[which(!is.na(RandNumICMGSR))]

# XW
DevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/devgenes.txt",header=FALSE,stringsAsFactors=FALSE)
NonDevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/nondevgenes.txt",header=FALSE,stringsAsFactors=FALSE)

high.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.xw,median.enhancers.xw,low.enhancers.xw)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_enh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

# Zygote
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="Zygote" & enhancer.stages[matchIndexesEnh2,3]=="Zygote")
enhenhPairsZygoteXW <- enhenhPairs[matchIndexesPairs,]

# Early 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="E2C" & enhancer.stages[matchIndexesEnh2,3]=="E2C")
enhenhPairsE2CXW <- enhenhPairs[matchIndexesPairs,]

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="L2C" & enhancer.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2CXW <- enhenhPairs[matchIndexesPairs,]

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M4C" & enhancer.stages[matchIndexesEnh2,3]=="M4C")
enhenhPairsM4CXW <- enhenhPairs[matchIndexesPairs,]

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M8C" & enhancer.stages[matchIndexesEnh2,3]=="M8C")
enhenhPairsM8CXW <- enhenhPairs[matchIndexesPairs,]

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & enhancer.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMXW <- enhenhPairs[matchIndexesPairs,]

EnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt")
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumZygoteXW <- foreach(iter=1:nrow(enhenhPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsZygoteXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumZygoteXW <- foreach(iter=1:nrow(enhenhPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsZygoteXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumE2CXW <- foreach(iter=1:nrow(enhenhPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsE2CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumE2CXW <- foreach(iter=1:nrow(enhenhPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsE2CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumL2CXW <- foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumL2CXW <- foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumM4CXW <- foreach(iter=1:nrow(enhenhPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsM4CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumM4CXW <- foreach(iter=1:nrow(enhenhPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsM4CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumM8CXW <- foreach(iter=1:nrow(enhenhPairsM8CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsM8CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumM8CXW <- foreach(iter=1:nrow(enhenhPairsM8CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsM8CXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumICMXW <- foreach(iter=1:nrow(enhenhPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calDevScore(as.character(enhenhPairsICMXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])
RandNumICMXW <- foreach(iter=1:nrow(enhenhPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calRandScore(as.character(enhenhPairsICMXW[iter,]),EnhTarDataXW,DevGenesData[,1],NonDevGenesData[,1])

RealNumZygoteXW <- RealNumZygoteXW[which(!is.na(RealNumZygoteXW))]
RandNumZygoteXW <- RandNumZygoteXW[which(!is.na(RandNumZygoteXW))]

RealNumE2CXW <- RealNumE2CXW[which(!is.na(RealNumE2CXW))]
RandNumE2CXW <- RandNumE2CXW[which(!is.na(RandNumE2CXW))]

RealNumL2CXW <- RealNumL2CXW[which(!is.na(RealNumL2CXW))]
RandNumL2CXW <- RandNumL2CXW[which(!is.na(RandNumL2CXW))]

RealNumM4CXW <- RealNumM4CXW[which(!is.na(RealNumM4CXW))]
RandNumM4CXW <- RandNumM4CXW[which(!is.na(RandNumM4CXW))]

RealNumM8CXW <- RealNumM8CXW[which(!is.na(RealNumM8CXW))]
RandNumM8CXW <- RandNumM8CXW[which(!is.na(RandNumM8CXW))]

RealNumICMXW <- RealNumICMXW[which(!is.na(RealNumICMXW))]
RandNumICMXW <- RandNumICMXW[which(!is.na(RandNumICMXW))]

gsr.res <- wilcox.test(c(RealNumMIIGSR,RealNumX2cellGSR,RealNumX4cellGSR,RealNumX8cellGSR,RealNumMorulaGSR,RealNumICMGSR),c(RandNumMIIGSR,RandNumX2cellGSR,RandNumX4cellGSR,RandNumX8cellGSR,RandNumMorulaGSR,RandNumICMGSR))
xw.res <- wilcox.test(c(RealNumZygoteXW,RealNumE2CXW,RealNumL2CXW,RealNumM4CXW,RealNumM8CXW,RealNumICMXW),c(RandNumZygoteXW,RandNumE2CXW,RandNumL2CXW,RandNumM4CXW,RandNumM8CXW,RandNumICMXW))

cat((gsr.res$p.value + xw.res$p.value)/2,"\n")


RealNumMII <- mean(c(RealNumMIIGSR))
RealNumMIISEM <- sd(RealNumMIIGSR)/sqrt(length(RealNumMIIGSR))
RealNumZygote <- mean(c(RealNumZygoteXW))
RealNumZygoteSEM <- sd(RealNumZygoteXW)/sqrt(length(RealNumZygoteXW))
RealNumE2C <- mean(c(RealNumE2CXW))
RealNumE2CSEM <- sd(RealNumE2CXW)/sqrt(length(RealNumE2CXW))
RealNumL2C <- mean(c(RealNumX2cellGSR,RealNumL2CXW))
RealNumL2CSEM <- sd(c(RealNumX2cellGSR,RealNumL2CXW))/sqrt(length(c(RealNumX2cellGSR,RealNumL2CXW)))
RealNumM4C <- mean(c(RealNumX4cellGSR,RealNumM4CXW))
RealNumM4CSEM <- sd(c(RealNumX4cellGSR,RealNumM4CXW))/sqrt(length(c(RealNumX4cellGSR,RealNumM4CXW)))
RealNumM8C <- mean(c(RealNumX8cellGSR,RealNumM8CXW))
RealNumM8CSEM <- sd(c(RealNumX8cellGSR,RealNumM8CXW))/sqrt(length(c(RealNumX8cellGSR,RealNumM8CXW)))
RealNumMorula <- mean(c(RealNumMorulaGSR))
RealNumMorulaSEM <- sd(RealNumMorulaGSR)/sqrt(length(RealNumMorulaGSR))
RealNumICM <- mean(c(RealNumICMGSR,RealNumICMXW))
RealNumICMSEM <- sd(c(RealNumICMGSR,RealNumICMXW))/sqrt(length(c(RealNumICMGSR,RealNumICMXW)))

RandNumMII <- mean(c(RandNumMIIGSR))
RandNumMIISEM <- sd(RandNumMIIGSR)/sqrt(length(RandNumMIIGSR))
RandNumZygote <- mean(c(RandNumZygoteXW))
RandNumZygoteSEM <- sd(RandNumZygoteXW)/sqrt(length(RandNumZygoteXW))
RandNumE2C <- mean(c(RandNumE2CXW))
RandNumE2CSEM <- sd(RandNumE2CXW)/sqrt(length(RandNumE2CXW))
RandNumL2C <- mean(c(RandNumX2cellGSR,RandNumL2CXW))
RandNumL2CSEM <- sd(c(RandNumX2cellGSR,RandNumL2CXW))/sqrt(length(c(RandNumX2cellGSR,RandNumL2CXW)))
RandNumM4C <- mean(c(RandNumX4cellGSR,RandNumM4CXW))
RandNumM4CSEM <- sd(c(RandNumX4cellGSR,RandNumM4CXW))/sqrt(length(c(RandNumX4cellGSR,RandNumM4CXW)))
RandNumM8C <- mean(c(RandNumX8cellGSR,RandNumM8CXW))
RandNumM8CSEM <- sd(c(RandNumX8cellGSR,RandNumM8CXW))/sqrt(length(c(RandNumX8cellGSR,RandNumM8CXW)))
RandNumMorula <- mean(c(RandNumMorulaGSR))
RandNumMorulaSEM <- sd(RandNumMorulaGSR)/sqrt(length(RandNumMorulaGSR))
RandNumICM <- mean(c(RandNumICMGSR,RandNumICMXW))
RandNumICMSEM <- sd(c(RandNumICMGSR,RandNumICMXW))/sqrt(length(c(RandNumICMGSR,RandNumICMXW)))

type <- rep(c("Real","Random"),c(length(c(RealNumMII,RealNumZygote,RealNumE2C,RealNumL2C,RealNumM4C,RealNumM8C,RealNumMorula,RealNumICM)),length(c(RandNumMII,RandNumZygote,RandNumE2C,RandNumL2C,RandNumM4C,RandNumM8C,RandNumMorula,RandNumICM))))
perc <- c(as.numeric(c(RealNumMII,RealNumZygote,RealNumE2C,RealNumL2C,RealNumM4C,RealNumM8C,RealNumMorula,RealNumICM)),as.numeric(c(RandNumMII,RandNumZygote,RandNumE2C,RandNumL2C,RandNumM4C,RandNumM8C,RandNumMorula,RandNumICM)))
sem <- c(as.numeric(c(RealNumMIISEM,RealNumZygoteSEM,RealNumE2CSEM,RealNumL2CSEM,RealNumM4CSEM,RealNumM8CSEM,RealNumMorulaSEM,RealNumICMSEM)),as.numeric(c(RandNumMIISEM,RandNumZygoteSEM,RandNumE2CSEM,RandNumL2CSEM,RandNumM4CSEM,RandNumM8CSEM,RandNumMorulaSEM,RandNumICMSEM)))
stage <- rep(rep(c("MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM"),c(length(RealNumMII),length(RealNumZygote),length(RealNumE2C),length(RealNumL2C),length(RealNumM4C),length(RealNumM8C),length(RealNumMorula),length(RealNumICM))),2)

statData <- as.data.frame(cbind(perc,sem,stage,type))
colnames(statData) <- c("perc","sem","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$sem <- as.numeric(statData$sem)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("Real","Random"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/enhenhcommTarsDev.pdf",width=6,height=5)
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + geom_errorbar(aes(x=stage, ymin=perc-sem, ymax=perc+sem), width=0.4, colour="black", alpha=0.9, size=1.3,position=position_dodge(.9))
print(p)
dev.off()