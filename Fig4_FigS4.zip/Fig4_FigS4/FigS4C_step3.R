# H3K4me1 SETE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-22)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/SETE_density_value_ES.RData")

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K4me1 TE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*TE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/TE_density_value_ES.RData") 

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac SETE 
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/SETE_density_value_ES.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# H3K27ac TE 
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*TE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/TE_density_value_ES.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF SETE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-22)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/SETE_density_value_ES.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# CTCF TE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*TE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/TE_density_value_ES.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 SETE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-22)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/SETE_density_value_ES.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# EP300 TE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*TE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/TE_density_value_ES.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A SETE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-22)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/SETE_density_value_ES.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# POLR2A TE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/TE_density_value_ES.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase SETE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_Expr_ICM_SETE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*SETE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-22)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*SETE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-22)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/SETE_density_value_ES.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_SETE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# DNase TE
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_Expr_ICM_TE_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*TE_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-23)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*TE_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-23)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/TE_density_value_ES.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_TE_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)
