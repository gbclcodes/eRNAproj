#!/usr/bin/env python

import os
import shutil
import glob

# def mkdir_p(dir):
    # if not os.path.exists(dir):
        # os.mkdir(dir)

# mkdir_p("/storage/gbcl/qiaolu/DNAMeth_mapping/")
# mkdir_p("/storage/gbcl/qiaolu/DNAMeth_mapping/mapping")
# mkdir_p("/storage/gbcl/qiaolu/DNAMeth_mapping/script")

job_directory = "/storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping"

os.chdir("/storage/gbcl/qiaolu/EpiData/DNAMethData")
directory = glob.glob("*1.fastq")

for file in directory:
    file2 = file[:10] + "_2.fastq"
    sra = file[:10]
    with open("/storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/script/%s.bash" % sra, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p intel-e5,amd-ep2,amd-ep2-16c\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J %s\n" % sra)
        fh.writelines("#SBATCH -c 16\n")
        fh.writelines("#SBATCH --ntasks-per-node 1\n")
        fh.writelines("#SBATCH --cpus-per-task 16\n")
        fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/DNAMeth_mapping/%s.log\n" % sra)
        fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/DNAMeth_mapping/%s.err\n" % sra)
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load bowtie/2.4.2 \n")
        fh.writelines("module load samtools/1.14 \n") 
        fh.writelines("/storage/gbcl/qiaolu/Bismark-0.23.0/bismark --parallel 3 -p 3 --bowtie2 --score_min L,0,-0.6 --genome /storage/gbcl/qiaolu/EpiData/METH -1 /storage/gbcl/qiaolu/EpiData/DNAMethData/%s -2 /storage/gbcl/qiaolu/EpiData/DNAMethData/%s -o /storage/gbcl/qiaolu/DNAMeth_mapping/mapping/%s \n" % (file, file2, sra))
