AllData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/DNAMeth/TE_TPM.tab",header=TRUE)
AllData <- AllData[which(!is.na(rowSums(AllData))),]
C57BLData <- AllData[,c(1,3,5,7)]
DBAData <- AllData[,c(2,4,6,8)]
colnames(C57BLData) <- c("Oocyte","M2C","M4C","ICM")
colnames(DBAData) <- c("Sperm","M2C","M4C","ICM.P")

zygote.v <- sum(DBAData[,1])/sum(C57BLData[,1])
m2c.v <- sum(DBAData[,2])/sum(C57BLData[,2])
m8c.v <- sum(DBAData[,3])/sum(C57BLData[,3])
icm.v <- sum(DBAData[,4])/sum(C57BLData[,4])

stage <- c("Zygote","M2C","M8C","ICM")
ratio <- c(zygote.v,m2c.v,m8c.v,icm.v)

statData <- as.data.frame(cbind(stage,ratio))
colnames(statData) <- c("stage","ratio")
statData$ratio <- as.numeric(statData$ratio)
statData$stage <- factor(statData$stage,levels=c("Zygote","M2C","M8C","ICM"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/DNAMeth/DNAMethRatio.pdf",width=7,height=5)
p <- ggplot(data=statData, aes(x=stage, y=ratio, group=1, fill=stage)) + geom_bar(stat="identity", width = 0.5) + scale_fill_manual(values = q4) 
p <- p + geom_line() 
p <- p + geom_point()
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + coord_cartesian(ylim = c(0.9,1.6))
print(p)
dev.off()


AllData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/DNAMeth/SE_TPM.tab",header=TRUE)
AllData <- AllData[which(!is.na(rowSums(AllData))),]
C57BLData <- AllData[,c(1,3,5,7)]
DBAData <- AllData[,c(2,4,6,8)]
colnames(C57BLData) <- c("Oocyte","M2C","M4C","ICM")
colnames(DBAData) <- c("Sperm","M2C","M4C","ICM.P")

zygote.v <- sum(DBAData[,1])/sum(C57BLData[,1])
m2c.v <- sum(DBAData[,2])/sum(C57BLData[,2])
m8c.v <- sum(DBAData[,3])/sum(C57BLData[,3])
icm.v <- sum(DBAData[,4])/sum(C57BLData[,4])

stage <- c("Zygote","M2C","M8C","ICM")
ratio <- c(zygote.v,m2c.v,m8c.v,icm.v)

statData <- as.data.frame(cbind(stage,ratio))
colnames(statData) <- c("stage","ratio")
statData$ratio <- as.numeric(statData$ratio)
statData$stage <- factor(statData$stage,levels=c("Zygote","M2C","M8C","ICM"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/DNAMeth/DNAMethRatio.pdf",width=7,height=5)
p <- ggplot(data=statData, aes(x=stage, y=ratio, group=1, fill=stage)) + geom_bar(stat="identity", width = 0.5) + scale_fill_manual(values = q4) 
p <- p + geom_line() 
p <- p + geom_point()
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + coord_cartesian(ylim = c(0.9,1.6))
print(p)
dev.off()