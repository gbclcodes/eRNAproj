#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my ($inputdir,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*_sorted.deduplicated.bam"`;
print join("\n",@samples)."\n";

foreach my $sample_in (@samples){
	chomp $sample_in;
	$sample_in =~ /.*\/(.*)\/.*_sorted.deduplicated.bam/;
	my $sample_id = $1;
	open(SH,">$inputdir/$sample_id/${sample_id}_SNPsplit.sh") or die "$!\n";
    print SH "/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit -o $inputdir/$sample_id --paired --snp_file /storage/gbcl/qiaolu/DNAMeth_SNP/all_SNPs_DBA_2J_GRCm38.txt.gz $sample_in\n";
	close SH;
    
    open OUT,">$inputdir/$sample_id/submit_${sample_id}_SNPsplit.sh";
    print OUT <<EOF;
#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J $sample_id
#SBATCH -c 1
#SBATCH --mem 60G
#SBATCH -o $inputdir/$sample_id/SNPsplit.log
#SBATCH -e $inputdir/$sample_id/SNPsplit.err

date
source ~/.bashrc
module load samtools/1.14
sh $inputdir/$sample_id/${sample_id}_SNPsplit.sh
date
EOF
	close OUT;
	
	my $sb = `sbatch $inputdir/$sample_id/submit_${sample_id}_SNPsplit.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl step4_SNPsplit.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping


