library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')

# H3K27ac
H3K4me1_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K4me1_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

H3K4me1_specificData <- c(median(H3K4me1_specificData[1:10]),median(H3K4me1_specificData[11:20]),H3K4me1_specificData[21],median(H3K4me1_specificData[22:31]),median(H3K4me1_specificData[32:41]))
H3K4me1_commonData <- c(median(H3K4me1_commonData[1:10]),median(H3K4me1_commonData[11:20]),H3K4me1_commonData[21],median(H3K4me1_commonData[22:31]),median(H3K4me1_commonData[32:41]))

H3K4me1_specificData <- approx(H3K4me1_specificData, n=41)$y
H3K4me1_commonData <- approx(H3K4me1_commonData, n=41)$y

yvalues <- c(H3K4me1_specificData,H3K4me1_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/H3K4me1_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# H3K27ac
H3K27ac_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K27ac_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

H3K27ac_specificData <- c(median(H3K27ac_specificData[1:10]),median(H3K27ac_specificData[11:20]),H3K27ac_specificData[21],median(H3K27ac_specificData[22:31]),median(H3K27ac_specificData[32:41]))
H3K27ac_commonData <- c(median(H3K27ac_commonData[1:10]),median(H3K27ac_commonData[11:20]),H3K27ac_commonData[21],median(H3K27ac_commonData[22:31]),median(H3K27ac_commonData[32:41]))

H3K27ac_specificData <- approx(H3K27ac_specificData, n=41)$y
H3K27ac_commonData <- approx(H3K27ac_commonData, n=41)$y

yvalues <- c(H3K27ac_specificData,H3K27ac_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/H3K27ac_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# CTCF
CTCF_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
CTCF_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

CTCF_specificData <- c(median(CTCF_specificData[1:10]),median(CTCF_specificData[11:20]),CTCF_specificData[21],median(CTCF_specificData[22:31]),median(CTCF_specificData[32:41]))
CTCF_commonData <- c(median(CTCF_commonData[1:10]),median(CTCF_commonData[11:20]),CTCF_commonData[21],median(CTCF_commonData[22:31]),median(CTCF_commonData[32:41]))

CTCF_specificData <- approx(CTCF_specificData, n=41)$y
CTCF_commonData <- approx(CTCF_commonData, n=41)$y

yvalues <- c(CTCF_specificData,CTCF_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/CTCF_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# EP300
EP300_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
EP300_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

EP300_specificData <- c(median(EP300_specificData[1:10]),median(EP300_specificData[11:20]),EP300_specificData[21],median(EP300_specificData[22:31]),median(EP300_specificData[32:41]))
EP300_commonData <- c(median(EP300_commonData[1:10]),median(EP300_commonData[11:20]),EP300_commonData[21],median(EP300_commonData[22:31]),median(EP300_commonData[32:41]))

EP300_specificData <- approx(EP300_specificData, n=41)$y
EP300_commonData <- approx(EP300_commonData, n=41)$y

yvalues <- c(EP300_specificData,EP300_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/EP300_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# POLR2A
POLR2A_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
POLR2A_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

POLR2A_specificData <- c(median(POLR2A_specificData[1:10]),median(POLR2A_specificData[11:20]),POLR2A_specificData[21],median(POLR2A_specificData[22:31]),median(POLR2A_specificData[32:41]))
POLR2A_commonData <- c(median(POLR2A_commonData[1:10]),median(POLR2A_commonData[11:20]),POLR2A_commonData[21],median(POLR2A_commonData[22:31]),median(POLR2A_commonData[32:41]))

POLR2A_specificData <- approx(POLR2A_specificData, n=41)$y
POLR2A_commonData <- approx(POLR2A_commonData, n=41)$y

yvalues <- c(POLR2A_specificData,POLR2A_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/POLR2A_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

# DNase
DNase_specificData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_specific.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
DNase_commonData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_common.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

DNase_specificData <- c(median(DNase_specificData[1:10]),median(DNase_specificData[11:20]),DNase_specificData[21],median(DNase_specificData[22:31]),median(DNase_specificData[32:41]))
DNase_commonData <- c(median(DNase_commonData[1:10]),median(DNase_commonData[11:20]),DNase_commonData[21],median(DNase_commonData[22:31]),median(DNase_commonData[32:41]))

DNase_specificData <- approx(DNase_specificData, n=41)$y
DNase_commonData <- approx(DNase_commonData, n=41)$y

yvalues <- c(DNase_specificData,DNase_commonData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=2)
grouplabels <- rep(c("specific","common"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("specific","common"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/DNase_density_plot_twogroupenhancers.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2,4)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()
