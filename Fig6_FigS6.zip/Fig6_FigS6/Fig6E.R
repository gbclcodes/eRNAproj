corCal <- function(x,y){
	matchIndexes <- which(x > 1.5 | y > 1.5)
	corvalue <- cor(x[matchIndexes],y[matchIndexes],method="pearson")
	res <- cor.test(x[matchIndexes],y[matchIndexes],method="pearson")
	pvalue <- res$p.value
	return(c(corvalue,pvalue))
}

corCal2 <- function(x,y){
	matchIndexes <- which(x > 3 | y > 30)
	corvalue <- cor(x[matchIndexes],y[matchIndexes],method="pearson")
	res <- cor.test(x[matchIndexes],y[matchIndexes],method="pearson")
	pvalue <- res$p.value
	return(c(corvalue,pvalue))
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# maternal
C57BLDataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,c(7,1,2,3,8,6,9,4,5)]
C57BLDataExpr <- C57BLDataExpr[1:(nrow(C57BLDataExpr)-5),]
C57BLDataH3K9me3 <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K9me3_C57BL_6J_enhancer.csv",header=TRUE,row.names=1)
C57BLDataH3K9me3 <- C57BLDataH3K9me3[,c(1,3,4,5,6,7,8,9,10)]
C57BLDataH3K9me3 <- C57BLDataH3K9me3[1:(nrow(C57BLDataH3K9me3)-5),]
matchIndexes <- match(rownames(C57BLDataH3K9me3),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataH3K9me3 <- C57BLDataH3K9me3[which(!is.na(matchIndexes)),]
C57BLCorDataH3K9me3 <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K9me3[,iterer])
C57BLCorDataH3K9me3 <- cbind(C57BLCorDataH3K9me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K9me3",9))

C57BLDataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,c(7,1,2,3,8,6,9,4,5)]
C57BLDataExpr <- C57BLDataExpr[1:(nrow(C57BLDataExpr)-5),]
C57BLDataH3K27me3 <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K27me3_C57BL_6J_enhancer.csv",header=TRUE,row.names=1)
C57BLDataH3K27me3 <- C57BLDataH3K27me3[,c(1,2,3,4,7,5,6,8,9)]
C57BLDataH3K27me3 <- C57BLDataH3K27me3[1:(nrow(C57BLDataH3K27me3)-5),]
matchIndexes <- match(rownames(C57BLDataH3K27me3),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataH3K27me3 <- C57BLDataH3K27me3[which(!is.na(matchIndexes)),]
C57BLCorDataH3K27me3 <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K27me3[,iterer])
C57BLCorDataH3K27me3 <- cbind(C57BLCorDataH3K27me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K27me3",9))

C57BLDataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,c(1,2,3,8,6,9,4,5)]
C57BLDataExpr <- C57BLDataExpr[1:(nrow(C57BLDataExpr)-5),]
rownames(C57BLDataExpr) <- toupper(rownames(C57BLDataExpr))
C57BLDataDNAMeth <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/TE_TPM.tab",sep=" ",header=TRUE,row.names=1)
C57BLDataDNAMeth <- C57BLDataDNAMeth[which(!is.na(rowSums(C57BLDataDNAMeth))),]
C57BLDataDNAMeth <- C57BLDataDNAMeth[,c(5,7,9,11,13,15,17,19)]
matchIndexes <- match(rownames(C57BLDataDNAMeth),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataDNAMeth <- C57BLDataDNAMeth[which(!is.na(matchIndexes)),]
C57BLCorDataDNAMeth <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal2(C57BLDataExpr[,iterer],C57BLDataDNAMeth[,iterer])
C57BLCorDataDNAMeth <- cbind(C57BLCorDataDNAMeth,c("2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("DNAMeth",8))

C57BLDataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLDataExpr <- C57BLDataExpr[,c(4,1,2,3,5)]
C57BLDataExpr <- C57BLDataExpr[1:(nrow(C57BLDataExpr)-5),]
C57BLDataATAC <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/ATAC_C57BL_6J_enhancer.csv",header=TRUE,row.names=1)
C57BLDataATAC <- C57BLDataATAC[,c(4,1,2,3,5)]
C57BLDataATAC <- C57BLDataATAC[1:(nrow(C57BLDataATAC)-5),]
matchIndexes <- match(rownames(C57BLDataATAC),rownames(C57BLDataExpr))
C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
C57BLDataATAC <- C57BLDataATAC[which(!is.na(matchIndexes)),]
C57BLCorDataATAC <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataATAC[,iterer])
C57BLCorDataATAC <- cbind(C57BLCorDataATAC,c("Early 2-cell","2-cell","4-cell","8-cell","ICM"),rep("ATAC",5))

# C57BLDataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
# C57BLDataExpr <- C57BLDataExpr[,c(6,1,3)]
# C57BLDataExpr <- C57BLDataExpr[1:(nrow(C57BLDataExpr)-5),]
# C57BLDataH3K27ac2C <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K27ac_C57BL_6J_2C_enhancer.csv",header=TRUE,row.names=1)
# C57BLDataH3K27ac <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K27ac_C57BL_6J_enhancer.csv",header=TRUE,row.names=1)
# matchIndexes <- match(rownames(C57BLDataH3K27ac2C),rownames(C57BLDataH3K27ac))
# C57BLDataH3K27ac <- C57BLDataH3K27ac[matchIndexes[which(!is.na(matchIndexes))],]
# EnhIDs <- rownames(C57BLDataH3K27ac)
# C57BLDataH3K27ac2C <- C57BLDataH3K27ac2C[which(!is.na(matchIndexes)),]
# C57BLDataH3K27ac <- cbind(C57BLDataH3K27ac[,1],C57BLDataH3K27ac2C,C57BLDataH3K27ac[,2])
# rownames(C57BLDataH3K27ac) <- EnhIDs
# C57BLDataH3K27ac <- C57BLDataH3K27ac[1:(nrow(C57BLDataH3K27ac)-5),]
# matchIndexes <- match(rownames(C57BLDataH3K27ac),rownames(C57BLDataExpr))
# C57BLDataExpr <- C57BLDataExpr[matchIndexes[which(!is.na(matchIndexes))],]
# C57BLDataH3K27ac <- C57BLDataH3K27ac[which(!is.na(matchIndexes)),]
# C57BLCorDataH3K27ac <- foreach(iterer=1:ncol(C57BLDataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(C57BLDataExpr[,iterer],C57BLDataH3K27ac[,iterer])
# C57BLCorDataH3K27ac <- cbind(C57BLCorDataH3K27ac,c("Oocyte","2-cell","8-cell"),rep("H3K27ac",3))

statData <- as.data.frame(rbind(C57BLCorDataH3K9me3,C57BLCorDataH3K27me3,C57BLCorDataDNAMeth,C57BLCorDataATAC))
colnames(statData) <- c("corValue","pValue","stageName","epiName")
statData$corValue <- as.numeric(statData$corValue)
statData$pValue <- as.numeric(statData$pValue)
statData$pValue <- -log10(p.adjust(statData$pValue))
statData$epiName <- factor(statData$epiName,levels=c("ATAC","H3K9me3","H3K27me3","DNAMeth"))
statData$stageName <- factor(statData$stageName,levels=c("Oocyte","Early 2-cell","2-cell", "4-cell", "8-cell","Morula","ICM","TE","E65Epi","E65Exe"))

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/MaternalEnhancerExprAndEpiSignalCorr.pdf",width=6,height=2.5)
p <- ggplot(statData, aes(x=stageName, y=epiName, size=pValue, color=corValue)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()

# paternal
DBADataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,c(7,1,2,3,8,6,9,4,5)]
DBADataExpr <- DBADataExpr[1:(nrow(DBADataExpr)-5),]
DBADataH3K9me3 <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K9me3_DBA_2J_enhancer.csv",header=TRUE,row.names=1)
DBADataH3K9me3 <- DBADataH3K9me3[,c(1,3,4,5,6,7,8,9,10)]
DBADataH3K9me3 <- DBADataH3K9me3[1:(nrow(DBADataH3K9me3)-5),]
matchIndexes <- match(rownames(DBADataH3K9me3),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataH3K9me3 <- DBADataH3K9me3[which(!is.na(matchIndexes)),]
DBACorDataH3K9me3 <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(DBADataExpr[,iterer],DBADataH3K9me3[,iterer])
DBACorDataH3K9me3 <- cbind(DBACorDataH3K9me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K9me3",9))

DBADataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,c(7,1,2,3,8,6,9,4,5)]
DBADataExpr <- DBADataExpr[1:(nrow(DBADataExpr)-5),]
DBADataH3K27me3 <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/H3K27me3_DBA_2J_enhancer.csv",header=TRUE,row.names=1)
DBADataH3K27me3 <- DBADataH3K27me3[,c(1,2,3,4,7,5,6,8,9)]
DBADataH3K27me3 <- DBADataH3K27me3[1:(nrow(DBADataH3K27me3)-5),]
matchIndexes <- match(rownames(DBADataH3K27me3),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataH3K27me3 <- DBADataH3K27me3[which(!is.na(matchIndexes)),]
DBACorDataH3K27me3 <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(DBADataExpr[,iterer],DBADataH3K27me3[,iterer])
DBACorDataH3K27me3 <- cbind(DBACorDataH3K27me3,c("Oocyte","2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("H3K27me3",9))

DBADataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/TotalRNAseqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,c(1,2,3,8,6,9,4,5)]
DBADataExpr <- DBADataExpr[1:(nrow(DBADataExpr)-5),]
rownames(DBADataExpr) <- toupper(rownames(DBADataExpr))
DBADataDNAMeth <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/TE_TPM.tab",sep=" ",header=TRUE,row.names=1)
DBADataDNAMeth <- DBADataDNAMeth[which(!is.na(rowSums(DBADataDNAMeth))),]
DBADataDNAMeth <- DBADataDNAMeth[,c(6,8,10,12,14,16,18,20)]
matchIndexes <- match(rownames(DBADataDNAMeth),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataDNAMeth <- DBADataDNAMeth[which(!is.na(matchIndexes)),]
DBACorDataDNAMeth <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal2(DBADataExpr[,iterer],DBADataDNAMeth[,iterer])
DBACorDataDNAMeth <- cbind(DBACorDataDNAMeth,c("2-cell","4-cell","8-cell","Morula","ICM","TE","E65Epi","E65Exe"),rep("DNAMeth",8))

DBADataExpr <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBADataExpr <- DBADataExpr[,c(4,1,2,3,5)]
DBADataExpr <- DBADataExpr[1:(nrow(DBADataExpr)-5),]
DBADataATAC <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/ATAC_DBA_2J_enhancer.csv",header=TRUE,row.names=1)
DBADataATAC <- DBADataATAC[,c(4,1,2,3,5)]
DBADataATAC <- DBADataATAC[1:(nrow(DBADataATAC)-5),]
matchIndexes <- match(rownames(DBADataATAC),rownames(DBADataExpr))
DBADataExpr <- DBADataExpr[matchIndexes[which(!is.na(matchIndexes))],]
DBADataATAC <- DBADataATAC[which(!is.na(matchIndexes)),]
DBACorDataATAC <- foreach(iterer=1:ncol(DBADataExpr),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(DBADataExpr[,iterer],DBADataATAC[,iterer])
DBACorDataATAC <- cbind(DBACorDataATAC,c("Early 2-cell","2-cell","4-cell","8-cell","ICM"),rep("ATAC",5))

statData <- as.data.frame(rbind(DBACorDataH3K9me3,DBACorDataH3K27me3,DBACorDataDNAMeth,DBACorDataATAC))
colnames(statData) <- c("corValue","pValue","stageName","epiName")
statData$corValue <- as.numeric(statData$corValue)
statData$pValue <- as.numeric(statData$pValue)
statData$pValue <- -log10(p.adjust(statData$pValue))
statData$epiName <- factor(statData$epiName,levels=c("ATAC","H3K9me3","H3K27me3","DNAMeth"))
statData$stageName <- factor(statData$stageName,levels=c("Oocyte","Early 2-cell","2-cell", "4-cell", "8-cell","Morula","ICM","TE","E65Epi","E65Exe"))

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Epigenome/PaternalEnhancerExprAndEpiSignalCorr.pdf",width=6,height=2.5)
p <- ggplot(statData, aes(x=stageName, y=epiName, size=pValue, color=corValue)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()