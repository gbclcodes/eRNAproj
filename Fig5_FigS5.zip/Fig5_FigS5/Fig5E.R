library(foreach)
library(doParallel)

calCommTarNum <- function(pair,network){
	Tars1 <- network[grep(pair[1],network[,1]),2]
	Tars2 <- network[grep(pair[2],network[,1]),2]
	return(length(intersect(Tars1,Tars2)))
}

# GSR
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_spenh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
EnhIDs <- enhancer.stages[,1]

# MIIOocyte
matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="MIIOocyte" & enhancer.stages[matchIndexesEnh2,3]=="MIIOocyte")
enhenhPairsMIIGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsMIIGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsMIIGSR),replace=TRUE)
randPairsMIIGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & enhancer.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cellGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsX2cellGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsX2cellGSR),replace=TRUE)
randPairsX2cellGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X4cell" & enhancer.stages[matchIndexesEnh2,3]=="X4cell")
enhenhPairsX4cellGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsX4cellGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsX4cellGSR),replace=TRUE)
randPairsX4cellGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X8cell" & enhancer.stages[matchIndexesEnh2,3]=="X8cell")
enhenhPairsX8cellGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsX8cellGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsX8cellGSR),replace=TRUE)
randPairsX8cellGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# Morula
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="morula" & enhancer.stages[matchIndexesEnh2,3]=="morula")
enhenhPairsMorulaGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsMorulaGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsMorulaGSR),replace=TRUE)
randPairsMorulaGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & enhancer.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMGSR),replace=TRUE)
randPairsICMGSR <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

EnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_table.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumMIIGSR <- foreach(iter=1:nrow(enhenhPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsMIIGSR[iter,]),EnhTarDataGSR)
RandNumMIIGSR <- foreach(iter=1:nrow(randPairsMIIGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsMIIGSR[iter,]),EnhTarDataGSR)

RealNumX2cellGSR <- foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR)
RandNumX2cellGSR <- foreach(iter=1:nrow(randPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsX2cellGSR[iter,]),EnhTarDataGSR)

RealNumX4cellGSR <- foreach(iter=1:nrow(enhenhPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX4cellGSR[iter,]),EnhTarDataGSR)
RandNumX4cellGSR <- foreach(iter=1:nrow(randPairsX4cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsX4cellGSR[iter,]),EnhTarDataGSR)

RealNumX8cellGSR <- foreach(iter=1:nrow(enhenhPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX8cellGSR[iter,]),EnhTarDataGSR)
RandNumX8cellGSR <- foreach(iter=1:nrow(randPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsX8cellGSR[iter,]),EnhTarDataGSR)

RealNumMorulaGSR <- foreach(iter=1:nrow(enhenhPairsMorulaGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsMorulaGSR[iter,]),EnhTarDataGSR)
RandNumMorulaGSR <- foreach(iter=1:nrow(randPairsMorulaGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsMorulaGSR[iter,]),EnhTarDataGSR)

RealNumICMGSR <- foreach(iter=1:nrow(enhenhPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsICMGSR[iter,]),EnhTarDataGSR)
RandNumICMGSR <- foreach(iter=1:nrow(randPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsICMGSR[iter,]),EnhTarDataGSR)

# XW
high.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.xw,median.enhancers.xw,low.enhancers.xw)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_spenh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
EnhIDs <- enhancer.stages[,1]

matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],enhancer.stages[,1])

# Zygote
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="Zygote" & enhancer.stages[matchIndexesEnh2,3]=="Zygote")
enhenhPairsZygoteXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsZygoteXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsZygoteXW),replace=TRUE)
randPairsZygoteXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# Early 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="E2C" & enhancer.stages[matchIndexesEnh2,3]=="E2C")
enhenhPairsE2CXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsE2CXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsE2CXW),replace=TRUE)
randPairsE2CXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="L2C" & enhancer.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2CXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsL2CXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsL2CXW),replace=TRUE)
randPairsL2CXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 4-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M4C" & enhancer.stages[matchIndexesEnh2,3]=="M4C")
enhenhPairsM4CXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsM4CXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsM4CXW),replace=TRUE)
randPairsM4CXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="M8C" & enhancer.stages[matchIndexesEnh2,3]=="M8C")
enhenhPairsM8CXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsM8CXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsM8CXW),replace=TRUE)
randPairsM8CXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & enhancer.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMXW),replace=TRUE)
randPairsICMXW <- cbind(EnhIDs[rowindexes],EnhIDs[colindexes])

EnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumZygoteXW <- foreach(iter=1:nrow(enhenhPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsZygoteXW[iter,]),EnhTarDataXW)
RandNumZygoteXW <- foreach(iter=1:nrow(randPairsZygoteXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsZygoteXW[iter,]),EnhTarDataXW)

RealNumE2CXW <- foreach(iter=1:nrow(enhenhPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsE2CXW[iter,]),EnhTarDataXW)
RandNumE2CXW <- foreach(iter=1:nrow(randPairsE2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsE2CXW[iter,]),EnhTarDataXW)

RealNumL2CXW <- foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW)
RandNumL2CXW <- foreach(iter=1:nrow(randPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsL2CXW[iter,]),EnhTarDataXW)

RealNumM4CXW <- foreach(iter=1:nrow(enhenhPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsM4CXW[iter,]),EnhTarDataXW)
RandNumM4CXW <- foreach(iter=1:nrow(randPairsM4CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsM4CXW[iter,]),EnhTarDataXW)

RealNumM8CXW <- foreach(iter=1:nrow(enhenhPairsM8CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsM8CXW[iter,]),EnhTarDataXW)
RandNumM8CXW <- foreach(iter=1:nrow(randPairsM8CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsM8CXW[iter,]),EnhTarDataXW)

RealNumICMXW <- foreach(iter=1:nrow(enhenhPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsICMXW[iter,]),EnhTarDataXW)
RandNumICMXW <- foreach(iter=1:nrow(randPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsICMXW[iter,]),EnhTarDataXW)

calCommTarNum <- function(pair,network1,network2){
	Tars1 <- network1[grep(pair[1],network1[,1]),2]
	Tars2 <- network2[grep(pair[2],network2[,1]),2]
	return(length(intersect(Tars1,Tars2)))
}

# GSR
high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

high.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_GSR.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_GSR.txt",header=FALSE,,stringsAsFactors=FALSE)
spenh.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)

enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_spenh_pairs_GSR_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EnhIDs <- rownames(mapInfo)
SpEnhIDs <- spenh.stages[,1]

matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],spenh.stages[,1])

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X2cell" & spenh.stages[matchIndexesEnh2,3]=="X2cell")
enhenhPairsX2cellGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsX2cellGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsX2cellGSR),replace=TRUE)
randPairsX2cellGSR <- cbind(EnhIDs[rowindexes],SpEnhIDs[colindexes])

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="X8cell" & spenh.stages[matchIndexesEnh2,3]=="X8cell")
enhenhPairsX8cellGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsX8cellGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsX8cellGSR),replace=TRUE)
randPairsX8cellGSR <- cbind(EnhIDs[rowindexes],SpEnhIDs[colindexes])

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & spenh.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMGSR <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMGSR),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMGSR),replace=TRUE)
randPairsICMGSR <- cbind(EnhIDs[rowindexes],SpEnhIDs[colindexes])

EnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
SpEnhTarDataGSR <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumX2cellGSRAdd <- foreach(iter=1:nrow(enhenhPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX2cellGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)
RandNumX2cellGSRAdd <- foreach(iter=1:nrow(randPairsX2cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsX2cellGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)

RealNumX8cellGSRAdd <- foreach(iter=1:nrow(enhenhPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsX8cellGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)
RandNumX8cellGSRAdd <- foreach(iter=1:nrow(randPairsX8cellGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsX8cellGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)

RealNumICMGSRAdd <- foreach(iter=1:nrow(enhenhPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsICMGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)
RandNumICMGSRAdd <- foreach(iter=1:nrow(randPairsICMGSR),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsICMGSR[iter,]),EnhTarDataGSR,SpEnhTarDataGSR)

# XW
high.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.xw,median.enhancers.xw,low.enhancers.xw)

high.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
spenh.stages <- rbind(high.enhancers.xw,median.enhancers.xw,low.enhancers.xw)
enhenhPairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_spenh_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
# enhenhPairs <- enhenhPairs[which(enhenhPairs[,7]=="inter-chrom"),]

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
EnhIDs <- rownames(mapInfo)
SpEnhIDs <- spenh.stages[,1]

matchIndexesEnh1 <- match(enhenhPairs[,1],enhancer.stages[,1])
matchIndexesEnh2 <- match(enhenhPairs[,2],spenh.stages[,1])

# 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="L2C" & spenh.stages[matchIndexesEnh2,3]=="L2C")
enhenhPairsL2CXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsL2CXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsL2CXW),replace=TRUE)
randPairsL2CXW <- cbind(EnhIDs[rowindexes],SpEnhIDs[colindexes])

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh1,3]=="ICM" & spenh.stages[matchIndexesEnh2,3]=="ICM")
enhenhPairsICMXW <- enhenhPairs[matchIndexesPairs,]
rowindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMXW),replace=TRUE)
colindexes <- sample(length(EnhIDs),nrow(enhenhPairsICMXW),replace=TRUE)
randPairsICMXW <- cbind(EnhIDs[rowindexes],SpEnhIDs[colindexes])

EnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
SpEnhTarDataXW <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
cl <- makeCluster(20)
registerDoParallel(cl)

RealNumL2CXWAdd <- foreach(iter=1:nrow(enhenhPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsL2CXW[iter,]),EnhTarDataXW,SpEnhTarDataXW)
RandNumL2CXWAdd <- foreach(iter=1:nrow(randPairsL2CXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsL2CXW[iter,]),EnhTarDataXW,SpEnhTarDataXW)

RealNumICMXWAdd <- foreach(iter=1:nrow(enhenhPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(enhenhPairsICMXW[iter,]),EnhTarDataXW,SpEnhTarDataXW)
RandNumICMXWAdd <- foreach(iter=1:nrow(randPairsICMXW),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% calCommTarNum(as.character(randPairsICMXW[iter,]),EnhTarDataXW,SpEnhTarDataXW)

gsr.res <- wilcox.test(c(RealNumMIIGSR,RealNumX2cellGSR,RealNumX4cellGSR,RealNumX8cellGSR,RealNumMorulaGSR,RealNumICMGSR,RealNumX2cellGSRAdd,RealNumX8cellGSRAdd,RealNumICMGSRAdd),c(RandNumMIIGSR,RandNumX2cellGSR,RandNumX4cellGSR,RandNumX8cellGSR,RandNumMorulaGSR,RandNumICMGSR,RandNumX2cellGSRAdd,RandNumX8cellGSRAdd,RandNumICMGSRAdd))
xw.res <- wilcox.test(c(RealNumZygoteXW,RealNumE2CXW,RealNumL2CXW,RealNumM4CXW,RealNumM8CXW,RealNumICMXW,RealNumL2CXWAdd,RealNumICMXWAdd),c(RandNumZygoteXW,RandNumE2CXW,RandNumL2CXW,RandNumM4CXW,RandNumM8CXW,RandNumICMXW,RandNumL2CXWAdd,RandNumICMXWAdd))

cat((gsr.res$p.value + xw.res$p.value)/2,"\n")

RealNumMII <- mean(c(RealNumMIIGSR))
RealNumMIISEM <- sd(RealNumMIIGSR)/sqrt(length(RealNumMIIGSR))
RealNumZygote <- mean(c(RealNumZygoteXW))
RealNumZygoteSEM <- sd(RealNumZygoteXW)/sqrt(length(RealNumZygoteXW))
RealNumE2C <- mean(c(RealNumE2CXW))
RealNumE2CSEM <- sd(RealNumE2CXW)/sqrt(length(RealNumE2CXW))
RealNumL2C <- mean(c(RealNumX2cellGSR,RealNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd))
RealNumL2CSEM <- sd(c(RealNumX2cellGSR,RealNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd))/sqrt(length(c(RealNumX2cellGSR,RealNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd)))
RealNumM4C <- mean(c(RealNumX4cellGSR,RealNumM4CXW))
RealNumM4CSEM <- sd(c(RealNumX4cellGSR,RealNumM4CXW))/sqrt(length(c(RealNumX4cellGSR,RealNumM4CXW)))
RealNumM8C <- mean(c(RealNumX8cellGSR,RealNumM8CXW,RealNumX8cellGSRAdd))
RealNumM8CSEM <- sd(c(RealNumX8cellGSR,RealNumM8CXW,RealNumX8cellGSRAdd))/sqrt(length(c(RealNumX8cellGSR,RealNumM8CXW,RealNumX8cellGSRAdd)))
RealNumMorula <- mean(c(RealNumMorulaGSR))
RealNumMorulaSEM <- sd(RealNumMorulaGSR)/sqrt(length(RealNumMorulaGSR))
RealNumICM <- mean(c(RealNumICMGSR,RealNumICMXW,RealNumICMXWAdd))
RealNumICMSEM <- sd(c(RealNumICMGSR,RealNumICMXW,RealNumICMGSRAdd,RealNumICMXWAdd))/sqrt(length(c(RealNumICMGSR,RealNumICMXW,RealNumICMGSRAdd,RealNumICMXWAdd)))

RandNumMII <- mean(c(RandNumMIIGSR))
RandNumMIISEM <- sd(RandNumMIIGSR)/sqrt(length(RandNumMIIGSR))
RandNumZygote <- mean(c(RandNumZygoteXW))
RandNumZygoteSEM <- sd(RandNumZygoteXW)/sqrt(length(RandNumZygoteXW))
RandNumE2C <- mean(c(RandNumE2CXW))
RandNumE2CSEM <- sd(RandNumE2CXW)/sqrt(length(RandNumE2CXW))
RandNumL2C <- mean(c(RandNumX2cellGSR,RandNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd))
RandNumL2CSEM <- sd(c(RandNumX2cellGSR,RandNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd))/sqrt(length(c(RandNumX2cellGSR,RandNumL2CXW,RealNumX2cellGSRAdd,RealNumL2CXWAdd)))
RandNumM4C <- mean(c(RandNumX4cellGSR,RandNumM4CXW))
RandNumM4CSEM <- sd(c(RandNumX4cellGSR,RandNumM4CXW))/sqrt(length(c(RandNumX4cellGSR,RandNumM4CXW)))
RandNumM8C <- mean(c(RandNumX8cellGSR,RandNumM8CXW,RealNumX8cellGSRAdd))
RandNumM8CSEM <- sd(c(RandNumX8cellGSR,RandNumM8CXW,RealNumX8cellGSRAdd))/sqrt(length(c(RandNumX8cellGSR,RandNumM8CXW,RealNumX8cellGSRAdd)))
RandNumMorula <- mean(c(RandNumMorulaGSR))
RandNumMorulaSEM <- sd(RandNumMorulaGSR)/sqrt(length(RandNumMorulaGSR))
RandNumICM <- mean(c(RandNumICMGSR,RandNumICMXW))
RandNumICMSEM <- sd(c(RandNumICMGSR,RandNumICMXW,RealNumICMGSRAdd,RealNumICMXWAdd))/sqrt(length(c(RandNumICMGSR,RandNumICMXW,RealNumICMGSRAdd,RealNumICMXWAdd)))


type <- rep(c("Real","Random"),c(length(c(RealNumMII,RealNumZygote,RealNumE2C,RealNumL2C,RealNumM4C,RealNumM8C,RealNumMorula,RealNumICM)),length(c(RandNumMII,RandNumZygote,RandNumE2C,RandNumL2C,RandNumM4C,RandNumM8C,RandNumMorula,RandNumICM))))
perc <- c(as.numeric(c(RealNumMII,RealNumZygote,RealNumE2C,RealNumL2C,RealNumM4C,RealNumM8C,RealNumMorula,RealNumICM)),as.numeric(c(RandNumMII,RandNumZygote,RandNumE2C,RandNumL2C,RandNumM4C,RandNumM8C,RandNumMorula,RandNumICM)))
sem <- c(as.numeric(c(RealNumMIISEM,RealNumZygoteSEM,RealNumE2CSEM,RealNumL2CSEM,RealNumM4CSEM,RealNumM8CSEM,RealNumMorulaSEM,RealNumICMSEM)),as.numeric(c(RandNumMIISEM,RandNumZygoteSEM,RandNumE2CSEM,RandNumL2CSEM,RandNumM4CSEM,RandNumM8CSEM,RandNumMorulaSEM,RandNumICMSEM)))
stage <- rep(rep(c("MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM"),c(length(RealNumMII),length(RealNumZygote),length(RealNumE2C),length(RealNumL2C),length(RealNumM4C),length(RealNumM8C),length(RealNumMorula),length(RealNumICM))),2)

statData <- as.data.frame(cbind(perc,sem,stage,type))
colnames(statData) <- c("perc","sem","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$sem <- as.numeric(statData$sem)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","M2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("Real","Random"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/SpENHData/spenhspenhcommTFs.pdf",width=10,height=5)				 
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + geom_errorbar(aes(x=stage, ymin=perc-sem, ymax=perc+sem), width=0.4, colour="black", alpha=0.9, size=1.3,position=position_dodge(.9))
print(p)
dev.off()

