C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
C57BLDataG <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_gene.csv",header=TRUE,row.names=1)
DBADataG <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_gene.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),] 
DBAData <- DBAData[1:(nrow(DBAData)-5),] 
AllDataG <- C57BLDataG + DBADataG

matchIndexes <- which(rowSums(C57BLData) > 8 | rowSums(DBAData) > 8)
C57BLData <- C57BLData[matchIndexes,]
DBAData <- DBAData[matchIndexes,]

for (iterer in seq(1,ncol(C57BLData))){
	baseNum <- sum(AllDataG[,iterer])/1000000
	C57BLData[,iterer] <- C57BLData[,iterer]/baseNum
}
C57BLData <- log2(C57BLData[,c(6,7,4,1,2,3,5)]+1)

for (iterer in seq(1,ncol(DBAData))){
	baseNum <- sum(AllDataG[,iterer])/1000000
	DBAData[,iterer] <- DBAData[,iterer]/baseNum
}
DBAData <- log2(DBAData[,c(6,7,4,1,2,3,5)]+1)

colnames(C57BLData) <- c("Oocyte","Zygote","E2C","M2C","M4C","M8C","ICM")
colnames(DBAData) <- c("Oocyte","Zygote","E2C","M2C","M4C","M8C","ICM")

library(RColorBrewer)
q4 = brewer.pal(4,'Set1')

library("vioplot")
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/ExprLevel.pdf",width=15,height=10)
vioplot(DBAData, side = "left", plotCentre = "line", col = q4[1], ylim=c(0,7))
vioplot(C57BLData, side = "right", plotCentre = "line", col = q4[2], ylim=c(0,7), add = TRUE)
legend("topleft", legend = c("Paternal", "Maternal"), fill = c(q4[1], q4[2]), cex = 1.25)
dev.off()

C57BLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",sep=" ",header=TRUE,row.names=1)
DBAData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_p.txt",sep=" ",header=TRUE,row.names=1)

TotalNum <- c(1823483,2320994,2333408,1585894,1532046,2105779,1762376)
matchIndexes <- which((rowSums(C57BLData) > 100 | rowSums(DBAData) > 100))
C57BLData <- C57BLData[matchIndexes,]
DBAData <- DBAData[matchIndexes,]

for (iterer in seq(1,ncol(C57BLData))){	
	baseNum <- TotalNum[iterer]/1000000
	C57BLData[,iterer] <- C57BLData[,iterer]/baseNum
}
C57BLData <- log2(C57BLData+1)

for (iterer in seq(1,ncol(DBAData))){	
	baseNum <- TotalNum[iterer]/1000000
	DBAData[,iterer] <- DBAData[,iterer]/baseNum
}
DBAData <- log2(DBAData+1)

library(RColorBrewer)
q4 = brewer.pal(4,'Set1')

colnames(C57BLData) <- c("Oocyte","Zygote","E2C","M2C","M4C","M8C","ICM")
colnames(DBAData) <- c("Oocyte","Zygote","E2C","M2C","M4C","M8C","ICM")

library("vioplot")
pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/ExprLevel.pdf",width=15,height=10)
vioplot(DBAData, side = "left", plotCentre = "line", col = q4[1],ylim=c(0,15))
vioplot(C57BLData, side = "right", plotCentre = "line", col = q4[2], ylim=c(0,15), add = TRUE)
legend("topleft", legend = c("Paternal", "Maternal"), fill = c(q4[1], q4[2]), cex = 1.25)
dev.off()