enhData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR/deepTools/enhancer_scaled.tab",header=TRUE,stringsAsFactors=FALSE,skip=2)
stageNames <- unique(colnames(enhData))
stageNames <- unique(gsub("\\.chr\\.sorted.*","",stageNames))

DNAMethSignal <- c()
for (stageName in stageNames){
	matchIndexes <- grep(stageName, colnames(enhData))
	if(length(DNAMethSignal)==0){
		DNAMethSignal <- rowMeans(enhData[,matchIndexes],na.rm=TRUE)
	}else{
		DNAMethSignal <- cbind(DNAMethSignal,rowMeans(enhData[,matchIndexes],na.rm=TRUE))
	}
}
colnames(DNAMethSignal) <- stageNames
write.table(DNAMethSignal,file="/media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR/deepTools/enhancer_DNAMeth_Signal.tab",col.names=TRUE,row.names=FALSE,quote=FALSE)
