# TE
corCal <- function(pair,tfData,enhData){
	matchIndexEnh <- match(pair[1],rownames(enhData))
	matchIndexTF <- match(pair[2],rownames(tfData))
	if(!is.na(matchIndexEnh) && !is.na(matchIndexTF)){
		if(sum(as.numeric(enhData[matchIndexEnh,])) > 0 && sum(as.numeric(tfData[matchIndexTF,])) > 0){ 
			corvalue <- cor(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			res <- cor.test(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			pvalue <- res$p.value
			return(c(corvalue,pvalue))
		}
	}
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# XW
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

tfMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfMData) <- gsub("\\.\\d+","",rownames(tfMData))
tfPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfPData) <- gsub("\\.\\d+","",rownames(tfPData))
enhMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
enhPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)

plotDataTFP <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhPData)
	corDataP <- cbind(corDataP,rep("TFP",nrow(corDataP)))
	if(length(plotDataTFP)==0){
		plotDataTFP <- corDataP
	}else{
		plotDataTFP <- rbind(plotDataTFP,corDataP)
	}
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhPData)
	corDataP <- cbind(corDataP,rep("TFP",nrow(corDataP)))
	plotDataTFP <- rbind(plotDataTFP,corDataP)

}

plotDataTFM <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhMData)
	corDataM <- cbind(corDataM,rep("TFM",nrow(corDataM)))
	if(length(plotDataTFM)==0){
		plotDataTFM <- corDataM
	}else{
		plotDataTFM <- rbind(plotDataTFM,corDataM)
	}
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhMData)
	corDataM <- cbind(corDataM,rep("TFM",nrow(corDataM)))
	plotDataTFM <- rbind(plotDataTFM,corDataM)
}


corCal <- function(pair,tfData,enhData){
	matchIndexEnh <- match(pair[1],rownames(enhData))
	matchIndexTF <- match(pair[2],rownames(tfData))
	if(!is.na(matchIndexEnh) && !is.na(matchIndexTF)){
		if(sum(as.numeric(enhData[matchIndexEnh,])) > 0 && sum(as.numeric(tfData[matchIndexTF,])) > 0){ 
			corvalue <- cor(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			res <- cor.test(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			pvalue <- res$p.value
			return(c(corvalue,pvalue))
		}
	}
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# XW
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

tfMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfMData) <- gsub("\\.\\d+","",rownames(tfMData))
tfPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfPData) <- gsub("\\.\\d+","",rownames(tfPData))
enhMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
enhPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)

plotDataeRNAP <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhPData)
	corDataP <- cbind(corDataP,rep("eRNAP",nrow(corDataP)))
	if(length(plotDataeRNAP)==0){
		plotDataeRNAP <- corDataP
	}else{
		plotDataeRNAP <- rbind(plotDataeRNAP,corDataP)
	}
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhPData)
	corDataP <- cbind(corDataP,rep("eRNAP",nrow(corDataP)))
	plotDataeRNAP <- rbind(plotDataeRNAP,corDataP)
}

plotDataeRNAM <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhMData)
	corDataM <- cbind(corDataM,rep("eRNAM",nrow(corDataM)))
	if(length(plotDataeRNAM)==0){
		plotDataeRNAM <- corDataM
	}else{
		plotDataeRNAM <- rbind(plotDataeRNAM,corDataM)
	}
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhMData)
	corDataM <- cbind(corDataM,rep("eRNAM",nrow(corDataM)))
	plotDataeRNAM <- rbind(plotDataeRNAM,corDataM)
}

plotData <- as.data.frame(rbind(plotDataTFP,plotDataTFM,plotDataeRNAP,plotDataeRNAM))
colnames(plotData) <- c("Cor","Pvalue","Stage")
plotData$Stage=factor(plotData$Stage,levels=c("TFP", "TFM", "eRNAP", "eRNAM"))
plotData$Cor <- as.numeric(plotData$Cor)
plotData$Pvalue <- -log10(as.numeric(plotData$Pvalue))
plotData <- plotData[which(plotData$Cor > 0),]

library(ggplot2)
library(RColorBrewer)
library(tidyverse)
library(ggbeeswarm)

q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/eRNATarCorr.pdf",width=8,height=6)
p <- ggplot(data=plotData, aes(x=Stage,y=Cor)) + geom_quasirandom(aes(color=Stage),method="frowney",width=0.3,size=1e-20) + scale_color_manual(values=q4[c(1,2,1,2)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean, geom="point", shape=20, size=10,  alpha=0.7, color="#8B814C")
p <- p + xlab("") + ylab("PCC") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()


# SE
corCal <- function(pair,tfData,enhData){
	matchIndexEnh <- match(pair[1],rownames(enhData))
	matchIndexTF <- match(pair[2],rownames(tfData))
	if(!is.na(matchIndexEnh) && !is.na(matchIndexTF)){
		if(sum(as.numeric(enhData[matchIndexEnh,])) > 0 && sum(as.numeric(tfData[matchIndexTF,])) > 0){ 
			corvalue <- cor(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			res <- cor.test(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			pvalue <- res$p.value
			return(c(corvalue,pvalue))
		}
	}
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# XW
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

tfMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfMData) <- gsub("\\.\\d+","",rownames(tfMData))
tfMData <- tfMData[,c(6,7,4,1,2,3,5)]
tfPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfPData) <- gsub("\\.\\d+","",rownames(tfPData))
tfPData <- tfPData[,c(6,7,4,1,2,3,5)]
enhMData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
enhPData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)

plotDataTFP <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhPData)
	corDataP <- cbind(corDataP,rep("TFP",nrow(corDataP)))
	if(length(plotDataTFP)==0){
		plotDataTFP <- corDataP
	}else{
		plotDataTFP <- rbind(plotDataTFP,corDataP)
	}
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhPData)
	corDataP <- cbind(corDataP,rep("TFP",nrow(corDataP)))
	plotDataTFP <- rbind(plotDataTFP,corDataP)

}

plotDataTFM <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhMData)
	corDataM <- cbind(corDataM,rep("TFM",nrow(corDataM)))
	if(length(plotDataTFM)==0){
		plotDataTFM <- corDataM
	}else{
		plotDataTFM <- rbind(plotDataTFM,corDataM)
	}
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhMData)
	corDataM <- cbind(corDataM,rep("TFM",nrow(corDataM)))
	plotDataTFM <- rbind(plotDataTFM,corDataM)
}


corCal <- function(pair,tfData,enhData){
	matchIndexEnh <- match(pair[1],rownames(enhData))
	matchIndexTF <- match(pair[2],rownames(tfData))
	if(!is.na(matchIndexEnh) && !is.na(matchIndexTF)){
		if(sum(as.numeric(enhData[matchIndexEnh,])) > 0 && sum(as.numeric(tfData[matchIndexTF,])) > 0){ 
			corvalue <- cor(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			res <- cor.test(as.numeric(enhData[matchIndexEnh,]),as.numeric(tfData[matchIndexTF,]),method="pearson")
			pvalue <- res$p.value
			return(c(corvalue,pvalue))
		}
	}
}

library(foreach)
library(doParallel)
cl <- makeCluster(20)
registerDoParallel(cl)

# XW
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/spenh_target_pairs_XW_all.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

tfMData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfMData) <- gsub("\\.\\d+","",rownames(tfMData))
tfMData <- tfMData[,c(6,7,4,1,2,3,5)]
tfPData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_gene.csv",row.names=1,header=TRUE,stringsAsFactors=FALSE)
rownames(tfPData) <- gsub("\\.\\d+","",rownames(tfPData))
tfPData <- tfPData[,c(6,7,4,1,2,3,5)]
enhMData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
enhPData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)

plotDataeRNAP <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhPData)
	corDataP <- cbind(corDataP,rep("eRNAP",nrow(corDataP)))
	if(length(plotDataeRNAP)==0){
		plotDataeRNAP <- corDataP
	}else{
		plotDataeRNAP <- rbind(plotDataeRNAP,corDataP)
	}
	corDataP <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhPData)
	corDataP <- cbind(corDataP,rep("eRNAP",nrow(corDataP)))
	plotDataeRNAP <- rbind(plotDataeRNAP,corDataP)
}

plotDataeRNAM <- c()
for (stageName in stageNames){
	matchIndexes <- match(tf.enh.pairs[,1],all.enhancers[which(all.enhancers[,3]==stageName),1])
	netData <- tf.enh.pairs[which(!is.na(matchIndexes)),c(1,2)]
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfPData,enhMData)
	corDataM <- cbind(corDataM,rep("eRNAM",nrow(corDataM)))
	if(length(plotDataeRNAM)==0){
		plotDataeRNAM <- corDataM
	}else{
		plotDataeRNAM <- rbind(plotDataeRNAM,corDataM)
	}
	corDataM <- foreach(iterer=1:nrow(netData),.combine=rbind,.multicombine=TRUE,.verbose=TRUE) %dopar% corCal(as.character(netData[iterer,]),tfMData,enhMData)
	corDataM <- cbind(corDataM,rep("eRNAM",nrow(corDataM)))
	plotDataeRNAM <- rbind(plotDataeRNAM,corDataM)
}

plotData <- as.data.frame(rbind(plotDataTFP,plotDataTFM,plotDataeRNAP,plotDataeRNAM))
colnames(plotData) <- c("Cor","Pvalue","Stage")
plotData$Stage=factor(plotData$Stage,levels=c("TFP", "TFM", "eRNAP", "eRNAM"))
plotData$Cor <- as.numeric(plotData$Cor)
plotData$Pvalue <- -log10(as.numeric(plotData$Pvalue))
plotData <- plotData[which(plotData$Cor > 0),]

library(ggplot2)
library(RColorBrewer)
library(tidyverse)
library(ggbeeswarm)

q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/seRNATarCorr.pdf",width=8,height=6)
p <- ggplot(data=plotData, aes(x=Stage,y=Cor)) + geom_quasirandom(aes(color=Stage),method="frowney",width=0.3,size=1e-20) + scale_color_manual(values=q4[c(1,2,1,2)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean, geom="point", shape=20, size=10,  alpha=0.7, color="#8B814C")
p <- p + xlab("") + ylab("PCC") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()