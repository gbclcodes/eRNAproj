library(pheatmap)
library(wesanderson)
library(dendextend)

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
expData <- cbind(C57BLData,DBAData)
expData <- expData[which(rowSums(expData) > 8),]
three.colors <- c(rev(wes_palette("Zissou1",2,type = "continuous")),"darkslateblue")

pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/HeatmapSamples.pdf",width=10,height=15)
p <- pheatmap(expData,show_rownames=FALSE,scale="row",cluster_rows=TRUE,cluster_cols=TRUE,clustering_distance_cols="correlation",fontsize=10)
dev.off()
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig6Data/Transcriptome/PolyACapturingRNAseeqData/ClusterSamples.pdf",width=10,height=15)
p.dend <- as.dendrogram(p$tree_col)
p.dend %>% set("labels_color",c(rep(three.colors[1:3],c(5,6,3)))) %>% set("hang") %>% set("branches_k_col", k = 3) %>% plot()
dev.off()

library(pheatmap)
library(wesanderson)
library(dendextend)

C57BLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",sep=" ",header=TRUE,row.names=1)
DBAData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_p.txt",sep=" ",header=TRUE,row.names=1)
colnames(C57BLData) <- c("Oocyte.M","Zygote.M","E2C.M","M2C.M","M4C.M","M8C.M","ICM.M")
colnames(DBAData) <- c("Oocyte.P","Zygote.P","E2C.P","M2C.P","M4C.P","M8C.P","ICM.P")
expData <- cbind(C57BLData,DBAData)
expData <- expData[which(rowSums(expData) > 1000),]
three.colors <- c(rev(wes_palette("Zissou1",2,type = "continuous")),"darkslateblue")

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/HeatmapSamples.pdf",width=10,height=15)
p <- pheatmap(expData,show_rownames=FALSE,scale="row",cluster_rows=TRUE,cluster_cols=TRUE,clustering_distance_cols="correlation",fontsize=10)
dev.off()

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/ClusterSamples.pdf",width=10,height=15)
p.dend <- as.dendrogram(p$tree_col)
p.dend %>% set("labels_color",c(rep(three.colors[1:3],c(4,4,6)))) %>% set("hang") %>% set("branches_k_col", k = 3) %>% plot()
dev.off()