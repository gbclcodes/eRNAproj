library(pheatmap)
library(wesanderson)
library(dendextend)

expData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/enhancer_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(expData) <- expData[,5]
sampInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/run2samplename.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
sampInfo[,2] <- factor(sampInfo[,2],levels=c("2-cell_1","2-cell_2","2-cell_3","2-cell_4","4-cell_1","4-cell_2","4-cell_3","4-cell_4","8-cell_1","8-cell_2","8-cell_3","morula_1","morula_2","ICM_1","ICM_2","ICM_3","ICM_4","TE_1","TE_2","TE_3","TE_4","E6.5_Epi_1","E6.5_Epi_2","E6.5_Exe_1","E6.5_Exe_2","MII-Oocyte_1","MII-Oocyte_2"),ordered=TRUE)
sampInfo <- sampInfo[order(sampInfo[,2]),]
matchIndexes <- match(sampInfo[,1],colnames(expData))
expData <- expData[,matchIndexes]
colnames(expData) <- as.character(sampInfo[,2])
expData <- expData[,c("2-cell_1","2-cell_2","2-cell_3","2-cell_4","4-cell_1","4-cell_2","4-cell_3","4-cell_4","8-cell_1","8-cell_3","morula_1","morula_2","ICM_1","ICM_4","TE_1","TE_2","E6.5_Epi_1","E6.5_Epi_2","E6.5_Exe_1","E6.5_Exe_2","MII-Oocyte_1","MII-Oocyte_2")]
expData <- expData[which(rowSums(expData) > 0),]
nine.colors <- c(rev(wes_palette("Zissou1",8,type = "continuous")),"darkslateblue")

pdf(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/SRRexprfiles/enhancer_expr_sample_cluster_res_GSR.pdf",width=10,height=15)
p <- pheatmap(expData,show_rownames=FALSE,scale="row",cluster_rows=FALSE,cluster_cols=TRUE,clustering_distance_cols="correlation",fontsize=10)
p.dend <- as.dendrogram(p$tree_col)
p.dend <- reorder(p.dend,seq(1,22),agglo.FUN=mean)
p.dend %>% set("labels_color",c(rep(nine.colors[8:5],c(4,4,2,2)),rep(nine.colors[1:4],c(2,2,2,2)),rep(nine.colors[9],2))) %>% set("hang") %>% set("branches_k_col", k = 4) %>% plot()
dev.off()
