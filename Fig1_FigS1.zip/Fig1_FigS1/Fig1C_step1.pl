use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$bedfile,$mapfile,$type,$help);
GetOptions(
	"inputdir=s" => \$inputdir,
    "bedfile=s" => \$bedfile,
	"mapfile=s" => \$mapfile,
	"type=s" => \$type,
	"help!" => \$help,
);

my %mapHash;
open(MAP,"<$mapfile") or die "$!\n";
while(<MAP>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\t/,$line;
	$fieldValues[3] =~ /.*\/(.*).bigWig/;
    my $sample_id = $1;
	$mapHash{$sample_id} = $fieldValues[1];
}
close MAP;

my @samples = `find $inputdir -name "*bigWig"`;
foreach my $sample (@samples){
    chomp $sample;
    $sample =~ /.*\/(.*).bigWig/;
    my $sample_id = $1;
    if($mapHash{$sample_id} =~ /ES/){
		if(!-e "$inputdir/${sample_id}_$type\_ES.bed" || -z "$inputdir/${sample_id}_$type\_ES.bed"){
			open(SH,">$inputdir/${sample_id}_bigWigAverageOverBed.sh") or die "$!\n";
			print SH "/media/yuhua/yuhua_projects/software/bigWigAverageOverBed $sample $bedfile $inputdir/$sample_id\_$type.tab -bedOut=$inputdir/${sample_id}_$type\_ES.bed\n";
			close SH;
			
			my $taskNum =`ps -aux | grep bigWigAverageOverBed | wc -l`; 
			while($taskNum > 20){
				print "The num of task remaining $taskNum\n";
				sleep 30;
				print `date`;
				$taskNum = `ps -aux | grep bigWigAverageOverBed | wc -l`;
			}
			
			my $out = system("sh $inputdir/${sample_id}_bigWigAverageOverBed.sh 1>>$inputdir/${sample_id}_bigWigAverageOverBed.log 2>>$inputdir/${sample_id}_bigWigAverageOverBed.err &");
			if($out==0){
				print "The task of $sample_id is successfully submitted\n";
			}
		}
	}
}


# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_expr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/H3K4me1_sample.tsv --type Expr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_expr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/H3K27ac_sample.tsv --type Expr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_expr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/CTCF_sample.tsv --type Expr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_expr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/EP300_sample.tsv --type Expr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_expr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/POLR2A_sample.tsv --type Expr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_nonexpr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/H3K4me1_sample.tsv --type NonExpr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_nonexpr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/H3K27ac_sample.tsv --type NonExpr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_nonexpr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/CTCF_sample.tsv --type NonExpr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300 --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_nonexpr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/EP300_sample.tsv --type NonExpr_ICM_Enhancer &

# perl fig1g_step1.pl --inputdir /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A --bedfile /media/yuhua/yuhua_projects/enhProj/ENHData/ICM_nonexpr_enh_tss.bed --mapfile /media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/POLR2A_sample.tsv --type NonExpr_ICM_Enhancer &

