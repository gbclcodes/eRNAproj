#!/bin/bash

#SBATCH -p amd-ep2			
#SBATCH -q normal
#SBATCH --cpus-per-task 4
#SBATCH --ntasks-per-node 1
#SBATCH -J MIIOocyte				
#SBATCH -c 4
#SBATCH --mem 120G 					
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIOocyte/MIIOocyte.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIOocyte/MIIOocyte.err

/storage/gbcl/yuhua/yuhua_projects/enhProj/software/HiC-Pro/bin/utils/hicpro2juicebox.sh -i /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_8cell_rep123.allValidPairs -g /storage/gbcl/yuhua/yuhua_projects/enhProj/software/HiC-Pro_2.11.0-beta/annotation/chrom_mm9.sizes -j /storage/gbcl/yuhua/yuhua_projects/enhProj/software/juicer_tools_1.22.01.jar -r /storage/gbcl/yuhua/yuhua_projects/enhProj/software/HiC-Pro_2.11.0-beta/annotation/mm9_mboi.bed -o /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIOocyte