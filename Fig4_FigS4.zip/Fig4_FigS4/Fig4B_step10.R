spNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
enhNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
colnames(enhNet) <- c("EID","TFID","RS","StageName","TFName")
mapInfo <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/GSR_EPM.SuperE3.csv",header=TRUE,stringsAsFactors=FALSE)
mapInfo <- mapInfo[,c(1,16)]

library(dplyr) 
outNet <- c()
for (rowi in seq(1,nrow(mapInfo))){
	enhids <- unlist(strsplit(mapInfo[rowi,2],";"))
	matchIndexes <- match(enhids,enhNet[,1])
	matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
	if(length(matchIndexes) > 0){
		unitNet <- enhNet[matchIndexes,]
		unitNet[,1] <- mapInfo[rowi,1]
		unitNet <- unitNet %>% group_by(TFID,StageName,TFName) %>% summarise_at(vars(RS),list(RS = mean))
		unitNet <- as.data.frame(unitNet)
		unitNet <- cbind(rep(mapInfo[rowi,1],nrow(unitNet)),unitNet)
		if(length(outNet)==0){
			outNet <- unitNet
		}else{
			outNet <- rbind(outNet,unitNet)
		}
	}		
}

colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
spNet <- spNet[,c(1,2,4,5,3)]
colnames(spNet) <- c("EID","TFID","StageName","TFName","RS")
matchIndexes <- match(paste(spNet[,1],spNet[,2],sep="--"),paste(outNet[,1],outNet[,2],sep="--"))
outNet <- rbind(outNet,spNet[which(is.na(matchIndexes)),])
colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
outNet <- outNet[,c(1,2,5,3,4)]
write.table(outNet,file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_whole.txt",row.names=FALSE,col.names=FALSE)


spNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
enhNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
colnames(enhNet) <- c("EID","TFID","RS","StageName","TFName")
mapInfo <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/GSR_EPM.SuperE3.csv",header=TRUE,stringsAsFactors=FALSE)
mapInfo <- mapInfo[,c(1,16)]

library(dplyr) 
outNet <- c()
for (rowi in seq(1,nrow(mapInfo))){
	enhids <- unlist(strsplit(mapInfo[rowi,2],";"))
	matchIndexes <- match(enhids,enhNet[,1])
	matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
	if(length(matchIndexes) > 0){
		unitNet <- enhNet[matchIndexes,]
		unitNet[,1] <- mapInfo[rowi,1]
		unitNet <- unitNet %>% group_by(TFID,StageName,TFName) %>% summarise_at(vars(RS),list(RS = mean))
		unitNet <- as.data.frame(unitNet)
		unitNet <- cbind(rep(mapInfo[rowi,1],nrow(unitNet)),unitNet)
		if(length(outNet)==0){
			outNet <- unitNet
		}else{
			outNet <- rbind(outNet,unitNet)
		}
	}		
}

colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
spNet <- spNet[,c(1,2,4,5,3)]
colnames(spNet) <- c("EID","TFID","StageName","TFName","RS")
matchIndexes <- match(paste(spNet[,1],spNet[,2],sep="--"),paste(outNet[,1],outNet[,2],sep="--"))
outNet <- rbind(outNet,spNet[which(is.na(matchIndexes)),])
colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
outNet <- outNet[,c(1,2,5,3,4)]
write.table(outNet,file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_whole.txt",row.names=FALSE,col.names=FALSE)


# Analysis
spNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)
enhNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
colnames(enhNet) <- c("EID","TFID","RS","StageName","TFName")
mapInfo <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/GSR_EPM.SuperE3.csv",header=TRUE,stringsAsFactors=FALSE)
mapInfo <- mapInfo[,c(1,16)]

library(dplyr) 
outNet <- c()
for (rowi in seq(1,nrow(mapInfo))){
	enhids <- unlist(strsplit(mapInfo[rowi,2],";"))
	matchIndexes <- match(enhids,enhNet[,1])
	matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
	if(length(matchIndexes) > 0){
		unitNet <- enhNet[matchIndexes,]
		unitNet[,1] <- mapInfo[rowi,1]
		unitNet <- unitNet %>% group_by(TFID,StageName,TFName) %>% summarise_at(vars(RS),list(RS = mean))
		unitNet <- as.data.frame(unitNet)
		unitNet <- cbind(rep(mapInfo[rowi,1],nrow(unitNet)),unitNet)
		if(length(outNet)==0){
			outNet <- unitNet
		}else{
			outNet <- rbind(outNet,unitNet)
		}
	}		
}

colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
spNet <- spNet[,c(1,2,4,5,3)]
colnames(spNet) <- c("EID","TFID","StageName","TFName","RS")
matchIndexes <- match(paste(spNet[,1],spNet[,2],sep="--"),paste(outNet[,1],outNet[,2],sep="--"))
outNet <- rbind(outNet,spNet[which(is.na(matchIndexes)),])
colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
outNet <- outNet[,c(1,2,5,3,4)]
outNet[,5] <- toupper(outNet[,5])
write.table(outNet,file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_whole_ana.txt",row.names=FALSE,col.names=FALSE)


spNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final_ana.txt",header=FALSE,stringsAsFactors=FALSE)
enhNet <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
colnames(enhNet) <- c("EID","TFID","RS","StageName","TFName")
mapInfo <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/GSR_EPM.SuperE3.csv",header=TRUE,stringsAsFactors=FALSE)
mapInfo <- mapInfo[,c(1,16)]

library(dplyr) 
outNet <- c()
for (rowi in seq(1,nrow(mapInfo))){
	enhids <- unlist(strsplit(mapInfo[rowi,2],";"))
	matchIndexes <- match(enhids,enhNet[,1])
	matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
	if(length(matchIndexes) > 0){
		unitNet <- enhNet[matchIndexes,]
		unitNet[,1] <- mapInfo[rowi,1]
		unitNet <- unitNet %>% group_by(TFID,StageName,TFName) %>% summarise_at(vars(RS),list(RS = mean))
		unitNet <- as.data.frame(unitNet)
		unitNet <- cbind(rep(mapInfo[rowi,1],nrow(unitNet)),unitNet)
		if(length(outNet)==0){
			outNet <- unitNet
		}else{
			outNet <- rbind(outNet,unitNet)
		}
	}		
}

colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
spNet <- spNet[,c(1,2,4,5,3)]
colnames(spNet) <- c("EID","TFID","StageName","TFName","RS")
matchIndexes <- match(paste(spNet[,1],spNet[,2],sep="--"),paste(outNet[,1],outNet[,2],sep="--"))
outNet <- rbind(outNet,spNet[which(is.na(matchIndexes)),])
colnames(outNet) <- c("EID","TFID","StageName","TFName","RS")
outNet <- outNet[,c(1,2,5,3,4)]
outNet[,5] <- toupper(outNet[,5])
write.table(outNet,file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_whole_ana.txt",row.names=FALSE,col.names=FALSE)