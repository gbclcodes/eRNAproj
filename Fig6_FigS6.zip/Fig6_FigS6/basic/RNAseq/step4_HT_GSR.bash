#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J HT
#SBATCH -c 1
#SBATCH --mem 10G
#SBATCH -o /storage/gbcl/qiaolu/GSRresult/HT.log
#SBATCH -e /storage/gbcl/qiaolu/GSRresult/HT.err

cd /storage/gbcl/qiaolu/GSRresult

ls *.bam | while read id; do (samtools sort -n $id -o /storage/gbcl/qiaolu/GSRresult/byname/${id:0:18}.byname.bam); done
cd /storage/gbcl/qiaolu/GSRresult/byname
ls *.bam | while read file; do (htseq-count -c ${file:0:18}_genome.csv -f bam -s no --nonunique all -q $file /storage/gbcl/qiaolu/new_gencode.vM17.annotation.gff3); done
ls *.bam | while read file; do (htseq-count -c ${file:0:18}.csv -f bam -s no -i Name -t BED_feature --nonunique all -q $file /storage/gbcl/qiaolu/EpiData/H3K27me3Fer_MD/result/enhancer_GSR_new.gff3); done