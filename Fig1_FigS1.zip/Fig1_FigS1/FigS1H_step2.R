enhExpDataMap <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.txt",sep=" ",header=TRUE,row.names=1,stringsAsFactors=FALSE)
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/enhancer_TPM.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
rownames(enhExpData) <- rownames(enhExpDataMap)
enhTSscoreData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores_XW.txt",sep=" ",header=FALSE,stringsAsFactors=FALSE)
highenhancers <- enhTSscoreData[which(enhTSscoreData[,2] > 0.7),1]
medianenhancers <- enhTSscoreData[which(enhTSscoreData[,2] < 0.7 & enhTSscoreData[,2] > 0.3),1]
lowenhancers <- enhTSscoreData[which(enhTSscoreData[,2] < 0.3),1]

matchIndexes <- match(highenhancers,rownames(enhExpData))
highexprlevels <- apply(enhExpData[matchIndexes,],1,max)
matchIndexes <- match(medianenhancers,rownames(enhExpData))
medianexprlevels <- apply(enhExpData[matchIndexes,],1,max)
matchIndexes <- match(lowenhancers,rownames(enhExpData))
lowexprlevels <- apply(enhExpData[matchIndexes,],1,max)

exprlevels <- c(highexprlevels,medianexprlevels,lowexprlevels)
exprtypes <- rep(c("High","Median","Low"),c(length(highexprlevels),length(medianexprlevels),length(lowexprlevels)))

df <- as.data.frame(cbind(exprlevels,exprtypes))
colnames(df) <- c("exprlevels","exprtypes")
df$exprtypes <- factor(exprtypes,levels=c("High","Median","Low"))
df$exprlevels <- as.numeric(exprlevels)

library(tidyverse)
library(ggplot2)
library(ggbeeswarm)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')

pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/stage_specific_enhancer_expr_level_beeswarm_boxplot_ggplot2_XW.pdf",width=6,height=6)
p <- ggplot(data=df, aes(x=exprtypes,y=exprlevels)) + geom_quasirandom(aes(color=exprtypes),method="frowney",width=0.4,size=1e-20) + scale_color_manual(values=q4[c(1,2,4)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,0.05) + xlab("") + ylab("Expression") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()


geneExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/gene_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(geneExpData) <- geneExpData[,1]
geneExpData[,c(1,2)] <- NULL 
mRNATSscoreData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/mRNA_stage_specific_scores_XW.txt",sep=" ",header=FALSE,stringsAsFactors=FALSE)
highmRNA <- mRNATSscoreData[which(mRNATSscoreData[,2] > 0.7),1]
medianmRNA <- mRNATSscoreData[which(mRNATSscoreData[,2] < 0.7 & mRNATSscoreData[,2] > 0.3),1]
lowmRNA <- mRNATSscoreData[which(mRNATSscoreData[,2] < 0.3),1]

matchIndexes <- match(highmRNA,rownames(geneExpData))
highexprlevels <- apply(geneExpData[matchIndexes,],1,max)
matchIndexes <- match(medianmRNA,rownames(geneExpData))
medianexprlevels <- apply(geneExpData[matchIndexes,],1,max)
matchIndexes <- match(lowmRNA,rownames(geneExpData))
lowexprlevels <- apply(geneExpData[matchIndexes,],1,max)

exprlevels <- c(highexprlevels,medianexprlevels,lowexprlevels)
exprtypes <- rep(c("High","Median","Low"),c(length(highexprlevels),length(medianexprlevels),length(lowexprlevels)))

df <- as.data.frame(cbind(exprlevels,exprtypes))
colnames(df) <- c("exprlevels","exprtypes")
df$exprtypes <- factor(exprtypes,levels=c("High","Median","Low"))
df$exprlevels <- as.numeric(exprlevels)

pdf("/media/yuhua/yuhua_projects/enhProj/GENEData/stage_specific_mRNA_expr_level_beeswarm_boxplot_ggplot2_XW.pdf",width=6,height=6)
p <- ggplot(data=df, aes(x=exprtypes,y=exprlevels)) + geom_quasirandom(aes(color=exprtypes),method="frowney",width=0.3,size=1e-20) + scale_color_manual(values=q4[c(1,2,4)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,200) + xlab("") + ylab("Expression") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off() 


geneExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/gene_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(geneExpData) <- geneExpData[,1]
geneExpData[,c(1,2)] <- NULL 
lncRNATSscoreData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_scores_XW.txt",sep=" ",header=FALSE,stringsAsFactors=FALSE)
highlncRNA <- lncRNATSscoreData[which(lncRNATSscoreData[,2] > 0.7),1]
medianlncRNA <- lncRNATSscoreData[which(lncRNATSscoreData[,2] < 0.7 & lncRNATSscoreData[,2] > 0.3),1]
lowlncRNA <- lncRNATSscoreData[which(lncRNATSscoreData[,2] < 0.3),1]

matchIndexes <- match(highlncRNA,rownames(geneExpData))
highexprlevels <- apply(geneExpData[matchIndexes,],1,max)
matchIndexes <- match(medianlncRNA,rownames(geneExpData))
medianexprlevels <- apply(geneExpData[matchIndexes,],1,max)
matchIndexes <- match(lowlncRNA,rownames(geneExpData))
lowexprlevels <- apply(geneExpData[matchIndexes,],1,max)

exprlevels <- c(highexprlevels,medianexprlevels,lowexprlevels)
exprtypes <- rep(c("High","Median","Low"),c(length(highexprlevels),length(medianexprlevels),length(lowexprlevels)))

df <- as.data.frame(cbind(exprlevels,exprtypes))
colnames(df) <- c("exprlevels","exprtypes")
df$exprtypes <- factor(exprtypes,levels=c("High","Median","Low"))
df$exprlevels <- as.numeric(exprlevels)

pdf("/media/yuhua/yuhua_projects/enhProj/GENEData/stage_specific_lncRNA_expr_level_beeswarm_boxplot_ggplot2_XW.pdf",width=6,height=6)
p <- ggplot(data=df, aes(x=exprtypes,y=exprlevels)) + geom_quasirandom(aes(color=exprtypes),method="frowney",width=0.3,size=1e-20) + scale_color_manual(values=q4[c(1,2,4)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=mean,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + ylim(0,10) + xlab("") + ylab("Expression") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()
