library(reshape2)
library(plyr)
library(Matrix)
library(foreach)
library(doParallel)

mapBin <- function(vec,binMat){
   vec <- unlist(strsplit(vec,"\t"))
   binIndexes <- binMat[which(binMat[,1] == vec[1] & ((binMat[,2] >= as.numeric(vec[2]) & (binMat[,2]) <= as.numeric(vec[3])) | (binMat[,3] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])) | (binMat[,2] <= as.numeric(vec[2]) & (binMat[,3]) >= as.numeric(vec[3])) | (binMat[,2] >= as.numeric(vec[2]) & (binMat[,3]) <= as.numeric(vec[3])))),4]
   return(binIndexes)
}

OEvalueCal <- function(enhTarPair,genePosInfo,enhPosInfo,contactMatrix,mapData){
	matchIndexEnh <- match(enhTarPair[1],enhPosInfo[,4])
	matchIndexGene <- match(enhTarPair[2],genePosInfo[,4])
	enhBins <- as.numeric(unlist(sapply(paste(enhPosInfo[matchIndexEnh,1],enhPosInfo[matchIndexEnh,2],enhPosInfo[matchIndexEnh,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
	geneBins <- as.numeric(unlist(sapply(paste(genePosInfo[matchIndexGene,1],genePosInfo[matchIndexGene,2],genePosInfo[matchIndexGene,3],sep="\t"),mapBin,mapData,simplify=TRUE)))
	if(length(enhBins) > 0 && length(geneBins) > 0){
		return(c(sum(contactMatrix[enhBins,geneBins] + t(contactMatrix[geneBins,enhBins]))))
	}
}

high.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancers.gsr <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.stages <- rbind(high.enhancers.gsr,median.enhancers.gsr,low.enhancers.gsr)
target.stages <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/gene_stage_specific_scores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])
enhTarPairs <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/spenh_target_pairs_XW_all.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

# MIIOocyte
matchIndexesEnh <- match(enhTarPairs[,1],enhancer.stages[,1])
matchIndexesTar <- match(enhTarPairs[,2],target.stages[,1])
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII <- enhTarPairs[matchIndexesPairs,]

# Early 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
enhTarPairsE2C <- enhTarPairs[matchIndexesPairs,]

# Late 2-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
enhTarPairsL2C <- enhTarPairs[matchIndexesPairs,]

# 8-cell
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
enhTarPairsM8C <- enhTarPairs[matchIndexesPairs,]

# ICM
matchIndexesPairs <- which(enhancer.stages[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM <- enhTarPairs[matchIndexesPairs,]

mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/GSE82185_MII_rep12_20000_abs.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
genePosInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/known_genes_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhPosInfo <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/SuperE3_mm9.bed",sep="\t",header=FALSE,stringsAsFactors=FALSE)

cl <- makeCluster(20)
registerDoParallel(cl)

MIIData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/MIIoocyte_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatMII <- sparseMatrix(as.numeric(MIIData[,1]), as.numeric(MIIData[,2]), x = as.numeric(MIIData[,3]))
rm(MIIData)
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
try(enhTarPairsOEvecMII <- foreach(iterer=1:nrow(enhTarPairsMII),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsMII[iterer,]),genePosInfo,enhPosInfo,freqMatMII,mapData))
save(enhTarPairsOEvecMII,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhTarPairOEvecMIIXW.RData")

E2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/E2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatE2C <- sparseMatrix(as.numeric(E2CData[,1]), as.numeric(E2CData[,2]), x = as.numeric(E2CData[,3]))
rm(E2CData)
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
try(enhTarPairsOEvecE2C <- foreach(iter=1:nrow(enhTarPairsE2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsE2C[iter,]),genePosInfo,enhPosInfo,freqMatE2C,mapData))
save(enhTarPairsOEvecE2C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhTarPairOEvecE2CXW.RData")

L2CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatL2C <- sparseMatrix(as.numeric(L2CData[,1]), as.numeric(L2CData[,2]), x = as.numeric(L2CData[,3]))
rm(L2CData)
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
try(enhTarPairsOEvecL2C <- foreach(iter=1:nrow(enhTarPairsL2C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsL2C[iter,]),genePosInfo,enhPosInfo,freqMatL2C,mapData))
save(enhTarPairsOEvecL2C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhTarPairOEvecL2CXW.RData")

M8CData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/M8C_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatM8C <- sparseMatrix(as.numeric(M8CData[,1]), as.numeric(M8CData[,2]), x = as.numeric(M8CData[,3]))
rm(M8CData)
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
try(enhTarPairsOEvecM8C <- foreach(iter=1:nrow(enhTarPairsM8C),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsM8C[iter,]),genePosInfo,enhPosInfo,freqMatM8C,mapData))
save(enhTarPairsOEvecM8C,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhTarPairOEvecM8CXW.RData")

ICMData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/ICM_corrected_obsexp_20000.matrix",sep="\t",header=FALSE,stringsAsFactors=FALSE)
freqMatICM <- sparseMatrix(as.numeric(ICMData[,1]), as.numeric(ICMData[,2]), x = as.numeric(ICMData[,3]))
rm(ICMData)
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
try(enhTarPairsOEvecICM <- foreach(iter=1:nrow(enhTarPairsICM),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% OEvalueCal(as.character(enhTarPairsICM[iter,]),genePosInfo,enhPosInfo,freqMatICM,mapData))
save(enhTarPairsOEvecICM,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/spenhTarPairOEvecICMXW.RData")
stopCluster(cl)
