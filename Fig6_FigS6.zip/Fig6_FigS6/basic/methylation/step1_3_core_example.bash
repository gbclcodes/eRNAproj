#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J SRR5479516
#SBATCH -c 3
#SBATCH --mem 150G
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479516.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479516.err

cd /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping
module load bowtie/2.4.2 
module load samtools/1.14
/storage/gbcl/qiaolu/Bismark-0.23.0/bismark --parallel 3 -p 3 --bowtie2 --score_min L,0,-0.6 --genome /storage/gbcl/qiaolu/EpiData/METH -1 /storage/gbcl/qiaolu/EpiData/DNAMethData/SRR5479516_1.fastq -2 /storage/gbcl/qiaolu/EpiData/DNAMethData/SRR5479516_2.fastq -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping/SRR5479516 
