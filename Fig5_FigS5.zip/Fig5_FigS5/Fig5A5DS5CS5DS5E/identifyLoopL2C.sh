#!/bin/bash

#SBATCH -n 1
#SBATCH -q gpu
#SBATCH --gres gpu:1
#SBATCH -J identifyloopL2C
#SBATCH -p v100-quad 
#SBATCH --mem 100G 					
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/loopData/L2C/L2C.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/loopData/L2C/L2C.err

source ~/.bashrc
module load cuda/10.1
java -jar /storage/gbcl/yuhua/yuhua_projects/enhProj/software/juicer_tools_1.22.01.jar hiccups --ignore-sparsity -m 512 -c chr1,chr2,chr3,chr4,chr5,chr6,chr7,chr8,chr9,chr10,chr11,chr12,chr13,chr14,chr15,chr16,chr17,chr18,chr19,chrX,chrY,chrM -r 5000,10000 -k KR -f 0.1,0.1 -p 4,2 -i 7,5 -t 0.02,1.5,1.75,2 -d 20000,20000 /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/L2C/ /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/loopData/L2C