expData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/enhancer_counts.txt",sep='\t',header=TRUE,row.names=1,stringsAsFactors=FALSE) 
rownames(expData) <- expData[,1]
expData[,1] <- NULL
mapData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/H3K27me3_run2samplename.txt",sep="\t")

expData.m <- expData[,grep("genome1",colnames(expData))]
colnames(expData.m) <- gsub(".genome1","",colnames(expData.m))
combData.m <- c()
stageNames <- c("MII Oocyte","2 cell","4 cell","8 cell","morula","ICM","TE","E65Epi","E65Exe")
for (stagename in stageNames){
	matchIndexes <- grep(stagename,mapData[,2])
	matchIndexes <- match(mapData[matchIndexes,1],colnames(expData.m))
	if(length(combData.m)==0){
		combData.m <- rowSums(expData.m[,matchIndexes])
	}else{
		combData.m <- cbind(combData.m,rowSums(expData.m[,matchIndexes]))
	}
}
combData.m <- combData.m[1:(nrow(combData.m)-5),]
colnames(combData.m) <-c("Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E65Epi","E65Exe")
write.table(combData.m,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/enhancer_counts_m.txt",row.names=TRUE,col.names=TRUE,quote=FALSE)

expData.p <- expData[,grep("genome2",colnames(expData))]
colnames(expData.p) <- gsub(".genome2","",colnames(expData.m))
combData.p <- c()
stageNames <- c("MII Oocyte","2 cell","4 cell","8 cell","morula","ICM","TE","E65Epi","E65Exe")
for (stagename in stageNames){
	matchIndexes <- grep(stagename,mapData[,2])
	matchIndexes <- match(mapData[matchIndexes,1],colnames(expData.p))
	if(length(combData.p)==0){
		combData.p <- rowSums(expData.p[,matchIndexes])
	}else{
		combData.p <- cbind(combData.p,rowSums(expData.p[,matchIndexes]))
	}
}
combData.p <- combData.p[1:(nrow(combData.p)-5),]
colnames(combData.p) <- c("Oocyte","2-cell","4-cell","8-cell","morula","ICM","TE","E65Epi","E65Exe")
write.table(combData.p,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Epigenome/H3K27me3/htseqcountfile/enhancer_counts_p.txt",row.names=TRUE,col.names=TRUE,quote=FALSE)