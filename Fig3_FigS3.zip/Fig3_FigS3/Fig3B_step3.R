# Regulatory ratio
# GSR
DevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/devgenes.txt",header=FALSE,stringsAsFactors=FALSE)
NonDevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/nondevgenes.txt",header=FALSE,stringsAsFactors=FALSE)

high.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_GSR_subset.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancer.gsr,median.enhancer.gsr,low.enhancer.gsr)

target.stages <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_GSR_subset.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])
enhTarPairsDev <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_devgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhTarPairsNonDev <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_nondevgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

# Developmental genes
matchIndexesTar <- match(enhTarPairsDev[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairsDev[,1],enhancer.gsr[,1])

MIIDevNum <- match(target.stages[which(target.stages[,3]=="MIIOocyte"),1],DevGenesData[,1])
MIIDevNum <- length(which(!is.na(MIIDevNum)))

M2CDevNum <- match(target.stages[which(target.stages[,3]=="X2cell"),1],DevGenesData[,1])
M2CDevNum <- length(which(!is.na(M2CDevNum)))

M4CDevNum <- match(target.stages[which(target.stages[,3]=="X4cell"),1],DevGenesData[,1])
M4CDevNum <- length(which(!is.na(M4CDevNum)))

M8CDevNum <- match(target.stages[which(target.stages[,3]=="X8cell"),1],DevGenesData[,1])
M8CDevNum <- length(which(!is.na(M8CDevNum)))

MorulaDevNum <- match(target.stages[which(target.stages[,3]=="morula"),1],DevGenesData[,1])
MorulaDevNum <- length(which(!is.na(MorulaDevNum)))

ICMDevNum <- match(target.stages[which(target.stages[,3]=="ICM"),1],DevGenesData[,1])
ICMDevNum <- length(which(!is.na(ICMDevNum)))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.dev <- enhTarPairsDev[matchIndexesPairs,]
MII.sem.dev.GSR <- sd(table(enhTarPairsMII.dev[,2]))/sqrt(length(table(enhTarPairsMII.dev[,2])))
MIIRRDevGSR <- nrow(enhTarPairsMII.dev)/MIIDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
enhTarPairsX2cell.dev <- enhTarPairsDev[matchIndexesPairs,]
M2C.sem.dev.GSR <- sd(table(enhTarPairsX2cell.dev[,2]))/sqrt(length(table(enhTarPairsX2cell.dev[,2])))
M2CRRDevGSR <- nrow(enhTarPairsX2cell.dev)/M2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
enhTarPairsX4cell.dev <- enhTarPairsDev[matchIndexesPairs,]
M4C.sem.dev.GSR <- sd(table(enhTarPairsX4cell.dev[,2]))/sqrt(length(table(enhTarPairsX4cell.dev[,2])))
M4CRRDevGSR <- nrow(enhTarPairsX4cell.dev)/M4CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
enhTarPairsX8cell.dev <- enhTarPairsDev[matchIndexesPairs,]
M8C.sem.dev.GSR <- sd(table(enhTarPairsX8cell.dev[,2]))/sqrt(length(table(enhTarPairsX8cell.dev[,2])))
M8CRRDevGSR <- nrow(enhTarPairsX8cell.dev)/M8CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
enhTarPairsMorula.dev <- enhTarPairsDev[matchIndexesPairs,]
Morula.sem.dev.GSR <- sd(table(enhTarPairsMorula.dev[,2]))/sqrt(length(table(enhTarPairsMorula.dev[,2])))
MorulaRRDevGSR <- nrow(enhTarPairsMorula.dev)/MorulaDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.dev <- enhTarPairsDev[matchIndexesPairs,]
ICM.sem.dev.GSR <- sd(table(enhTarPairsICM.dev[,2]))/sqrt(length(table(enhTarPairsICM.dev[,2])))
ICMRRDevGSR <- nrow(enhTarPairsICM.dev)/ICMDevNum

# Non-developmental genes
matchIndexesTar <- match(enhTarPairsNonDev[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairsNonDev[,1],enhancer.gsr[,1])

MIINonDevNum <- match(target.stages[which(target.stages[,3]=="MIIOocyte"),1],NonDevGenesData[,1])
MIINonDevNum <- length(which(!is.na(MIINonDevNum)))

M2CNonDevNum <- match(target.stages[which(target.stages[,3]=="X2cell"),1],NonDevGenesData[,1])
M2CNonDevNum <- length(which(!is.na(M2CNonDevNum)))

M4CNonDevNum <- match(target.stages[which(target.stages[,3]=="X4cell"),1],NonDevGenesData[,1])
M4CNonDevNum <- length(which(!is.na(M4CNonDevNum)))

M8CNonDevNum <- match(target.stages[which(target.stages[,3]=="X8cell"),1],NonDevGenesData[,1])
M8CNonDevNum <- length(which(!is.na(M8CNonDevNum)))

MorulaNonDevNum <- match(target.stages[which(target.stages[,3]=="morula"),1],NonDevGenesData[,1])
MorulaNonDevNum <- length(which(!is.na(MorulaNonDevNum)))

ICMNonDevNum <- match(target.stages[which(target.stages[,3]=="ICM"),1],NonDevGenesData[,1])
ICMNonDevNum <- length(which(!is.na(ICMNonDevNum)))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
MII.sem.nondev.GSR <- sd(table(enhTarPairsMII.nondev[,2]))/sqrt(length(table(enhTarPairsMII.nondev[,2])))
MIIRRNonDevGSR <- nrow(enhTarPairsMII.nondev)/MIINonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X2cell" & target.stages[matchIndexesTar,3]=="X2cell")
enhTarPairsX2cell.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
M2C.sem.nondev.GSR <- sd(table(enhTarPairsX2cell.nondev[,2]))/sqrt(length(table(enhTarPairsX2cell.nondev[,2])))
M2CRRNonDevGSR <- nrow(enhTarPairsX2cell.nondev)/M2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X4cell" & target.stages[matchIndexesTar,3]=="X4cell")
enhTarPairsX4cell.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
M4C.sem.nondev.GSR <- sd(table(enhTarPairsX4cell.nondev[,2]))/sqrt(length(table(enhTarPairsX4cell.nondev[,2])))
M4CRRNonDevGSR <- nrow(enhTarPairsX4cell.nondev)/M4CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="X8cell" & target.stages[matchIndexesTar,3]=="X8cell")
enhTarPairsX8cell.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
M8C.sem.nondev.GSR <- sd(table(enhTarPairsX8cell.nondev[,2]))/sqrt(length(table(enhTarPairsX8cell.nondev[,2])))
M8CRRNonDevGSR <- nrow(enhTarPairsX8cell.nondev)/M8CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="morula" & target.stages[matchIndexesTar,3]=="morula")
enhTarPairsMorula.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
Morula.sem.nondev.GSR <- sd(table(enhTarPairsMorula.nondev[,2]))/sqrt(length(table(enhTarPairsMorula.nondev[,2])))
MorulaRRNonDevGSR <- nrow(enhTarPairsMorula.nondev)/MorulaNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
ICM.sem.nondev.GSR <- sd(table(enhTarPairsICM.nondev[,2]))/sqrt(length(table(enhTarPairsICM.nondev[,2])))
ICMRRNonDevGSR <- nrow(enhTarPairsICM.nondev)/ICMNonDevNum

# XW 
DevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/devgenes.txt",header=FALSE,stringsAsFactors=FALSE)
NonDevGenesData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_XW/nondevgenes.txt",header=FALSE,stringsAsFactors=FALSE)

high.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
low.enhancer.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,,stringsAsFactors=FALSE)
enhancer.gsr <- rbind(high.enhancer.gsr,median.enhancer.gsr,low.enhancer.gsr)

target.stages <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
target.stages[,1] <- gsub("\\.\\d+","",target.stages[,1])
enhTarPairsDev <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_devgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
enhTarPairsNonDev <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_nondevgenes.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)

# Developmental genes
matchIndexesTar <- match(enhTarPairsNonDev[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairsNonDev[,1],enhancer.gsr[,1])

MIIDevNum <- match(target.stages[which(target.stages[,3]=="MIIOocyte"),1],DevGenesData[,1])
MIIDevNum <- length(which(!is.na(MIIDevNum)))

ZygoteDevNum <- match(target.stages[which(target.stages[,3]=="Zygote"),1],DevGenesData[,1])
ZygoteDevNum <- length(which(!is.na(ZygoteDevNum)))

E2CDevNum <- match(target.stages[which(target.stages[,3]=="E2C"),1],DevGenesData[,1])
E2CDevNum <- length(which(!is.na(E2CDevNum)))

L2CDevNum <- match(target.stages[which(target.stages[,3]=="L2C"),1],DevGenesData[,1])
L2CDevNum <- length(which(!is.na(L2CDevNum)))

M4CDevNum <- match(target.stages[which(target.stages[,3]=="M4C"),1],DevGenesData[,1])
M4CDevNum <- length(which(!is.na(M4CDevNum)))

M8CDevNum <- match(target.stages[which(target.stages[,3]=="M8C"),1],DevGenesData[,1])
M8CDevNum <- length(which(!is.na(M8CDevNum)))

ICMDevNum <- match(target.stages[which(target.stages[,3]=="ICM"),1],DevGenesData[,1])
ICMDevNum <- length(which(!is.na(ICMDevNum)))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.dev <- enhTarPairsDev[matchIndexesPairs,]
MII.sem.dev.XW <- sd(table(enhTarPairsMII.dev[,2]))/sqrt(length(table(enhTarPairsMII.dev[,2])))
MIIRRDevXW <- nrow(enhTarPairsMII.dev)/MIIDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
enhTarPairsZygote.dev <- enhTarPairsDev[matchIndexesPairs,]
Zygote.sem.dev.XW <- sd(table(enhTarPairsZygote.dev[,2]))/sqrt(length(table(enhTarPairsZygote.dev[,2])))
ZygoteRRDevXW <- nrow(enhTarPairsZygote.dev)/ZygoteDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
enhTarPairsE2C.dev <- enhTarPairsDev[matchIndexesPairs,]
E2C.sem.dev.XW <- sd(table(enhTarPairsE2C.dev[,2]))/sqrt(length(table(enhTarPairsE2C.dev[,2])))
E2CRRDevXW <- nrow(enhTarPairsE2C.dev)/E2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
enhTarPairsL2C.dev <- enhTarPairsDev[matchIndexesPairs,]
L2C.sem.dev.XW <- sd(table(enhTarPairsL2C.dev[,2]))/sqrt(length(table(enhTarPairsL2C.dev[,2])))
L2CRRDevXW <- nrow(enhTarPairsL2C.dev)/L2CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
enhTarPairsM4C.dev <- enhTarPairsDev[matchIndexesPairs,]
M4C.sem.dev.XW <- sd(table(enhTarPairsM4C.dev[,2]))/sqrt(length(table(enhTarPairsM4C.dev[,2])))
M4CRRDevXW <- nrow(enhTarPairsM4C.dev)/M4CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
enhTarPairsM8C.dev <- enhTarPairsDev[matchIndexesPairs,]
M8C.sem.dev.XW <- sd(table(enhTarPairsM8C.dev[,2]))/sqrt(length(table(enhTarPairsM8C.dev[,2])))
M8CRRDevXW <- nrow(enhTarPairsM8C.dev)/M8CDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.dev <- enhTarPairsDev[matchIndexesPairs,]
ICM.sem.dev.XW <- sd(table(enhTarPairsICM.dev[,2]))/sqrt(length(table(enhTarPairsICM.dev[,2])))
ICMRRDevXW <- nrow(enhTarPairsICM.dev)/ICMDevNum

# Non-developmental genes
matchIndexesTar <- match(enhTarPairsNonDev[,2],target.stages[,1])
matchIndexesEnh <- match(enhTarPairsNonDev[,1],enhancer.gsr[,1])

MIINonDevNum <- match(target.stages[which(target.stages[,3]=="MIIOocyte"),1],NonDevGenesData[,1])
MIINonDevNum <- length(which(!is.na(MIINonDevNum)))

ZygoteNonDevNum <- match(target.stages[which(target.stages[,3]=="Zygote"),1],NonDevGenesData[,1])
ZygoteNonDevNum <- length(which(!is.na(ZygoteNonDevNum)))

E2CNonDevNum <- match(target.stages[which(target.stages[,3]=="E2C"),1],NonDevGenesData[,1])
E2CNonDevNum <- length(which(!is.na(E2CNonDevNum)))

L2CNonDevNum <- match(target.stages[which(target.stages[,3]=="L2C"),1],NonDevGenesData[,1])
L2CNonDevNum <- length(which(!is.na(L2CNonDevNum)))

M4CNonDevNum <- match(target.stages[which(target.stages[,3]=="M4C"),1],NonDevGenesData[,1])
M4CNonDevNum <- length(which(!is.na(M4CNonDevNum)))

M8CNonDevNum <- match(target.stages[which(target.stages[,3]=="M8C"),1],NonDevGenesData[,1])
M8CNonDevNum <- length(which(!is.na(M8CNonDevNum)))

ICMNonDevNum <- match(target.stages[which(target.stages[,3]=="ICM"),1],NonDevGenesData[,1])
ICMNonDevNum <- length(which(!is.na(ICMNonDevNum)))

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="MIIOocyte" & target.stages[matchIndexesTar,3]=="MIIOocyte")
enhTarPairsMII.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
MII.sem.nondev.XW <- sd(table(enhTarPairsMII.nondev[,2]))/mean(table(enhTarPairsMII.nondev[,2]))
MIIRRNonDevXW <- nrow(enhTarPairsMII.nondev)/MIINonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="Zygote" & target.stages[matchIndexesTar,3]=="Zygote")
enhTarPairsZygote.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
Zygote.sem.nondev.XW <- sd(table(enhTarPairsZygote.nondev[,2]))/sqrt(length(table(enhTarPairsZygote.nondev[,2])))
ZygoteRRNonDevXW <- nrow(enhTarPairsZygote.nondev)/ZygoteNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="E2C" & target.stages[matchIndexesTar,3]=="E2C")
enhTarPairsE2C.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
E2C.sem.nondev.XW <- sd(table(enhTarPairsE2C.nondev[,2]))/sqrt(length(table(enhTarPairsE2C.nondev[,2])))
E2CRRNonDevXW <- nrow(enhTarPairsE2C.nondev)/E2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="L2C" & target.stages[matchIndexesTar,3]=="L2C")
enhTarPairsL2C.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
L2C.sem.nondev.XW <- sd(table(enhTarPairsL2C.nondev[,2]))/sqrt(length(table(enhTarPairsL2C.nondev[,2])))
L2CRRNonDevXW <- nrow(enhTarPairsL2C.nondev)/L2CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M4C" & target.stages[matchIndexesTar,3]=="M4C")
enhTarPairsM4C.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
M4C.sem.nondev.XW <- sd(table(enhTarPairsM4C.nondev[,2]))/sqrt(length(table(enhTarPairsM4C.nondev[,2])))
M4CRRNonDevXW <- nrow(enhTarPairsM4C.nondev)/M4CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="M8C" & target.stages[matchIndexesTar,3]=="M8C")
enhTarPairsM8C.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
M8C.sem.nondev.XW <- sd(table(enhTarPairsM8C.nondev[,2]))/sqrt(length(table(enhTarPairsM8C.nondev[,2])))
M8CRRNonDevXW <- nrow(enhTarPairsM8C.nondev)/M8CNonDevNum

matchIndexesPairs <- which(enhancer.gsr[matchIndexesEnh,3]=="ICM" & target.stages[matchIndexesTar,3]=="ICM")
enhTarPairsICM.nondev <- enhTarPairsNonDev[matchIndexesPairs,]
ICM.sem.nondev.XW <- sd(table(enhTarPairsICM.nondev[,2]))/sqrt(length(table(enhTarPairsICM.nondev[,2])))
ICMRRNonDevXW <- nrow(enhTarPairsICM.nondev)/ICMNonDevNum

RRMII.dev <- (MIIRRDevGSR + MIIRRDevXW)/2
RRZygote.dev <- ZygoteRRDevXW
RRE2C.dev <- E2CRRDevXW
RRL2C.dev <- (M2CRRDevGSR + L2CRRDevXW)/2
RRM4C.dev <- (M4CRRDevGSR + M4CRRDevXW)/2
RRM8C.dev <- (M8CRRDevGSR + M8CRRDevXW)/2
RRMorula.dev <- MorulaRRDevGSR
RRICM.dev <- (ICMRRDevGSR + ICMRRDevXW)/2

RRMII.nondev <- (MIIRRNonDevGSR + MIIRRNonDevXW)/2
RRZygote.nondev <- ZygoteRRNonDevXW
RRE2C.nondev <- E2CRRNonDevXW
RRL2C.nondev <- (M2CRRNonDevGSR + L2CRRNonDevXW)/2
RRM4C.nondev <- (M4CRRNonDevGSR + M4CRRNonDevXW)/2
RRM8C.nondev <- (M8CRRNonDevGSR + M8CRRNonDevXW)/2
RRMorula.nondev <- MorulaRRNonDevGSR
RRICM.nondev <- (ICMRRNonDevGSR + ICMRRNonDevXW)/2

MII.sem.dev <- (MII.sem.dev.GSR + MII.sem.dev.XW)/2
Zygote.sem.dev <- Zygote.sem.dev.XW
E2C.sem.dev <- E2C.sem.dev.XW
L2C.sem.dev <- (M2C.sem.dev.GSR + L2C.sem.dev.XW)/2
M4C.sem.dev <- (M4C.sem.dev.GSR + M4C.sem.dev.XW)/2
M8C.sem.dev <- (M8C.sem.dev.GSR + M8C.sem.dev.XW)/2
Morula.sem.dev <- Morula.sem.dev.GSR
ICM.sem.dev <- (ICM.sem.dev.GSR + ICM.sem.dev.XW)/2

MII.sem.nondev <- (MII.sem.nondev.GSR + MII.sem.nondev.XW)/2
Zygote.sem.nondev <- Zygote.sem.nondev.XW
E2C.sem.nondev <- E2C.sem.nondev.XW
L2C.sem.nondev <- (M2C.sem.nondev.GSR + L2C.sem.nondev.XW)/2
M4C.sem.nondev <- (M4C.sem.nondev.GSR + M4C.sem.nondev.XW)/2
M8C.sem.nondev <- (M8C.sem.nondev.GSR + M8C.sem.nondev.XW)/2
Morula.sem.nondev <- Morula.sem.nondev.GSR
ICM.sem.nondev <- (ICM.sem.nondev.GSR + ICM.sem.nondev.XW)/2

num <- c(RRMII.dev,RRZygote.dev,RRE2C.dev,RRL2C.dev,RRM4C.dev,RRM8C.dev,RRMorula.dev,RRICM.dev,RRMII.nondev,RRZygote.nondev,RRE2C.nondev,RRL2C.nondev,RRM4C.nondev,RRM8C.nondev,RRMorula.nondev,RRICM.nondev)
sem <- c(MII.sem.dev,Zygote.sem.dev,E2C.sem.dev,L2C.sem.dev,M4C.sem.dev,M8C.sem.dev,Morula.sem.dev,ICM.sem.dev,MII.sem.nondev,Zygote.sem.nondev,E2C.sem.nondev,L2C.sem.nondev,M4C.sem.nondev,M8C.sem.nondev,Morula.sem.nondev,ICM.sem.nondev)
stage <- rep(c("MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM","MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM"),c(length(RRMII.dev),length(RRZygote.dev),length(RRE2C.dev),length(RRL2C.dev),length(RRM4C.dev),length(RRM8C.dev),length(RRMorula.dev),length(RRICM.dev),length(RRMII.nondev),length(RRZygote.nondev),length(RRE2C.nondev),length(RRL2C.nondev),length(RRM4C.nondev),length(RRM8C.nondev),length(RRMorula.nondev),length(RRICM.nondev)))
type <- rep(c("DEV","DEV","DEV","DEV","DEV","DEV","DEV","DEV","NONDEV","NONDEV","NONDEV","NONDEV","NONDEV","NONDEV","NONDEV","NONDEV"),c(length(RRMII.dev),length(RRZygote.dev),length(RRE2C.dev),length(RRL2C.dev),length(RRM4C.dev),length(RRM8C.dev),length(RRMorula.dev),length(RRICM.dev),length(RRMII.nondev),length(RRZygote.nondev),length(RRE2C.nondev),length(RRL2C.nondev),length(RRM4C.nondev),length(RRM8C.nondev),length(RRMorula.nondev),length(RRICM.nondev)))

statData <- as.data.frame(cbind(num,sem,stage,type))
colnames(statData) <- c("num","sem","stage","type")
statData$num <- as.numeric(statData$num)
statData$sem <- as.numeric(statData$sem)
statData$stage <- factor(statData$stage,levels=c("MII","Zygote","E2C","L2C","M4C","M8C","Morula","ICM"))
statData$type <- factor(statData$type,levels=c("DEV","NONDEV"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/DevNonDevRegRatio.pdf",width=7,height=5)
p <- ggplot(data=statData, aes(x=stage, y=num, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p + geom_errorbar(aes(x=stage, ymin=num-sem, ymax=num+sem), width=0.4, colour="black", alpha=0.9, size=1.3,position=position_dodge(.9))
print(p)
dev.off()