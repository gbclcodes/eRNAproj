#!/usr/bin/env python



# common command:
# os.getcwd()
# os.chdir()
# os.listdir("dir")
# os.system()
# os.walk("dir")
# os.remove()
# os.rmdir()
# os.rename(src, dst)
# os.path.join() 
#    ''' join strings as path '''
# os.path.abspath()
#    ''' return path no matter exist or not '''
# os.path.basename()
#    ''' return the lowest '''
# os.path.dirname()
#    ''' return the path before the last '/' '''
# os.path.exists()
# os.path.isabs()
# os.path.isfile()
# os.path.isdir()
# shutil.copyfile()
# shutil.move()
# glob.glob("*.py")


import os
import shutil
import glob

def mkdir_p(dir):
#    '''make a directory (dir) if it doesn't exist'''
    if not os.path.exists(dir):
        os.mkdir(dir)
    
# Make top level directories
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K9me3_SNP")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/script")

job_directory = "/storage/gbcl/qiaolu/EpiData/H3K9me3_SNP"
script_directory = "/storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/script"
data_directory = "/storage/gbcl/qiaolu/EpiData/H3K9me3_mapping/files"

os.chdir(data_directory)
files = glob.glob("*_mapping.sam")

for file in files:
    file_name = file[:14]
    job_file = os.path.join(script_directory,"%s_SNP.bash" %file_name)


    with open(job_file, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p amd-ep2\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J %s\n" % file_name)
        fh.writelines("#SBATCH -c 1\n")
        fh.writelines("#SBATCH --mem 100G\n")
        fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/%s.out\n" % file_name)
        fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/%s.err\n" % file_name)
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load samtools/1.14 \n")
        fh.writelines("cp /storage/gbcl/qiaolu/EpiData/H3K27me3_SNP/all_SNPs_DBA_2J_GRCm38.txt.gz %s \n" % job_directory )
        fh.writelines("/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit -o /storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/%s --paired --snp_file /storage/gbcl/qiaolu/EpiData/H3K9me3_SNP/all_SNPs_DBA_2J_GRCm38.txt.gz %s/%s" % (file_name, data_directory, file))

    os.system("sbatch %s" %job_file)