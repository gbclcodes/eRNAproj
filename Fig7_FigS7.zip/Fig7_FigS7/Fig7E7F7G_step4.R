library(DESeq2)
mapInfo <- read.table(file = "/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/gene_TPM.txt", sep = "\t", header = T, row.names = 1)
database_all <- read.table(file = "/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/gene_count_matrix.csv", sep = ",", header = T)
expdata <- database_all[,2:ncol(database_all)]
rownames(expdata) <- database_all[,1]
conditions <- factor(c(rep("siNC",2),rep("siEH",2)),levels=c("siNC","siEH"))
coldata <- data.frame(row.names = colnames(expdata[,c(3,4,1,2)]), conditions)
dds <- DESeqDataSetFromMatrix(countData=expdata[,c(3,4,1,2)], colData=coldata, design=~conditions)
dds <- DESeq(dds)
res <- results(dds)
res <- res[order(res$padj),]
resdata <- merge(as.data.frame(res), as.data.frame(counts(dds, normalized=TRUE)),by="row.names",sort=FALSE)
matchIndexes <- match(resdata[,1],mapInfo[,1])
rownames(resdata) <- resdata[,1]
resdata[,1] <- mapInfo[matchIndexes,2]
colnames(resdata)[1] <- c("gene_name")
write.csv(resdata, file = "/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/siENH_vs_siNC_2C.csv",row.names=T,col.names=T)
