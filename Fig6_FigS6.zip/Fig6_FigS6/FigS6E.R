# Zygote 
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,7] > 0),7] + 1)/(DBAData[which(AllData[,7] > 0),7] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.zygote <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.zygote <- unique(tf.enh.pairs[matchIndexes,2])

tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,2] > 0),2] + 1)/(DBAData[which(AllData[,2] > 0),2] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.zygote <- unique(c(tf.m.zygote,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.zygote <- unique(c(tf.p.zygote,unique(tf.enh.pairs[matchIndexes,2])))


# Early 2-cell
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,4] > 0),4] + 1)/(DBAData[which(AllData[,4] > 0),4] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.e2c <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.e2c <- unique(tf.enh.pairs[matchIndexes,2])


tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,3] > 0),3] + 1)/(DBAData[which(AllData[,3] > 0),3] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.e2c <- unique(c(tf.m.e2c,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.e2c <- unique(c(tf.p.e2c,unique(tf.enh.pairs[matchIndexes,2])))


# 2-cell
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,1] > 0),1] + 1)/(DBAData[which(AllData[,1] > 0),1] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.2c <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.2c <- unique(tf.enh.pairs[matchIndexes,2])

tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,4] > 0),4] + 1)/(DBAData[which(AllData[,4] > 0),4] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.2c <- unique(c(tf.m.2c,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.2c <- unique(c(tf.p.2c,unique(tf.enh.pairs[matchIndexes,2])))


# 4-cell
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,2] > 0),2] + 1)/(DBAData[which(AllData[,2] > 0),2] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.4c <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.4c <- unique(tf.enh.pairs[matchIndexes,2])

tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,5] > 0),5] + 1)/(DBAData[which(AllData[,5] > 0),5] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.4c <- unique(c(tf.m.4c,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.4c <- unique(c(tf.p.4c,unique(tf.enh.pairs[matchIndexes,2])))


# 8-cell
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,3] > 0),3] + 1)/(DBAData[which(AllData[,3] > 0),3] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.8c <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.8c <- unique(tf.enh.pairs[matchIndexes,2])

tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,5] > 0),5] + 1)/(DBAData[which(AllData[,5] > 0),5] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.8c <- unique(c(tf.m.8c,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.8c <- unique(c(tf.p.8c,unique(tf.enh.pairs[matchIndexes,2])))


# ICM
tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
C57BLData <- C57BLData[1:(nrow(C57BLData)-5),]
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
DBAData <- DBAData[1:(nrow(DBAData)-5),]
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,5] > 0),5] + 1)/(DBAData[which(AllData[,5] > 0),5] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.icm <- unique(tf.enh.pairs[matchIndexes,2])
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.icm <- unique(tf.enh.pairs[matchIndexes,2])

tf.enh.pairs <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
high.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_highscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
median.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_medianscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
low.enhancers <- read.table(file="/media/yuhua/yuhua_projects/enhProj/SpENHData/superenhancer_stage_specific_lowscores_XW.txt",header=FALSE,stringsAsFactors=FALSE)
all.enhancers <- rbind(high.enhancers,median.enhancers,low.enhancers)
stageNames <- unique(all.enhancers[,3])

C57BLData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_m.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
DBAData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/enhancer_counts_p.txt",row.names=1,header=TRUE,stringsAsFactors=FALSE)
AllData <- C57BLData + DBAData

ratioData <- log2((C57BLData[which(AllData[,7] > 0),7] + 1)/(DBAData[which(AllData[,7] > 0),7] + 1))
classData <- rep("Both",length(ratioData))
classData[which(ratioData > 1)] <- "Maternal"
classData[which(ratioData < -1)] <- "Paternal"

matchIndexes <- match(rownames(C57BLData)[which(classData=="Maternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.m.icm <- unique(c(tf.m.8c,unique(tf.enh.pairs[matchIndexes,2])))
matchIndexes <- match(rownames(C57BLData)[which(classData=="Paternal")],tf.enh.pairs[,1])
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
tf.p.icm <- unique(c(tf.p.8c,unique(tf.enh.pairs[matchIndexes,2])))

tfdata.m <- list(tf.m.zygote,tf.m.e2c,tf.m.2c,tf.m.4c,tf.m.8c,tf.m.icm)
tfdata.p <- list(tf.p.zygote,tf.p.e2c,tf.p.2c,tf.p.4c,tf.p.8c,tf.p.icm)

library(pheatmap)
library(clusterProfiler)
library(org.Mm.eg.db)

clslist <- list()
for(tfIDs in tfdata.p){
	geneIDs <- bitr(tfIDs, fromType="ENSEMBL", toType="ENTREZID", OrgDb="org.Mm.eg.db")
    clslist <- c(clslist,list(geneIDs[,2]))
}
names(clslist) <- paste("C",seq(1,6),sep="")

tf.genes <- read.table(file="/media/yuhua/yuhua_projects/enhProj/annodata/AnimalTFDB_mus_musculus_TF.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
tf.genes.map <- bitr(tf.genes[,3], fromType="ENSEMBL", toType="ENTREZID", OrgDb="org.Mm.eg.db")
matchIndexes <- match(tf.genes.map[,1],tf.genes[,3])
tf.genes.family <- cbind(tf.genes[matchIndexes[which(!is.na(matchIndexes))],4],tf.genes.map[which(!is.na(matchIndexes)),2])
colnames(tf.genes.family) <- c("familyName","geneID")

EnZygote <- enricher(clslist$C1, TERM2GENE = tf.genes.family)
EnE2Cell <- enricher(clslist$C2, TERM2GENE = tf.genes.family)
En2Cell <- enricher(clslist$C3, TERM2GENE = tf.genes.family)
En4Cell <- enricher(clslist$C4, TERM2GENE = tf.genes.family)
En8Cell <- enricher(clslist$C5, TERM2GENE = tf.genes.family)
EnICM <- enricher(clslist$C6, TERM2GENE = tf.genes.family)

EnZygote_setratio <- unlist(lapply(strsplit(EnZygote@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnZygote_bgratio <- unlist(lapply(strsplit(EnZygote@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnZygote_fcvalue <- EnZygote_setratio/EnZygote_bgratio
EnZygote_data <- cbind(rep("Zygote",nrow(EnZygote@result)),EnZygote@result$ID,EnZygote@result$p.adjust,EnZygote_fcvalue)

EnE2Cell_setratio <- unlist(lapply(strsplit(EnE2Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnE2Cell_bgratio <- unlist(lapply(strsplit(EnE2Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnE2Cell_fcvalue <- EnE2Cell_setratio/EnE2Cell_bgratio
EnE2Cell_data <- cbind(rep("E2C",nrow(EnE2Cell@result)),EnE2Cell@result$ID,EnE2Cell@result$p.adjust,EnE2Cell_fcvalue)

En2Cell_setratio <- unlist(lapply(strsplit(En2Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En2Cell_bgratio <- unlist(lapply(strsplit(En2Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En2Cell_fcvalue <- En2Cell_setratio/En2Cell_bgratio
En2Cell_data <- cbind(rep("M2C",nrow(En2Cell@result)),En2Cell@result$ID,En2Cell@result$p.adjust,En2Cell_fcvalue)

En4Cell_setratio <- unlist(lapply(strsplit(En4Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En4Cell_bgratio <- unlist(lapply(strsplit(En4Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En4Cell_fcvalue <- En4Cell_setratio/En4Cell_bgratio
En4Cell_data <- cbind(rep("M4C",nrow(En4Cell@result)),En4Cell@result$ID,En4Cell@result$p.adjust,En4Cell_fcvalue)

En8Cell_setratio <- unlist(lapply(strsplit(En8Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En8Cell_bgratio <- unlist(lapply(strsplit(En8Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En8Cell_fcvalue <- En8Cell_setratio/En8Cell_bgratio
En8Cell_data <- cbind(rep("M8C",nrow(En8Cell@result)),En8Cell@result$ID,En8Cell@result$p.adjust,En8Cell_fcvalue)

EnICM_setratio <- unlist(lapply(strsplit(EnICM@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnICM_bgratio <- unlist(lapply(strsplit(EnICM@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnICM_fcvalue <- EnICM_setratio/EnICM_bgratio
EnICM_data <- cbind(rep("ICM",nrow(EnICM@result)),EnICM@result$ID,EnICM@result$p.adjust,EnICM_fcvalue)

plotdata <- as.data.frame(rbind(EnZygote_data,EnE2Cell_data,En2Cell_data,En4Cell_data,En8Cell_data,EnICM_data))
colnames(plotdata) <- c("sptype","goterm","padjust","fcvalue")
plotdata <- plotdata[which(plotdata$goterm!="Others"),]
plotdata$sptype <- factor(plotdata$sptype,levels=c("Zygote","E2C","M2C","M4C","M8C","ICM"))
plotdata$goterm <- factor(plotdata$goterm,levels=rev(unique(plotdata$goterm)))
plotdata$padjust <- -log10(as.numeric(plotdata$padjust))
plotdata$fcvalue <- as.numeric(plotdata$fcvalue)
p.level <- rev(unique(plotdata$goterm))

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/tffamilypaternal.pdf",width=4,height=6)
p <- ggplot(plotdata, aes(x=sptype, y=goterm, size=fcvalue, color=padjust)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()


clslist <- list()
for(tfIDs in tfdata.m){
	geneIDs <- bitr(tfIDs, fromType="ENSEMBL", toType="ENTREZID", OrgDb="org.Mm.eg.db")
    clslist <- c(clslist,list(geneIDs[,2]))
}
names(clslist) <- paste("C",seq(1,6),sep="")

tf.genes <- read.table(file="/media/yuhua/yuhua_projects/enhProj/annodata/AnimalTFDB_mus_musculus_TF.txt",sep="\t",header=TRUE,stringsAsFactors=FALSE)
tf.genes.map <- bitr(tf.genes[,3], fromType="ENSEMBL", toType="ENTREZID", OrgDb="org.Mm.eg.db")
matchIndexes <- match(tf.genes.map[,1],tf.genes[,3])
tf.genes.family <- cbind(tf.genes[matchIndexes[which(!is.na(matchIndexes))],4],tf.genes.map[which(!is.na(matchIndexes)),2])
colnames(tf.genes.family) <- c("familyName","geneID")

EnZygote <- enricher(clslist$C1, TERM2GENE = tf.genes.family)
EnE2Cell <- enricher(clslist$C2, TERM2GENE = tf.genes.family)
En2Cell <- enricher(clslist$C3, TERM2GENE = tf.genes.family)
En4Cell <- enricher(clslist$C4, TERM2GENE = tf.genes.family)
En8Cell <- enricher(clslist$C5, TERM2GENE = tf.genes.family)
EnICM <- enricher(clslist$C6, TERM2GENE = tf.genes.family)

EnZygote_setratio <- unlist(lapply(strsplit(EnZygote@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnZygote_bgratio <- unlist(lapply(strsplit(EnZygote@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnZygote_fcvalue <- EnZygote_setratio/EnZygote_bgratio
EnZygote_data <- cbind(rep("Zygote",nrow(EnZygote@result)),EnZygote@result$ID,EnZygote@result$p.adjust,EnZygote_fcvalue)

EnE2Cell_setratio <- unlist(lapply(strsplit(EnE2Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnE2Cell_bgratio <- unlist(lapply(strsplit(EnE2Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnE2Cell_fcvalue <- EnE2Cell_setratio/EnE2Cell_bgratio
EnE2Cell_data <- cbind(rep("E2C",nrow(EnE2Cell@result)),EnE2Cell@result$ID,EnE2Cell@result$p.adjust,EnE2Cell_fcvalue)

En2Cell_setratio <- unlist(lapply(strsplit(En2Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En2Cell_bgratio <- unlist(lapply(strsplit(En2Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En2Cell_fcvalue <- En2Cell_setratio/En2Cell_bgratio
En2Cell_data <- cbind(rep("M2C",nrow(En2Cell@result)),En2Cell@result$ID,En2Cell@result$p.adjust,En2Cell_fcvalue)

En4Cell_setratio <- unlist(lapply(strsplit(En4Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En4Cell_bgratio <- unlist(lapply(strsplit(En4Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En4Cell_fcvalue <- En4Cell_setratio/En4Cell_bgratio
En4Cell_data <- cbind(rep("M4C",nrow(En4Cell@result)),En4Cell@result$ID,En4Cell@result$p.adjust,En4Cell_fcvalue)

En8Cell_setratio <- unlist(lapply(strsplit(En8Cell@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En8Cell_bgratio <- unlist(lapply(strsplit(En8Cell@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
En8Cell_fcvalue <- En8Cell_setratio/En8Cell_bgratio
En8Cell_data <- cbind(rep("M8C",nrow(En8Cell@result)),En8Cell@result$ID,En8Cell@result$p.adjust,En8Cell_fcvalue)

EnICM_setratio <- unlist(lapply(strsplit(EnICM@result$GeneRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnICM_bgratio <- unlist(lapply(strsplit(EnICM@result$BgRatio,"\\/"),function(x) return(as.numeric(x[1])/as.numeric(x[2]))))
EnICM_fcvalue <- EnICM_setratio/EnICM_bgratio
EnICM_data <- cbind(rep("ICM",nrow(EnICM@result)),EnICM@result$ID,EnICM@result$p.adjust,EnICM_fcvalue)

plotdata <- as.data.frame(rbind(EnZygote_data,EnE2Cell_data,En2Cell_data,En4Cell_data,En8Cell_data,EnICM_data))
colnames(plotdata) <- c("sptype","goterm","padjust","fcvalue")
plotdata <- plotdata[which(plotdata$goterm!="Others"),]
plotdata <- plotdata[which(plotdata$goterm!="T-box"),]
plotdata <- plotdata[which(plotdata$goterm!="MYB"),]
plotdata$sptype <- factor(plotdata$sptype,levels=c("Zygote","E2C","M2C","M4C","M8C","ICM"))
plotdata$goterm <- factor(plotdata$goterm,levels=p.level)
plotdata$padjust <- -log10(as.numeric(plotdata$padjust))
plotdata$fcvalue <- as.numeric(plotdata$fcvalue)

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/tffamilymaternal.pdf",width=4,height=6)
p <- ggplot(plotdata, aes(x=sptype, y=goterm, size=fcvalue, color=padjust)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()

