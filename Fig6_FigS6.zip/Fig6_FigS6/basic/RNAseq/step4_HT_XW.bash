#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J HT
#SBATCH -c 2
#SBATCH --mem 8G
#SBATCH -o /storage/gbcl/qiaolu/XWresult/byname/HT.log
#SBATCH -e /storage/gbcl/qiaolu/XWresult/byname/HT.err

cd /storage/gbcl/qiaolu/XWresult/byname

ls *.bam | while read file; do (htseq-count -c ${file:0:18}.csv -f bam -s no -i Name -t BED_feature --nonunique all -q $file enhancer_XW_new.gff3); done