### plotting
pathData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/genes_within_kegg_signaling_pathway.txt",sep="\t",header=FALSE,stringsAsFactors=FALSE)
pathFreq <- table(pathData[,4])
load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecMIIGSR.kegg.signal.RData")
MIIPairs <- unique(paste(enhTarPairsOEvecMII[,3],enhTarPairsOEvecMII[,7],sep="--"))
matchIndexes <- match(MIIPairs,paste(enhTarPairsOEvecMII[,3],enhTarPairsOEvecMII[,7],sep="--"))
MIIPairs <- enhTarPairsOEvecMII[matchIndexes,]
MIIFreq <- table(MIIPairs[,7])
matchIndexesMII <- match(names(MIIFreq),gsub("\\s+","",names(pathFreq)))
MIIPerc <- MIIFreq/pathFreq[matchIndexesMII]
MIItotalFreq <- table(enhTarPairsOEvecMII[,7])
enhTarPairsOEvecMII <- enhTarPairsOEvecMII[which(enhTarPairsOEvecMII[,8] > 0),]
MIIHiCFreq <- table(enhTarPairsOEvecMII[,7])
matchIndexesMII1 <- match(names(MIIFreq),gsub("\\s+","",names(MIIHiCFreq)))
matchIndexesMII2 <- match(names(MIIFreq),gsub("\\s+","",names(MIItotalFreq)))
MIIHiCPerc <- MIIHiCFreq[matchIndexesMII1]/MIItotalFreq[matchIndexesMII2]
MIIDataGSR <- cbind(names(MIIFreq),as.numeric(MIIFreq),as.numeric(MIIPerc),as.numeric(MIIHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecE2CGSR.kegg.signal.RData")
E2CPairs <- unique(paste(enhTarPairsOEvecE2C[,3],enhTarPairsOEvecE2C[,7],sep="--"))
matchIndexes <- match(E2CPairs,paste(enhTarPairsOEvecE2C[,3],enhTarPairsOEvecE2C[,7],sep="--"))
E2CPairs <- enhTarPairsOEvecE2C[matchIndexes,]
E2CFreq <- table(E2CPairs[,7])
matchIndexesE2C <- match(names(E2CFreq),gsub("\\s+","",names(pathFreq)))
E2CPerc <- E2CFreq/pathFreq[matchIndexesE2C]
E2CtotalFreq <- table(enhTarPairsOEvecE2C[,7])
enhTarPairsOEvecE2C <- enhTarPairsOEvecE2C[which(enhTarPairsOEvecE2C[,8] > 0),]
E2CHiCFreq <- table(enhTarPairsOEvecE2C[,7])
matchIndexesE2C1 <- match(names(E2CFreq),gsub("\\s+","",names(E2CHiCFreq)))
matchIndexesE2C2 <- match(names(E2CFreq),gsub("\\s+","",names(E2CtotalFreq)))
E2CHiCPerc <- E2CHiCFreq[matchIndexesE2C1]/E2CtotalFreq[matchIndexesE2C2]
E2CDataGSR <- cbind(names(E2CFreq),as.numeric(E2CFreq),as.numeric(E2CPerc),as.numeric(E2CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecL2CGSR.kegg.signal.RData")
L2CPairs <- unique(paste(enhTarPairsOEvecL2C[,3],enhTarPairsOEvecL2C[,7],sep="--"))
matchIndexes <- match(L2CPairs,paste(enhTarPairsOEvecL2C[,3],enhTarPairsOEvecL2C[,7],sep="--"))
L2CPairs <- enhTarPairsOEvecL2C[matchIndexes,]
L2CFreq <- table(L2CPairs[,7])
matchIndexesL2C <- match(names(L2CFreq),gsub("\\s+","",names(pathFreq)))
L2CPerc <- L2CFreq/pathFreq[matchIndexesL2C]
L2CtotalFreq <- table(enhTarPairsOEvecL2C[,7])
enhTarPairsOEvecL2C <- enhTarPairsOEvecL2C[which(enhTarPairsOEvecL2C[,8] > 0),]
L2CHiCFreq <- table(enhTarPairsOEvecL2C[,7])
matchIndexesL2C1 <- match(names(L2CFreq),gsub("\\s+","",names(L2CHiCFreq)))
matchIndexesL2C2 <- match(names(L2CFreq),gsub("\\s+","",names(L2CtotalFreq)))
L2CHiCPerc <- L2CHiCFreq[matchIndexesL2C1]/L2CtotalFreq[matchIndexesL2C2]
L2CDataGSR <- cbind(names(L2CFreq),as.numeric(L2CFreq),as.numeric(L2CPerc),as.numeric(L2CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecM8CGSR.kegg.signal.RData")
M8CPairs <- unique(paste(enhTarPairsOEvecM8C[,3],enhTarPairsOEvecM8C[,7],sep="--"))
matchIndexes <- match(M8CPairs,paste(enhTarPairsOEvecM8C[,3],enhTarPairsOEvecM8C[,7],sep="--"))
M8CPairs <- enhTarPairsOEvecM8C[matchIndexes,]
M8CFreq <- table(M8CPairs[,7])
matchIndexesM8C <- match(names(M8CFreq),gsub("\\s+","",names(pathFreq)))
M8CPerc <- M8CFreq/pathFreq[matchIndexesM8C]
M8CtotalFreq <- table(enhTarPairsOEvecM8C[,7])
enhTarPairsOEvecM8C <- enhTarPairsOEvecM8C[which(enhTarPairsOEvecM8C[,8] > 0),]
M8CHiCFreq <- table(enhTarPairsOEvecM8C[,7])
matchIndexesM8C1 <- match(names(M8CFreq),gsub("\\s+","",names(M8CHiCFreq)))
matchIndexesM8C2 <- match(names(M8CFreq),gsub("\\s+","",names(M8CtotalFreq)))
M8CHiCPerc <- M8CHiCFreq[matchIndexesM8C1]/M8CtotalFreq[matchIndexesM8C2]
M8CDataGSR <- cbind(names(M8CFreq),as.numeric(M8CFreq),as.numeric(M8CPerc),as.numeric(M8CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecICMGSR.kegg.signal.RData")
ICMPairs <- unique(paste(enhTarPairsOEvecICM[,3],enhTarPairsOEvecICM[,7],sep="--"))
matchIndexes <- match(ICMPairs,paste(enhTarPairsOEvecICM[,3],enhTarPairsOEvecICM[,7],sep="--"))
ICMPairs <- enhTarPairsOEvecICM[matchIndexes,]
ICMFreq <- table(ICMPairs[,7])
matchIndexesICM <- match(names(ICMFreq),gsub("\\s+","",names(pathFreq)))
ICMPerc <- ICMFreq/pathFreq[matchIndexesICM]
ICMtotalFreq <- table(enhTarPairsOEvecICM[,7])
enhTarPairsOEvecICM <- enhTarPairsOEvecICM[which(enhTarPairsOEvecICM[,8] > 0),]
ICMHiCFreq <- table(enhTarPairsOEvecICM[,7])
matchIndexesICM1 <- match(names(ICMFreq),gsub("\\s+","",names(ICMHiCFreq)))
matchIndexesICM2 <- match(names(ICMFreq),gsub("\\s+","",names(ICMtotalFreq)))
ICMHiCPerc <- ICMHiCFreq[matchIndexesICM1]/ICMtotalFreq[matchIndexesICM2]
ICMDataGSR <- cbind(names(ICMFreq),as.numeric(ICMFreq),as.numeric(ICMPerc),as.numeric(ICMHiCPerc))


load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecMIIXW.kegg.signal.RData")
MIIPairs <- unique(paste(enhTarPairsOEvecMII[,3],enhTarPairsOEvecMII[,7],sep="--"))
matchIndexes <- match(MIIPairs,paste(enhTarPairsOEvecMII[,3],enhTarPairsOEvecMII[,7],sep="--"))
MIIPairs <- enhTarPairsOEvecMII[matchIndexes,]
MIIFreq <- table(MIIPairs[,7])
matchIndexesMII <- match(names(MIIFreq),gsub("\\s+","",names(pathFreq)))
MIIPerc <- MIIFreq/pathFreq[matchIndexesMII]
MIItotalFreq <- table(enhTarPairsOEvecMII[,7])
enhTarPairsOEvecMII <- enhTarPairsOEvecMII[which(enhTarPairsOEvecMII[,8] > 0),]
MIIHiCFreq <- table(enhTarPairsOEvecMII[,7])
matchIndexesMII1 <- match(names(MIIFreq),gsub("\\s+","",names(MIIHiCFreq)))
matchIndexesMII2 <- match(names(MIIFreq),gsub("\\s+","",names(MIItotalFreq)))
MIIHiCPerc <- MIIHiCFreq[matchIndexesMII1]/MIItotalFreq[matchIndexesMII2]
MIIDataXW <- cbind(names(MIIFreq),as.numeric(MIIFreq),as.numeric(MIIPerc),as.numeric(MIIHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecE2CXW.kegg.signal.RData")
E2CPairs <- unique(paste(enhTarPairsOEvecE2C[,3],enhTarPairsOEvecE2C[,7],sep="--"))
matchIndexes <- match(E2CPairs,paste(enhTarPairsOEvecE2C[,3],enhTarPairsOEvecE2C[,7],sep="--"))
E2CPairs <- enhTarPairsOEvecE2C[matchIndexes,]
E2CFreq <- table(E2CPairs[,7])
matchIndexesE2C <- match(names(E2CFreq),gsub("\\s+","",names(pathFreq)))
E2CPerc <- E2CFreq/pathFreq[matchIndexesE2C]
E2CtotalFreq <- table(enhTarPairsOEvecE2C[,7])
enhTarPairsOEvecE2C <- enhTarPairsOEvecE2C[which(enhTarPairsOEvecE2C[,8] > 0),]
E2CHiCFreq <- table(enhTarPairsOEvecE2C[,7])
matchIndexesE2C1 <- match(names(E2CFreq),gsub("\\s+","",names(E2CHiCFreq)))
matchIndexesE2C2 <- match(names(E2CFreq),gsub("\\s+","",names(E2CtotalFreq)))
E2CHiCPerc <- E2CHiCFreq[matchIndexesE2C1]/E2CtotalFreq[matchIndexesE2C2]
E2CDataXW <- cbind(names(E2CFreq),as.numeric(E2CFreq),as.numeric(E2CPerc),as.numeric(E2CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecL2CXW.kegg.signal.RData")
L2CPairs <- unique(paste(enhTarPairsOEvecL2C[,3],enhTarPairsOEvecL2C[,7],sep="--"))
matchIndexes <- match(L2CPairs,paste(enhTarPairsOEvecL2C[,3],enhTarPairsOEvecL2C[,7],sep="--"))
L2CPairs <- enhTarPairsOEvecL2C[matchIndexes,]
L2CFreq <- table(L2CPairs[,7])
matchIndexesL2C <- match(names(L2CFreq),gsub("\\s+","",names(pathFreq)))
L2CPerc <- L2CFreq/pathFreq[matchIndexesL2C]
L2CtotalFreq <- table(enhTarPairsOEvecL2C[,7])
enhTarPairsOEvecL2C <- enhTarPairsOEvecL2C[which(enhTarPairsOEvecL2C[,8] > 0),]
L2CHiCFreq <- table(enhTarPairsOEvecL2C[,7])
matchIndexesL2C1 <- match(names(L2CFreq),gsub("\\s+","",names(L2CHiCFreq)))
matchIndexesL2C2 <- match(names(L2CFreq),gsub("\\s+","",names(L2CtotalFreq)))
L2CHiCPerc <- L2CHiCFreq[matchIndexesL2C1]/L2CtotalFreq[matchIndexesL2C2]
L2CDataXW <- cbind(names(L2CFreq),as.numeric(L2CFreq),as.numeric(L2CPerc),as.numeric(L2CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecM8CXW.kegg.signal.RData")
M8CPairs <- unique(paste(enhTarPairsOEvecM8C[,3],enhTarPairsOEvecM8C[,7],sep="--"))
matchIndexes <- match(M8CPairs,paste(enhTarPairsOEvecM8C[,3],enhTarPairsOEvecM8C[,7],sep="--"))
M8CPairs <- enhTarPairsOEvecM8C[matchIndexes,]
M8CFreq <- table(M8CPairs[,7])
matchIndexesM8C <- match(names(M8CFreq),gsub("\\s+","",names(pathFreq)))
M8CPerc <- M8CFreq/pathFreq[matchIndexesM8C]
M8CtotalFreq <- table(enhTarPairsOEvecM8C[,7])
enhTarPairsOEvecM8C <- enhTarPairsOEvecM8C[which(enhTarPairsOEvecM8C[,8] > 0),]
M8CHiCFreq <- table(enhTarPairsOEvecM8C[,7])
matchIndexesM8C1 <- match(names(M8CFreq),gsub("\\s+","",names(M8CHiCFreq)))
matchIndexesM8C2 <- match(names(M8CFreq),gsub("\\s+","",names(M8CtotalFreq)))
M8CHiCPerc <- M8CHiCFreq[matchIndexesM8C1]/M8CtotalFreq[matchIndexesM8C2]
M8CDataXW <- cbind(names(M8CFreq),as.numeric(M8CFreq),as.numeric(M8CPerc),as.numeric(M8CHiCPerc))

load("/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/enhTarPairOEvecICMXW.kegg.signal.RData")
ICMPairs <- unique(paste(enhTarPairsOEvecICM[,3],enhTarPairsOEvecICM[,7],sep="--"))
matchIndexes <- match(ICMPairs,paste(enhTarPairsOEvecICM[,3],enhTarPairsOEvecICM[,7],sep="--"))
ICMPairs <- enhTarPairsOEvecICM[matchIndexes,]
ICMFreq <- table(ICMPairs[,7])
matchIndexesICM <- match(names(ICMFreq),gsub("\\s+","",names(pathFreq)))
ICMPerc <- ICMFreq/pathFreq[matchIndexesICM]
ICMtotalFreq <- table(enhTarPairsOEvecICM[,7])
enhTarPairsOEvecICM <- enhTarPairsOEvecICM[which(enhTarPairsOEvecICM[,8] > 0),]
ICMHiCFreq <- table(enhTarPairsOEvecICM[,7])
matchIndexesICM1 <- match(names(ICMFreq),gsub("\\s+","",names(ICMHiCFreq)))
matchIndexesICM2 <- match(names(ICMFreq),gsub("\\s+","",names(ICMtotalFreq)))
ICMHiCPerc <- ICMHiCFreq[matchIndexesICM1]/ICMtotalFreq[matchIndexesICM2]
ICMDataXW <- cbind(names(ICMFreq),as.numeric(ICMFreq),as.numeric(ICMPerc),as.numeric(ICMHiCPerc))

MIIData <- as.data.frame(rbind(MIIDataGSR,MIIDataXW))
colnames(MIIData) <- c("PathName","GeneNum","RegNum","HiCNum")
MIIData$GeneNum <- as.numeric(MIIData$GeneNum)
MIIData$RegNum <- as.numeric(MIIData$RegNum)
MIIData$HiCNum <- as.numeric(MIIData$HiCNum)
E2CData <- as.data.frame(rbind(E2CDataGSR,E2CDataXW))
colnames(E2CData) <- c("PathName","GeneNum","RegNum","HiCNum")
E2CData$GeneNum <- as.numeric(E2CData$GeneNum)
E2CData$RegNum <- as.numeric(E2CData$RegNum)
E2CData$HiCNum <- as.numeric(E2CData$HiCNum)
L2CData <- as.data.frame(rbind(L2CDataGSR,L2CDataXW))
colnames(L2CData) <- c("PathName","GeneNum","RegNum","HiCNum")
L2CData$GeneNum <- as.numeric(L2CData$GeneNum)
L2CData$RegNum <- as.numeric(L2CData$RegNum)
L2CData$HiCNum <- as.numeric(L2CData$HiCNum)
M8CData <- as.data.frame(rbind(M8CDataGSR,M8CDataXW))
colnames(M8CData) <- c("PathName","GeneNum","RegNum","HiCNum")
M8CData$GeneNum <- as.numeric(M8CData$GeneNum)
M8CData$RegNum <- as.numeric(M8CData$RegNum)
M8CData$HiCNum <- as.numeric(M8CData$HiCNum)
ICMData <- as.data.frame(rbind(ICMDataGSR,ICMDataXW))
colnames(ICMData) <- c("PathName","GeneNum","RegNum","HiCNum")
ICMData$GeneNum <- as.numeric(ICMData$GeneNum)
ICMData$RegNum <- as.numeric(ICMData$RegNum)
ICMData$HiCNum <- as.numeric(ICMData$HiCNum)

outData <- cbind(c(rep("MII",nrow(MIIData)),rep("E2C",nrow(E2CData)),rep("L2C",nrow(L2CData)),rep("M8C",nrow(M8CData)),rep("ICM",nrow(ICMData))),rbind(MIIData,E2CData,L2CData,M8CData,ICMData))
outData <- cbind(outData,c(rep("GSR",nrow(MIIDataGSR)),rep("XW",nrow(MIIDataXW)),rep("GSR",nrow(E2CDataGSR)),rep("XW",nrow(E2CDataXW)),rep("GSR",nrow(L2CDataGSR)),rep("XW",nrow(L2CDataXW)),rep("GSR",nrow(M8CDataGSR)),rep("XW",nrow(M8CDataXW)),rep("GSR",nrow(ICMDataGSR)),rep("XW",nrow(ICMDataXW))))
outData <- as.data.frame(outData)
colnames(outData) <- c("Stage","PathName","GeneNum","RegNum","HiCNum","DataType")
write.table(outData,file="/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/HiCSuppPerc.txt",sep="\t",row.names=FALSE,col.name=TRUE)

library(dplyr)
MIIData <- MIIData %>% group_by(PathName) %>% summarise_at(vars(GeneNum,RegNum,HiCNum), list(name = mean))
E2CData <- E2CData %>% group_by(PathName) %>% summarise_at(vars(GeneNum,RegNum,HiCNum), list(name = mean))
L2CData <- L2CData %>% group_by(PathName) %>% summarise_at(vars(GeneNum,RegNum,HiCNum), list(name = mean))
M8CData <- M8CData %>% group_by(PathName) %>% summarise_at(vars(GeneNum,RegNum,HiCNum), list(name = mean))
ICMData <- ICMData %>% group_by(PathName) %>% summarise_at(vars(GeneNum,RegNum,HiCNum), list(name = mean))
plotData <- cbind(c(rep("MII",nrow(MIIData)),rep("E2C",nrow(E2CData)),rep("L2C",nrow(L2CData)),rep("M8C",nrow(M8CData)),rep("ICM",nrow(ICMData))),rbind(MIIData,E2CData,L2CData,M8CData,ICMData))
plotData <- as.data.frame(plotData)
colnames(plotData) <- c("Stage","PathName","GeneNum","RegNum","HiCNum")
plotData$GeneNum <- as.numeric(plotData$GeneNum)
plotData$RegNum <- as.numeric(plotData$RegNum)
plotData$HiCNum <- as.numeric(plotData$HiCNum)
plotData[which(is.na(plotData$HiCNum)),5] <- 0
plotData$Stage <- factor(plotData$Stage,levels=c("MII","E2C","L2C","M8C","ICM"))

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/SignalingPathwayRdata/HiCSuppPerc.pdf",width=6,height=10)
p <- ggplot(plotData, aes(x=Stage, y=PathName, size=GeneNum, color=HiCNum)) + geom_point() + scale_color_gradient(low="#FFFFF0",high="#FF00FF") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()
