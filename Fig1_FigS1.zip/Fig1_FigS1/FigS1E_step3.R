library(ggplot2)
library(RColorBrewer)
q7 = brewer.pal(7,'Set1')

H3K4me1_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
H3K27ac_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
CTCF_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
EP300_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
POLR2A_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]
DNase_enhancerData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_EnhancerAltasOnly.txt",sep='\t',header=FALSE,stringsAsFactors=FALSE)[,1]

H3K4me1_enhancerData <- c(median(H3K4me1_enhancerData[1:10]),median(H3K4me1_enhancerData[11:20]),H3K4me1_enhancerData[21],median(H3K4me1_enhancerData[22:31]),median(H3K4me1_enhancerData[32:41]))
H3K27ac_enhancerData <- c(median(H3K27ac_enhancerData[1:10]),median(H3K27ac_enhancerData[11:20]),H3K27ac_enhancerData[21],median(H3K27ac_enhancerData[22:31]),median(H3K27ac_enhancerData[32:41]))
CTCF_enhancerData <- c(median(CTCF_enhancerData[1:10]),median(CTCF_enhancerData[11:20]),CTCF_enhancerData[21],median(CTCF_enhancerData[22:31]),median(CTCF_enhancerData[32:41]))
EP300_enhancerData <- c(median(EP300_enhancerData[1:10]),median(EP300_enhancerData[11:20]),EP300_enhancerData[21],median(EP300_enhancerData[22:31]),median(EP300_enhancerData[32:41]))
POLR2A_enhancerData <- c(median(POLR2A_enhancerData[1:10]),median(POLR2A_enhancerData[11:20]),POLR2A_enhancerData[21],median(POLR2A_enhancerData[22:31]),median(POLR2A_enhancerData[32:41]))
DNase_enhancerData <- c(median(DNase_enhancerData[1:10]),median(DNase_enhancerData[11:20]),DNase_enhancerData[21],median(DNase_enhancerData[22:31]),median(DNase_enhancerData[32:41]))

H3K4me1_enhancerData <- approx(H3K4me1_enhancerData, n=41)$y
H3K27ac_enhancerData <- approx(H3K27ac_enhancerData, n=41)$y
CTCF_enhancerData <- approx(CTCF_enhancerData, n=41)$y
EP300_enhancerData <- approx(EP300_enhancerData, n=41)$y
POLR2A_enhancerData <- approx(POLR2A_enhancerData, n=41)$y
DNase_enhancerData <- approx(DNase_enhancerData, n=41)$y

yvalues <- c(H3K4me1_enhancerData,H3K27ac_enhancerData,DNase_enhancerData,CTCF_enhancerData,EP300_enhancerData,POLR2A_enhancerData)
locations <- rep(c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"),times=6)
grouplabels <- rep(c("H3K4me1","H3K27ac","DNase","CTCF","EP300","POLR2A"),each=41)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=c("Up20","Up19","Up18","Up17","Up16","Up15","Up14","Up13","Up12","Up11","Up10","Up09","Up08","Up07","Up06","Up05","Up04","Up03","Up02","Up01","SS","Down01","Down02","Down03","Down04","Down05","Down06","Down07","Down08","Down09","Down10","Down11","Down12","Down13","Down14","Down15","Down16","Down17","Down18","Down19","Down20"))
plotdata$Value <- as.numeric(yvalues)
plotdata$Group <- factor(grouplabels,levels=c("H3K4me1","H3K27ac","DNase","CTCF","EP300","POLR2A"))

pdf(file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EnhancerAltasOnly.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=Group,color=Group)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q7[c(1,2,4,5,6,7)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6,angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()