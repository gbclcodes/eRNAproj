#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J DUX		
#SBATCH -c 2
#SBATCH --mem 30G
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/%j.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/%j.err

date
source ~/.bashrc
conda activate py37
computeMatrix scale-regions -R /storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/enhancer_annotation_step6_6column.bed -S /storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/*/*.bw -b 1000 -a 1000 --regionBodyLength 1000 --binSize 10 -p 10 -o /storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/enhancer_scaled.gz --outFileNameMatrix /storage/gbcl/yuhua/yuhua_projects/enhProj/DUXESKORNAseqData/hisat2file/enhancer_scaled.tab
date
