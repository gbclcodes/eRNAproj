#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J SNPsplit_genome_pre                          
#SBATCH -c 1
#SBATCH --mem 10G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/CBA_6J/pre.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/CBA_6J/pre.err



/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit_genome_preparation --vcf /storage/gbcl/qiaolu/EpiData/mgp.v5.merged.snps_all.dbSNP142.vcf.gz --reference_genome /storage/gbcl/qiaolu/SNPsplit_genome_pre/mm10_ref --strain CBA_J