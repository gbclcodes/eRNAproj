# Expr
# H3K4me1 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-26)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-26)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/enhancer_density_value_ES.RData")

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/expPlotVec_H3K4me1_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# H3K4me1 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}
 
totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K4me1.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("enhancer_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K4me1.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/nonenhancer_density_value_ES.RData") 

expMeanVec_H3K4me1_enhancer <- rowMeans(expData)
expMeanMatrix_H3K4me1_enhancer <- matrix(expMeanVec_H3K4me1_enhancer,nrow=41)
expMeanMatrix_H3K4me1_enhancer <- apply(expMeanMatrix_H3K4me1_enhancer,2,Zscore)
expMeanMatrix_H3K4me1_enhancer <- expMeanMatrix_H3K4me1_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K4me1_enhancer)))]
expPlotVec_H3K4me1_enhancer <- rowMeans(expMeanMatrix_H3K4me1_enhancer)
write.table(expPlotVec_H3K4me1_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K4me1/nonexpPlotVec_H3K4me1_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# Expr
# H3K27ac enhancer 
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-26)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-26)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/enhancer_density_value_ES.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/expPlotVec_H3K27ac_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# H3K27ac enhancer 
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('H3K27ac.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('H3K27ac.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/nonenhancer_density_value_ES.RData") 

expMeanVec_H3K27ac_enhancer <- rowMeans(expData)
expMeanMatrix_H3K27ac_enhancer <- matrix(expMeanVec_H3K27ac_enhancer,nrow=41)
expMeanMatrix_H3K27ac_enhancer <- apply(expMeanMatrix_H3K27ac_enhancer,2,Zscore)
expMeanMatrix_H3K27ac_enhancer <- expMeanMatrix_H3K27ac_enhancer[,which(!is.na(colSums(expMeanMatrix_H3K27ac_enhancer)))]
expPlotVec_H3K27ac_enhancer <- rowMeans(expMeanMatrix_H3K27ac_enhancer)
write.table(expPlotVec_H3K27ac_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/H3K27ac/nonexpPlotVec_H3K27ac_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# Expr
# CTCF enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-26)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-26)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/enhancer_density_value_ES.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/expPlotVec_CTCF_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# CTCF enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('CTCF.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+5,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('CTCF.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+5,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/nonenhancer_density_value_ES.RData") 

expMeanVec_CTCF_enhancer <- rowMeans(expData)
expMeanMatrix_CTCF_enhancer <- matrix(expMeanVec_CTCF_enhancer,nrow=41)
# expMeanMatrix_CTCF_enhancer  <- expMeanMatrix_CTCF_enhancer[11:31,]
expMeanMatrix_CTCF_enhancer <- apply(expMeanMatrix_CTCF_enhancer,2,Zscore)
expMeanMatrix_CTCF_enhancer <- expMeanMatrix_CTCF_enhancer[,which(!is.na(colSums(expMeanMatrix_CTCF_enhancer)))]
expPlotVec_CTCF_enhancer <- rowMeans(expMeanMatrix_CTCF_enhancer)
write.table(expPlotVec_CTCF_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/CTCF/nonexpPlotVec_CTCF_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# Expr
# EP300 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/enhancer_density_value_ES.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/expPlotVec_EP300_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# EP300 enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('EP300.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('EP300.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/nonenhancer_density_value_ES.RData") 

expMeanVec_EP300_enhancer <- rowMeans(expData)
expMeanMatrix_EP300_enhancer <- matrix(expMeanVec_EP300_enhancer,nrow=41)
expMeanMatrix_EP300_enhancer <- apply(expMeanMatrix_EP300_enhancer,2,Zscore)
expMeanMatrix_EP300_enhancer <- expMeanMatrix_EP300_enhancer[,which(!is.na(colSums(expMeanMatrix_EP300_enhancer)))]
expPlotVec_EP300_enhancer <- rowMeans(expMeanMatrix_EP300_enhancer)
write.table(expPlotVec_EP300_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/EP300/nonexpPlotVec_EP300_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# Expr
# POLR2A enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-26)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-26)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/enhancer_density_value_ES.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/expPlotVec_POLR2A_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# POLR2A enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('POLR2A.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+7,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('POLR2A.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+7,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/nonenhancer_density_value_ES.RData") 

expMeanVec_POLR2A_enhancer <- rowMeans(expData)
expMeanMatrix_POLR2A_enhancer <- matrix(expMeanVec_POLR2A_enhancer,nrow=41)
expMeanMatrix_POLR2A_enhancer <- apply(expMeanMatrix_POLR2A_enhancer,2,Zscore)
expMeanMatrix_POLR2A_enhancer <- expMeanMatrix_POLR2A_enhancer[,which(!is.na(colSums(expMeanMatrix_POLR2A_enhancer)))]
expPlotVec_POLR2A_enhancer <- rowMeans(expMeanMatrix_POLR2A_enhancer)
write.table(expPlotVec_POLR2A_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/POLR2A/nonexpPlotVec_POLR2A_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# Expr
# DNase enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_Expr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-26)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-26)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/enhancer_density_value_ES.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/expPlotVec_DNase_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)

# NonExpr
# DNase enhancer
Zscore <- function(x){
	y <- (x-mean(x))/sd(x)
}

totalfiles <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase","*_NonExpr_ICM_Enhancer_ES.bed"))
files <- c()
for (filename in totalfiles){
	if(file.info(filename)$size > 0){
		files <- c(files,filename)
	}	
}
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(4,5)]
posIndex <- regexpr('DNase.*ancer_ES.bed',files[1])
sampleid <- substring(files[1],posIndex+6,posIndex+attr(posIndex,'match.length')-29)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)

for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
        if(nrow(sampleMat)==nrow(expData)){
            expData <- cbind(expData,sampleMat[,5])
            posIndex <- regexpr('DNase.*ancer_ES.bed',filename)
            sampleid <- substring(filename,posIndex+6,posIndex+attr(posIndex,'match.length')-29)
            cat(sampleid,"\n")
            columnNames <- append(columnNames,sampleid)
        }
	}
}
colnames(expData) <- columnNames
rownames(expData) <- expData[,1]
expData[,1] <- NULL
save(expData,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/nonenhancer_density_value_ES.RData") 

expMeanVec_DNase_enhancer <- rowMeans(expData)
expMeanMatrix_DNase_enhancer <- matrix(expMeanVec_DNase_enhancer,nrow=41)
expMeanMatrix_DNase_enhancer <- apply(expMeanMatrix_DNase_enhancer,2,Zscore)
expMeanMatrix_DNase_enhancer <- expMeanMatrix_DNase_enhancer[,which(!is.na(colSums(expMeanMatrix_DNase_enhancer)))]
expPlotVec_DNase_enhancer <- rowMeans(expMeanMatrix_DNase_enhancer)
write.table(expPlotVec_DNase_enhancer,file="/media/yuhua/yuhua_projects/enhProj/ENCODEData/DNase/nonexpPlotVec_DNase_enhancer_ES.txt",sep='\t',quote=FALSE,row.names=F,col.names=F)
