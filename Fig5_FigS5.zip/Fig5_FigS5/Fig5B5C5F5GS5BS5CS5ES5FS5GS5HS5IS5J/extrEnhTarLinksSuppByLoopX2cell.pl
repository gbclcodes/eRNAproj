#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Path;

my ($enhtarnetfile,$enhposfile,$geneposfile,$loopfile,$genestagefile,$enhstagefile,$stagename,$outfile,$help);
GetOptions(
	"enhtarnetfile=s" => \$enhtarnetfile,
	"enhposfile=s" => \$enhposfile,
	"geneposfile=s" => \$geneposfile,
	"loopfile=s" => \$loopfile,
	"genestagefile=s" => \$genestagefile,
	"enhstagefile=s" => \$enhstagefile,
	"stagename=s" => \$stagename,
	"outfile=s" => \$outfile,
	"help!" => \$help,
);

my(%enhtarHash,%enhposHash,%geneposHash,%loopHash,%genestageHash,%enhstageHash);
open(ES,"<$enhstagefile") or die "$!\n";
while(<ES>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\s+/, $line;
	$enhstageHash{$fieldValues[0]} = $fieldValues[2];
	
}
close ES;

open(GS,"<$genestagefile") or die "$!\n";
while(<GS>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\s+/, $line;
	$fieldValues[0] =~ s/\.\d+//;
	$genestageHash{$fieldValues[0]} = $fieldValues[2];
	
}
close GS;

open(ET,"<$enhtarnetfile") or die "$!\n";
while(<ET>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\t/,$line;
	if(exists $enhstageHash{$fieldValues[0]} && exists $genestageHash{$fieldValues[1]}){
		if($enhstageHash{$fieldValues[0]} eq $stagename && $genestageHash{$fieldValues[1]} eq $stagename){
			$enhtarHash{"$fieldValues[0]\t$fieldValues[1]"} = 1;
		}
	}
}
close ET;

open(EP,"<$enhposfile") or die "$!\n";
while(<EP>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\t/,$line;
	$enhposHash{$fieldValues[3]}{"chrom"} = $fieldValues[0];
	$enhposHash{$fieldValues[3]}{"start"} = $fieldValues[1];
	$enhposHash{$fieldValues[3]}{"end"} = $fieldValues[2];
}
close EP;

open(GP,"<$geneposfile") or die "$!\n";
while(<GP>){
	my $line = $_;
	chomp $line;
	my @fieldValues = split /\t/,$line;
	$geneposHash{$fieldValues[3]}{"chrom"} = $fieldValues[0];
	$geneposHash{$fieldValues[3]}{"start"} = $fieldValues[1];
	$geneposHash{$fieldValues[3]}{"end"} = $fieldValues[2];
}
close GP;

open(LP,"<$loopfile") or die "$!\n";
while(<LP>){
	my $line = $_;
	chomp $line;
	next if($line =~ /^#/);
	my @fieldValues = split /\t/,$line;
	$loopHash{"$fieldValues[0]--$fieldValues[1]--$fieldValues[2]--$fieldValues[3]--$fieldValues[4]--$fieldValues[5]"} = 1;
}
close LP;

open(OUT,">$outfile") or die "$!\n";
foreach my $enhtarpair (keys %enhtarHash){
	my @pair = split /\t/,$enhtarpair;
	if(exists $enhposHash{$pair[0]} && exists $geneposHash{$pair[1]}){
		my $enhchrom = $enhposHash{$pair[0]}{"chrom"}; 
		my $enhstart = $enhposHash{$pair[0]}{"start"};
		my $enhend = $enhposHash{$pair[0]}{"end"};
		my $genechrom = $geneposHash{$pair[1]}{"chrom"}; 
		my $genestart = $geneposHash{$pair[1]}{"start"}; 
		my $geneend = $geneposHash{$pair[1]}{"end"};
		foreach my $loop (keys %loopHash){
			my @loopinfo = split /--/,$loop;
			if($enhchrom eq $genechrom && $loopinfo[0] eq $loopinfo[3] && $enhchrom eq $loopinfo[0]){
				if(($enhstart <= $loopinfo[1] && $enhend >= $loopinfo[1]) || ($enhstart <= $loopinfo[2] && $enhend >= $loopinfo[2]) || ($loopinfo[1] <= $enhstart && $loopinfo[2] >= $enhstart) || ($loopinfo[1] <= $enhend && $loopinfo[2] >= $enhend)){
					if(($genestart <= $loopinfo[4] && $geneend >= $loopinfo[4]) || ($genestart <= $loopinfo[5] && $geneend >= $loopinfo[5]) || ($loopinfo[4] <= $genestart && $loopinfo[5] >= $genestart) || ($loopinfo[4] <= $geneend && $loopinfo[5] >= $geneend)){
						print OUT "$pair[0]\t$enhchrom\t$enhstart\t$enhend\t$pair[1]\t$genechrom\t$genestart\t$geneend\t".join("\t",@loopinfo)."\n";
					}
				}elsif(($enhstart <= $loopinfo[4] && $enhend >= $loopinfo[4]) || ($enhstart <= $loopinfo[5] && $enhend >= $loopinfo[5]) || ($loopinfo[4] <= $enhstart && $loopinfo[5] >= $enhstart) || ($loopinfo[4] <= $enhend && $loopinfo[5] >= $enhend)){
					if(($genestart <= $loopinfo[1] && $geneend >= $loopinfo[1]) || ($genestart <= $loopinfo[2] && $geneend >= $loopinfo[2]) || ($loopinfo[1] <= $genestart && $loopinfo[2] >= $genestart) || ($loopinfo[1] <= $geneend && $loopinfo[2] >= $geneend)){
						print OUT "$pair[0]\t$enhchrom\t$enhstart\t$enhend\t$pair[1]\t$genechrom\t$genestart\t$geneend\t".join("\t",@loopinfo)."\n";
					}
				}
			}
		}
	}
}
close OUT;


# perl extrEnhTarLinksSuppByLoopX2cell.pl --enhtarnetfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt --enhposfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_step6_GSR_6column_mm9.bed --geneposfile /media/yuhua/yuhua_projects/enhProj/ENHData/known_genes_mm9.bed --loopfile /media/yuhua/yuhua_projects/enhProj/ENHData/E2C.bedpe --genestagefile /media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_GSR.txt --enhstagefile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores_stagename_GSR.txt --stagename X2cell --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/X2cellEnhTarLinksSuppByE2Cloop.txt

# perl extrEnhTarLinksSuppByLoopX2cell.pl --enhtarnetfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_GSR_all.txt --enhposfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_step6_GSR_6column_mm9.bed --geneposfile /media/yuhua/yuhua_projects/enhProj/ENHData/known_genes_mm9.bed --loopfile /media/yuhua/yuhua_projects/enhProj/ENHData/L2C.bedpe --genestagefile /media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_GSR.txt --enhstagefile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores_stagename_GSR.txt --stagename X2cell --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/X2cellEnhTarLinksSuppByL2Cloop.txt

# perl extrEnhTarLinksSuppByLoopX2cell.pl --enhtarnetfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt --enhposfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_step6_XW_6column_mm9.bed --geneposfile /media/yuhua/yuhua_projects/enhProj/ENHData/known_genes_mm9.bed --loopfile /media/yuhua/yuhua_projects/enhProj/ENHData/E2C.bedpe --genestagefile /media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_XW.txt --enhstagefile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores_stagename_XW.txt --stagename E2C --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/E2CEnhTarLinksSuppByE2Cloop.txt

# perl extrEnhTarLinksSuppByLoopX2cell.pl --enhtarnetfile /media/yuhua/yuhua_projects/enhProj/ENHData/enh_target_pairs_XW_all.txt --enhposfile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_annotation_step6_XW_6column_mm9.bed --geneposfile /media/yuhua/yuhua_projects/enhProj/ENHData/known_genes_mm9.bed --loopfile /media/yuhua/yuhua_projects/enhProj/ENHData/L2C.bedpe --genestagefile /media/yuhua/yuhua_projects/enhProj/GENEData/gene_stage_specific_scores_XW.txt --enhstagefile /media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores_stagename_XW.txt --stagename L2C --outfile /media/yuhua/yuhua_projects/enhProj/ENHData/L2CEnhTarLinksSuppByL2Cloop.txt