#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J SNPsplit_genome_pre                          
#SBATCH -c 1
#SBATCH --mem 100G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/DBA_6NJ/pre.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/DBA_6NJ/pre.err

cd /storage/gbcl/qiaolu/EpiData/DBA_6NJ

/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit_genome_preparation --vcf /storage/gbcl/qiaolu/EpiData/mgp.v5.merged.snps_all.dbSNP142.vcf.gz --reference_genome /storage/gbcl/qiaolu/SNPsplit_genome_pre/mm10_ref --strain DBA_2J --strain2 C57BL_6NJ