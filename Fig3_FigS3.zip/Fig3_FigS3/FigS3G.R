# Hi-C Supported percentage
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIGSR.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CGSR.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CGSR.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CGSR.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMGSR.dev.RData")

percMIIGSR.dev <- length(which(enhTarPairsOEvecMII > 0))/length(enhTarPairsOEvecMII)
percE2CGSR.dev <- length(which(enhTarPairsOEvecE2C > 0))/length(enhTarPairsOEvecE2C)
percL2CGSR.dev <- length(which(enhTarPairsOEvecL2C > 0))/length(enhTarPairsOEvecL2C)
percM8CGSR.dev <- length(which(enhTarPairsOEvecM8C > 0))/length(enhTarPairsOEvecM8C)
percICMGSR.dev <- length(which(enhTarPairsOEvecICM > 0))/length(enhTarPairsOEvecICM)

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIGSR.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CGSR.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CGSR.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CGSR.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMGSR.nondev.RData")

percMIIGSR.nondev <- length(which(enhTarPairsOEvecMII > 0))/length(enhTarPairsOEvecMII)
percE2CGSR.nondev <- length(which(enhTarPairsOEvecE2C > 0))/length(enhTarPairsOEvecE2C)
percL2CGSR.nondev <- length(which(enhTarPairsOEvecL2C > 0))/length(enhTarPairsOEvecL2C)
percM8CGSR.nondev <- length(which(enhTarPairsOEvecM8C > 0))/length(enhTarPairsOEvecM8C)
percICMGSR.nondev <- length(which(enhTarPairsOEvecICM > 0))/length(enhTarPairsOEvecICM)

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIXW.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CXW.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CXW.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CXW.dev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMXW.dev.RData")

percMIIXW.dev <- length(which(enhTarPairsOEvecMII > 0))/length(enhTarPairsOEvecMII)
percE2CXW.dev <- length(which(enhTarPairsOEvecE2C > 0))/length(enhTarPairsOEvecE2C)
percL2CXW.dev <- length(which(enhTarPairsOEvecL2C > 0))/length(enhTarPairsOEvecL2C)
percM8CXW.dev <- length(which(enhTarPairsOEvecM8C > 0))/length(enhTarPairsOEvecM8C)
percICMXW.dev <- length(which(enhTarPairsOEvecICM > 0))/length(enhTarPairsOEvecICM)

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIXW.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CXW.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CXW.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CXW.nondev.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMXW.nondev.RData")

percMIIXW.nondev <- length(which(enhTarPairsOEvecMII > 0))/length(enhTarPairsOEvecMII)
percE2CXW.nondev <- length(which(enhTarPairsOEvecE2C > 0))/length(enhTarPairsOEvecE2C)
percL2CXW.nondev <- length(which(enhTarPairsOEvecL2C > 0))/length(enhTarPairsOEvecL2C)
percM8CXW.nondev <- length(which(enhTarPairsOEvecM8C > 0))/length(enhTarPairsOEvecM8C)
percICMXW.nondev <- length(which(enhTarPairsOEvecICM > 0))/length(enhTarPairsOEvecICM)

percMII.dev <- (percMIIGSR.dev + percMIIXW.dev)/2
percE2C.dev <- (percE2CGSR.dev + percE2CXW.dev)/2
percL2C.dev <- (percL2CGSR.dev + percL2CXW.dev)/2
percM8C.dev <- (percM8CGSR.dev + percM8CXW.dev)/2
percICM.dev <- (percICMGSR.dev + percICMXW.dev)/2

percMII.nondev <- (percMIIGSR.nondev + percMIIXW.nondev)/2
percE2C.nondev <- (percE2CGSR.nondev + percE2CXW.nondev)/2
percL2C.nondev <- (percL2CGSR.nondev + percL2CXW.nondev)/2
percM8C.nondev <- (percM8CGSR.nondev + percM8CXW.nondev)/2
percICM.nondev <- (percICMGSR.nondev + percICMXW.nondev)/2

perc <- c(percMII.dev,percE2C.dev,percL2C.dev,percM8C.dev,percICM.dev,percMII.nondev,percE2C.nondev,percL2C.nondev,percM8C.nondev,percICM.nondev)
stage <- c("MII","E2C","L2C","M8C","ICM","MII","E2C","L2C","M8C","ICM")
type <- c("DEV","DEV","DEV","DEV","DEV","NONDEV","NONDEV","NONDEV","NONDEV","NONDEV")

statData <- as.data.frame(cbind(perc,stage,type))
colnames(statData) <- c("perc","stage","type")
statData$perc <- as.numeric(statData$perc)
statData$stage <- factor(statData$stage,levels=c("MII","E2C","L2C","M8C","ICM"))
statData$type <- factor(statData$type,levels=c("DEV","NONDEV"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/DevNonDevPerc.pdf",width=6,height=5)
p <- ggplot(data=statData, aes(x=stage, y=perc, fill=type)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()