#!/usr/bin/perl -w
use warnings;
use strict;
use Getopt::Long;

my ($ginterfile,$bedfile,$hicprofile,$help);
GetOptions(
    "ginterfile=s" => \$ginterfile,
    "bedfile=s" => \$bedfile,
    "hicprofile=s" => \$hicprofile,
	"help!" => \$help,
);

my (%giHash,%bedHash);
open(GI,"<$ginterfile") or die "$!\n";
while(<GI>){
    my $line = $_;
    chomp $line;
    my @fieldValues = split /\s+/,$line;
    $giHash{"$fieldValues[0]--$fieldValues[1]--$fieldValues[2]"}{"$fieldValues[3]--$fieldValues[4]--$fieldValues[5]"} = $fieldValues[6];
}
close GI;

open(BED,"<$bedfile") or die "$!\n";
while(<BED>){
    my $line = $_;
    chomp $line;
    my @fieldValues = split /\s+/,$line;
    $bedHash{"$fieldValues[0]--$fieldValues[1]--$fieldValues[2]"} = $fieldValues[3];
}
close BED;

my %outHash;
foreach my $bin1 (keys %giHash){
    foreach my $bin2 (keys %{$giHash{$bin1}}){
       $outHash{$bedHash{$bin1}}{$bedHash{$bin2}} = $giHash{$bin1}{$bin2};
    }
}
close HP;

open(HP,">$hicprofile") or die "$!\n";
foreach my $bin1 (sort {$a <=> $b} keys %outHash){
    foreach my $bin2 (sort {$a <=> $b} keys %{$outHash{$bin1}}){
        print HP "$bin1\t$bin2\t$outHash{$bin1}{$bin2}\n";
    }
}
close HP;

# perl tranGInterToHiCPro.pl --ginterfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/MIIoocyte/kr/MIIoocyte_corrected_obsexp_20000.ginteraction.tsv --bedfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/MIIoocyte/raw/20000/GSE82185_MII_rep12_20000_abs.bed --hicprofile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/MIIoocyte/kr/MIIoocyte_corrected_obsexp_20000.matrix

# perl tranGInterToHiCPro.pl --ginterfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/early2cell/kr/E2C_corrected_obsexp_20000.ginteraction.tsv --bedfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/early2cell/raw/20000/GSE82185_early_2cell_rep123_20000_abs.bed --hicprofile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/early2cell/kr/E2C_corrected_obsexp_20000.matrix

# perl tranGInterToHiCPro.pl --ginterfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/late2cell/kr/L2C_corrected_obsexp_20000.ginteraction.tsv --bedfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/late2cell/raw/20000/GSE82185_late_2cell_rep1234_20000_abs.bed --hicprofile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/late2cell/kr/L2C_corrected_obsexp_20000.matrix

# perl tranGInterToHiCPro.pl --ginterfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/8cell/kr/M8C_corrected_obsexp_20000.ginteraction.tsv --bedfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/8cell/raw/20000/GSE82185_8cell_rep123_20000_abs.bed --hicprofile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/8cell/kr/M8C_corrected_obsexp_20000.matrix

# perl tranGInterToHiCPro.pl --ginterfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/ICM/kr/ICM_corrected_obsexp_20000.ginteraction.tsv --bedfile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/ICM/raw/20000/GSE82185_ICM_rep123_20000_abs.bed --hicprofile /media/yuhua/yuhua_projects/enhProj/XWData/HiCData_XW/matrix/ICM/kr/ICM_corrected_obsexp_20000.matrix