#!/usr/bin/env python


import os
import shutil
import glob

def mkdir_p(dir):
    '''make a directory (dir) if it doesn't exist'''
    if not os.path.exists(dir):
        os.mkdir(dir)

Epiname = "H3K27ac_CBA"

mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/%s_SNP" % Epiname)
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/%s_SNP/script" % Epiname)

job_directory = "/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/%s_SNP" % Epiname
script_directory = "/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/%s_SNP/script" % Epiname
data_directory = "/storage/gbcl/qiaolu/EpiData/H3K27ac_CBA/mapping"

os.chdir(data_directory)
files = glob.glob("*sam")

for file in files:
    file_name = file[:10]
    job_file = os.path.join(script_directory,"%s_SNP.bash" % file_name)

    with open(job_file, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p amd-ep2\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J %s \n" % file_name)
        fh.writelines("#SBATCH -c 1\n")
        fh.writelines("#SBATCH --mem 50G\n")
        fh.writelines("#SBATCH -o %s/%s.out\n" % (job_directory, file_name))
        fh.writelines("#SBATCH -e %s/%s.err\n" % (job_directory, file_name))
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load samtools/1.14 \n")
        fh.writelines("/storage/gbcl/qiaolu/SNPsplit-master/SNPsplit -o %s/%s --paired --snp_file /storage/gbcl/qiaolu/EpiData/CBA_6J/all_SNPs_CBA_J_GRCm38.txt.gz %s/" % (job_directory, file_name, data_directory) + file )

    # os.system("sbatch %s" %job_file)