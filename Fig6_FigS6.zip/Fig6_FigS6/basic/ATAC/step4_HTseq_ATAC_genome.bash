#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J HT_ATAC
#SBATCH -c 2
#SBATCH --mem 10G
#SBATCH -o /storage/gbcl/qiaolu/EpiData/ATAC_MD/result/HT_genome.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/ATAC_MD/result/HT_genome.err

cd /storage/gbcl/qiaolu/EpiData/ATAC_MD/result

ls *.bam | while read file; do (htseq-count -c ${file:0:23}_genome.csv -r pos -f bam -s no --nonunique all -q $file /storage/gbcl/qiaolu/new_gencode.vM17.annotation.gff3); done
