files <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_LF_DNase","*","htseq_count.txt"))
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(1,2)]
posIndex <- regexpr('R_DNase.*htseq_count',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-13)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)
for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
		matchIndex <- match(uniqEnsemids,sampleMat[,1])
		expData <- cbind(expData,sampleMat[matchIndex,2])
		posIndex <- regexpr('R_DNase.*htseq_count',filename)
		sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-13)
		cat(sampleid,"\n")
		columnNames <- append(columnNames,sampleid)
	}
}
colnames(expData) <- columnNames
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_LF_DNase/enhancer_counts.txt",sep='\t',quote=FALSE,row.names=T,col.names=T)

files <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K9me3","*","htseq_count.txt"))
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(1,2)]
posIndex <- regexpr('H3K9me3.*htseq_count',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-13)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)
for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
		matchIndex <- match(uniqEnsemids,sampleMat[,1])
		expData <- cbind(expData,sampleMat[matchIndex,2])
		posIndex <- regexpr('H3K9me3.*htseq_count',filename)
		sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-13)
		cat(sampleid,"\n")
		columnNames <- append(columnNames,sampleid)
	}
}
colnames(expData) <- columnNames
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K9me3/enhancer_counts.txt",sep='\t',quote=FALSE,row.names=T,col.names=T)

files <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K27me3","*","htseq_count.txt"))
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(1,2)]
posIndex <- regexpr('3K27me3.*htseq_count',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-13)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)
for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
		matchIndex <- match(uniqEnsemids,sampleMat[,1])
		expData <- cbind(expData,sampleMat[matchIndex,2])
		posIndex <- regexpr('3K27me3.*htseq_count',filename)
		sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-13)
		cat(sampleid,"\n")
		columnNames <- append(columnNames,sampleid)
	}
}
colnames(expData) <- columnNames
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K27me3/enhancer_counts.txt",sep='\t',quote=FALSE,row.names=T,col.names=T)


files <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW_ATAC","*","htseq_count.txt"))
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(1,2)]
posIndex <- regexpr('H3K4me3.*htseq_count',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-13)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)
for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
		matchIndex <- match(uniqEnsemids,sampleMat[,1])
		expData <- cbind(expData,sampleMat[matchIndex,2])
		posIndex <- regexpr('H3K4me3.*htseq_count',filename)
		sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-13)
		cat(sampleid,"\n")
		columnNames <- append(columnNames,sampleid)
	}
}
colnames(expData) <- columnNames
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_ATAC/enhancer_counts.txt",sep='\t',quote=FALSE,row.names=T,col.names=T)


files <- Sys.glob(file.path("/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW_H3K27ac","*","htseq_count.txt"))
expData <- read.delim(file=files[1],header=FALSE,stringsAsFactors=FALSE)
expData <- expData[,c(1,2)]
posIndex <- regexpr('H3K4me3.*htseq_count',files[1])
sampleid <- substring(files[1],posIndex+8,posIndex+attr(posIndex,'match.length')-13)
uniqIndex <- which(!duplicated(as.character(expData[,1])))
uniqEnsemids <- as.character(expData[uniqIndex,1])
expData <- expData[uniqIndex,]
columnNames <- c("gene_id",sampleid)
for (filename in files[2:length(files)]){
	if(file.info(filename)[1] > 0){
		sampleMat <- read.delim(file=filename,header=FALSE,stringsAsFactors=FALSE)
		matchIndex <- match(uniqEnsemids,sampleMat[,1])
		expData <- cbind(expData,sampleMat[matchIndex,2])
		posIndex <- regexpr('H3K4me3.*htseq_count',filename)
		sampleid <- substring(filename,posIndex+8,posIndex+attr(posIndex,'match.length')-13)
		cat(sampleid,"\n")
		columnNames <- append(columnNames,sampleid)
	}
}
colnames(expData) <- columnNames
write.table(expData,file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K27ac/enhancer_counts.txt",sep='\t',quote=FALSE,row.names=T,col.names=T)