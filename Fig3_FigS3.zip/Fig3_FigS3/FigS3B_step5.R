q99 <- 0

load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIGSR.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CGSR.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CGSR.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CGSR.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMGSR.RData")
percMIIGSR <- length(which(enhTarPairsOEvecMII > q99))/length(enhTarPairsOEvecMII)
percE2CGSR <- length(which(enhTarPairsOEvecE2C > q99))/length(enhTarPairsOEvecE2C)
percL2CGSR <- length(which(enhTarPairsOEvecL2C > q99))/length(enhTarPairsOEvecL2C)
percM8CGSR <- length(which(enhTarPairsOEvecM8C > q99))/length(enhTarPairsOEvecM8C)
percICMGSR <- length(which(enhTarPairsOEvecICM > q99))/length(enhTarPairsOEvecICM)
(length(which(enhTarPairsOEvecE2C > q99)) + length(which(enhTarPairsOEvecL2C > q99)) + length(which(enhTarPairsOEvecM8C > q99)) + length(which(enhTarPairsOEvecICM > q99)))/(length(enhTarPairsOEvecE2C) + length(enhTarPairsOEvecL2C) + length(enhTarPairsOEvecM8C) + length(enhTarPairsOEvecICM))
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecMIIXW.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecE2CXW.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecL2CXW.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecM8CXW.RData")
load("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/enhTarPairOEvecICMXW.RData")
percMIIXW <- length(which(enhTarPairsOEvecMII > q99))/length(enhTarPairsOEvecMII)
percE2CXW <- length(which(enhTarPairsOEvecE2C > q99))/length(enhTarPairsOEvecE2C)
percL2CXW <- length(which(enhTarPairsOEvecL2C > q99))/length(enhTarPairsOEvecL2C)
percM8CXW <- length(which(enhTarPairsOEvecM8C > q99))/length(enhTarPairsOEvecM8C)
percICMXW <- length(which(enhTarPairsOEvecICM > q99))/length(enhTarPairsOEvecICM)
(length(which(enhTarPairsOEvecE2C > q99)) + length(which(enhTarPairsOEvecL2C > q99)) + length(which(enhTarPairsOEvecM8C > q99)) + length(which(enhTarPairsOEvecICM > q99)))/(length(enhTarPairsOEvecE2C) + length(enhTarPairsOEvecL2C) + length(enhTarPairsOEvecM8C) + length(enhTarPairsOEvecICM))
percMII <- (percMIIGSR + percMIIXW)/2
percE2C <- (percE2CGSR + percE2CXW)/2
percL2C <- (percL2CGSR + percL2CXW)/2
percM8C <- (percM8CGSR + percM8CXW)/2
percICM <- (percICMGSR + percICMXW)/2
RealPerc <- c(percE2C,percL2C,percM8C,percICM)  

randPercVecMII <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","enhTarPairOEvecMII*RData"))
for (randfile in randfiles){
	enhTarPairOEvec <- load(randfile)
	enhTarPairOEvec <- eval(parse(text = enhTarPairOEvec))
	percValue <- length(which(enhTarPairOEvec > q99))/length(enhTarPairOEvec)
	randPercVecMII <- c(randPercVecMII,percValue)
}

randPercVecE2C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","enhTarPairOEvecE2C*RData"))
for (randfile in randfiles){
	enhTarPairOEvec <- load(randfile)
	enhTarPairOEvec <- eval(parse(text = enhTarPairOEvec))
	percValue <- length(which(enhTarPairOEvec > q99))/length(enhTarPairOEvec)
	randPercVecE2C <- c(randPercVecE2C,percValue)
}

randPercVecL2C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","enhTarPairOEvecL2C*RData"))
for (randfile in randfiles){
	enhTarPairOEvec <- load(randfile)
	enhTarPairOEvec <- eval(parse(text = enhTarPairOEvec))
	percValue <- length(which(enhTarPairOEvec > q99))/length(enhTarPairOEvec)
	randPercVecL2C <- c(randPercVecL2C,percValue)
}

randPercVecM8C <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","enhTarPairOEvecM8C*RData"))
for (randfile in randfiles){
	enhTarPairOEvec <- load(randfile)
	enhTarPairOEvec <- eval(parse(text = enhTarPairOEvec))
	percValue <- length(which(enhTarPairOEvec > q99))/length(enhTarPairOEvec)
	randPercVecM8C <- c(randPercVecM8C,percValue)
}

randPercVecICM <- c()
randfiles <- Sys.glob(file.path("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND","enhTarPairOEvecICM*RData"))
for (randfile in randfiles){
	enhTarPairOEvec <- load(randfile)
	enhTarPairOEvec <- eval(parse(text = enhTarPairOEvec))
	percValue <- length(which(enhTarPairOEvec > q99))/length(enhTarPairOEvec)
	randPercVecICM <- c(randPercVecICM,percValue)
}
RandPerc <- c(median(randPercVecE2C),median(randPercVecL2C),median(randPercVecM8C),median(randPercVecICM))

condition <- rep(c("Real","Random"),c(4,4))
type <- rep(c("E2C","L2C","M8C","ICM"),2)
percvalue <- c(as.numeric(RealPerc),as.numeric(RandPerc))
plotData <- as.data.frame(cbind(percvalue,type,condition))
colnames(plotData) <- c("percvalue","type","condition")
plotData$percvalue <- as.numeric(percvalue)
plotData$type <- factor(type,levels=c("E2C","L2C","M8C","ICM"))
plotData$condition <- factor(condition,levels=c("Real","Random"))

library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/REAL/EnhTarHiCSupportedPerc.pdf",width=8,height=5)
p <- ggplot(data=plotData, aes(x=type, y=percvalue, fill=condition)) + geom_bar(stat="identity",position=position_dodge2(preserve = 'single', width = 0.5, padding = 0.5)) + scale_fill_manual(values = q4[c(1,2)])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()