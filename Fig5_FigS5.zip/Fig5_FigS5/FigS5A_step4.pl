#!/usr/bin/perl -w
use strict;

for (my $iterer = 1; $iterer <= 100; $iterer++){
    open OUT,">/storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/permutation_$iterer.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $iterer			
#SBATCH -c 10
#SBATCH --mem 60G
#SBATCH -o /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/%j.log
#SBATCH -e /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/%j.err

date
source ~/.bashrc
conda activate R41
Rscript --vanilla figS5a_step4.R $iterer
date
EOF
	close OUT;
	my $sb = `sbatch /storage/gbcl/yuhua/yuhua_projects/enhProj/HiCData_XW/RAND/permutation_$iterer.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$iterer is not successfully submitted\n";
	}
	
	my $taskNum =`squeue -u yuhua | wc -l`; 
    	while($taskNum > 100){
        	print "The num of task remaining $taskNum\n";
        	sleep 30;
        	print `date`;
        	$taskNum = `squeue -u yuhua | wc -l`;
    	}
}

# perl fig5b_step4.pl 
