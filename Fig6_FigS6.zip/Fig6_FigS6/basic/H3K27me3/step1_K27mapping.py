#!/usr/bin/env python

import os
import shutil
import glob

def mkdir_p(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)
    
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27me3_mapping/script")

job_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3_mapping/files"
script_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3_mapping/script"

os.chdir("/storage/gbcl/qiaolu/EpiData/H3K27me3")
files = glob.glob("*_1.fastq")

for file in files:
    file_name = file[:10]
    job_file = os.path.join(script_directory,"%s.bash" %file_name)


    with open(job_file, "w") as fh:
        fh.writelines("#!/bin/bash\n")
        fh.writelines("#SBATCH -p amd-ep2\n")
        fh.writelines("#SBATCH -q normal\n")
        fh.writelines("#SBATCH -J K27map_%s\n" % file_name)
        fh.writelines("#SBATCH -c 1\n")
        fh.writelines("#SBATCH --mem 100G\n")
        fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27me3_mapping/%s.out\n" % file_name)
        fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27me3_mapping/%s.err\n" % file_name)
        fh.writelines("cd %s \n" % job_directory)
        fh.writelines("module load bowtie/2.4.2 \n")
        fh.writelines("bowtie2 -t -q -N 1 -L 25 -X 2000 --no-mixed --no-discordant -x DBA_2J_N-masked_genome -1 /storage/gbcl/qiaolu/EpiData/H3K27me3/%s_1.fastq -2 /storage/gbcl/qiaolu/EpiData/H3K27me3/%s_2.fastq -S K27_%s_mapping.sam" % (file_name, file_name, file_name))

    os.system("sbatch %s" %job_file)

