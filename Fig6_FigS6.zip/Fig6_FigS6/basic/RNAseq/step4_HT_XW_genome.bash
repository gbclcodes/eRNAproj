#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J HT
#SBATCH -c 2
#SBATCH --mem 8G
#SBATCH -o /storage/gbcl/qiaolu/XWresult/byname/HT_genome.log
#SBATCH -e /storage/gbcl/qiaolu/XWresult/byname/HT_genome.err

cd /storage/gbcl/qiaolu/XWresult/byname

ls *.bam | while read file; do (htseq-count -c ${file:0:18}_genome.csv -f bam -s no --nonunique all -q $file /storage/gbcl/qiaolu/new_gencode.vM17.annotation.gff3); done
