tf.enh.motif.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
tf.enh.motif.pairs.gsr <- tf.enh.motif.pairs.gsr[grep("X2cell",tf.enh.motif.pairs.gsr[,4]),]
tfIDs <- unique(tf.enh.motif.pairs.gsr[,5])

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
enhexpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/enhancer_TPM.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
rownames(enhexpData) <- rownames(mapInfo)

medianVal <- c()
for (tfID in tfIDs){
	matchIndexes <- which(tf.enh.motif.pairs.gsr[,5]==tfID)
	matchIndexes <- match(tf.enh.motif.pairs.gsr[matchIndexes,1],rownames(enhexpData))
	medianVal <- c(medianVal,median(enhexpData[matchIndexes,1]))
}
names(medianVal) <- tfIDs

medianVal <- sort(medianVal,decreasing=TRUE)
tfIDs <- names(medianVal)[1:10]

plotdata <- c()
for (tfID in tfIDs){
	matchIndexes <- which(tf.enh.motif.pairs.gsr[,5]==tfID)
	matchIndexes <- match(tf.enh.motif.pairs.gsr[matchIndexes,1],rownames(enhexpData))
	if(length(plotdata)==0){
		plotdata <- cbind(rep(tfID,length(matchIndexes)),enhexpData[matchIndexes,1])
	}else{
		plotdata <- rbind(plotdata,cbind(rep(tfID,length(matchIndexes)),enhexpData[matchIndexes,1]))
	}
}

df <- as.data.frame(plotdata)
colnames(df) <- c("tfname","exprlevel")
df$tfname <- factor(plotdata[,1],levels=c(tfIDs))
df$exprlevel <- as.numeric(plotdata[,2])

library(ggplot2)
library(ggbeeswarm)
library(RColorBrewer)
q4 = brewer.pal(10,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TFtop10_enhancer_expression.pdf",width=5,height=4)
p <- ggplot(data=df, aes(x=tfname,y=exprlevel)) + geom_quasirandom(aes(color=tfname),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", q4)) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=median,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()

tf.enh.motif.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
tf.enh.motif.pairs.gsr <- tf.enh.motif.pairs.gsr[grep("E2C|L2C",tf.enh.motif.pairs.gsr[,4]),]
tfIDs <- unique(tf.enh.motif.pairs.gsr[,5])

mapInfo <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_XW_clean_td_0.01EPM.txt",header=TRUE,row.names=1,stringsAsFactors=FALSE)
enhexpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/XWData/RNAseqData_XW/deepTools/enhancer_TPM.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
rownames(enhexpData) <- rownames(mapInfo)

medianVal <- c()
for (tfID in tfIDs){
	matchIndexes <- which(tf.enh.motif.pairs.gsr[,5]==tfID)
	matchIndexes <- match(tf.enh.motif.pairs.gsr[matchIndexes,1],rownames(enhexpData))
	medianVal <- c(medianVal,median(enhexpData[matchIndexes,1]))
}
names(medianVal) <- tfIDs

medianVal <- sort(medianVal,decreasing=TRUE)
tfIDs <- names(medianVal)[1:10]

plotdata <- c()
for (tfID in tfIDs){
	matchIndexes <- which(tf.enh.motif.pairs.gsr[,5]==tfID)
	matchIndexes <- match(tf.enh.motif.pairs.gsr[matchIndexes,1],rownames(enhexpData))
	if(length(plotdata)==0){
		plotdata <- cbind(rep(tfID,length(matchIndexes)),enhexpData[matchIndexes,1])
	}else{
		plotdata <- rbind(plotdata,cbind(rep(tfID,length(matchIndexes)),enhexpData[matchIndexes,1]))
	}
}

df <- as.data.frame(plotdata)
colnames(df) <- c("tfname","exprlevel")
df$tfname <- factor(plotdata[,1],levels=c(tfIDs[1:6],tfIDs[8:10],tfIDs[7]))
df$exprlevel <- as.numeric(plotdata[,2])

library(ggplot2)
library(ggbeeswarm)
library(RColorBrewer)
q4 = brewer.pal(10,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TFtop10_enhancer_expression.pdf",width=5,height=4)
p <- ggplot(data=df, aes(x=tfname,y=exprlevel)) + geom_quasirandom(aes(color=tfname),method="frowney",width=0.3,size=1) + scale_color_manual(values = c("#2B5CD8", q4)) + geom_boxplot(width=0.05,outlier.shape=NA,color="grey",fill="white",linetype=2) + stat_summary(fun.y=median,geom="point",shape=20,size=10,alpha=0.7,color="#8B814C")
p <- p + xlab("") + ylab("TPM") + ggtitle("") + theme_classic() + ylim(0,2)
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()
