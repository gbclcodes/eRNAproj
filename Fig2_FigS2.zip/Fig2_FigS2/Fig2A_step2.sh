nohup samtools merge Dux.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPSRAData/bowtie2file/SRR5297327/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPSRAData/bowtie2file/SRR5297328/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPSRAData/bowtie2file/SRR5297329/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPSRAData/bowtie2file/SRR5297330/accepted_hits.sorted.unique.bam &
nohup samtools index Dux.sorted.unique.bam &

bamCompare -b1 Dux.sorted.unique.bam -b2 /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeDuxChIPSRAData/bowtie2file/SRR5297331/accepted_hits.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --scaleFactorsMethod None --normalizeUsing BPM --numberOfProcessors 2 -o Dux.bw

nohup samtools merge Zscan4.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487458/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487460/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487465/accepted_hits.sorted.unique.bam &
nohup samtools index Zscan4.sorted.unique.bam &

nohup samtools merge Input.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487459/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487461/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeZscan4ChIPSRAData/bowtie2file/SRR10487464/accepted_hits.sorted.unique.bam &
nohup samtools index Input.sorted.unique.bam &

nohup bamCompare -b1 Zscan4.sorted.unique.bam -b2 Input.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --scaleFactorsMethod None --normalizeUsing BPM --numberOfProcessors 2 --extendReads -o Zscan4.bw &

nohup bamCompare -b1 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713340/accepted_hits.sorted.unique.bam -b2 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713343/accepted_hits.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --scaleFactorsMethod None --normalizeUsing BPM --numberOfProcessors 2 -o Nanog.bw &

nohup bamCompare -b1 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713341/accepted_hits.sorted.unique.bam -b2 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713343/accepted_hits.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --scaleFactorsMethod None --normalizeUsing BPM --numberOfProcessors 2 -o Sox2.bw &

nohup bamCompare -b1 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713342/accepted_hits.sorted.unique.bam -b2 /storage/gbcl/yuhua/yuhua_projects/enhProj/ESNanogOct4Sox2ChIPSRAData/bowtie2file/SRR713343/accepted_hits.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --scaleFactorsMethod None --normalizeUsing BPM --numberOfProcessors 2 -o Oct4.bw &

nohup samtools merge ESC.CTCF.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/CTCFSRAData/bowtie2file/SRR15897145/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeSLChIPATACSRAData/bowtie2file/SRR15897145/accepted_hits.sorted.unique.bam &
nohup samtools index ESC.CTCF.sorted.unique.bam &
nohup bamCoverage -b ESC.CTCF.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --normalizeUsing BPM --numberOfProcessors 2 -o ESC_CTCF.bw

nohup samtools merge 2CLC.CTCF.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/CTCFSRAData/bowtie2file/SRR15897149/accepted_hits.sorted.unique.bam /storage/gbcl/yuhua/yuhua_projects/enhProj/2ClikeSLChIPATACSRAData/bowtie2file/SRR15897151/accepted_hits.sorted.unique.bam &
nohup samtools index 2CLC.CTCF.sorted.unique.bam &
nohup bamCoverage -b 2CLC.CTCF.sorted.unique.bam -of bigwig --binSize 10 --ignoreDuplicates --normalizeUsing BPM --numberOfProcessors 2 -o 2CLC_CTCF.bw &