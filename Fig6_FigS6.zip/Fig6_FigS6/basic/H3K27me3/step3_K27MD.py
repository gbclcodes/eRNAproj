#!/usr/bin/env python


import os
import shutil
import glob

def mkdir_p(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)
    
# Make top level directories
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27me3_MD")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/result")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/metrics")
mkdir_p("/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/prep")


job_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3_MD"
data_directory = "/storage/gbcl/qiaolu/EpiData/H3K27me3_SNP"

os.chdir(job_directory)

names = ["K27_SRR3208749", "K27_SRR3208750", "K27_SRR3208751", "K27_SRR3208756", "K27_SRR3208757", "K27_SRR3208758", "K27_SRR3208763",
"K27_SRR3208764", "K27_SRR3208765", "K27_SRR3208769", "K27_SRR3208770", "K27_SRR3208771", "K27_SRR3208776", "K27_SRR3208777", "K27_SRR3208781",
"K27_SRR3208782", "K27_SRR3208786", "K27_SRR3208787", "K27_SRR5479602", "K27_SRR5479603", "K27_SRR5479604", "K27_SRR5479631", 
"K27_SRR5479632", "K27_SRR5479639", "K27_SRR5479640", "K27_SRR5479641"]

job = ""

for file in names:
    job += "samtools sort %s/%s/%s_mapping.genome1.bam > %s.genome1.sorted.bam\n" % (data_directory, file, file, file)
    job += "samtools index %s.genome1.sorted.bam\n" % file
    job += "java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=%s.genome1.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/result/%s.genome1.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/metrics/%s.genome1.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n" % (file, file, file)
    job += "samtools sort %s/%s/%s_mapping.genome2.bam > %s.genome2.sorted.bam\n" % (data_directory, file, file, file)
    job += "samtools index %s.genome2.sorted.bam\n" % file
    job += "java -Xmx15g -jar /storage/gbcl/qiaolu/Packages/picard.jar MarkDuplicates I=%s.genome2.sorted.bam O=/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/result/%s.genome2.sorted.unique.bam METRICS_FILE=/storage/gbcl/qiaolu/EpiData/H3K27me3_MD/metrics/%s.genome2.sorted.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n" % (file, file, file)

with open("MD_K27.bash", "w") as fh:
    fh.writelines("#!/bin/bash\n")
    fh.writelines("#SBATCH -p amd-ep2\n")
    fh.writelines("#SBATCH -q normal\n")
    fh.writelines("#SBATCH -J MD_K27\n")
    fh.writelines("#SBATCH -c 1\n")
    fh.writelines("#SBATCH --mem 200G\n")
    fh.writelines("#SBATCH -o /storage/gbcl/qiaolu/EpiData/H3K27me3_MD/MD_K27.log\n")
    fh.writelines("#SBATCH -e /storage/gbcl/qiaolu/EpiData/H3K27me3_MD/MD_K27.err\n")
    fh.writelines("cd /storage/gbcl/qiaolu/EpiData/H3K27me3_MD\n")
    fh.writelines("module load samtools/1.14\n")
    fh.writelines(job)







