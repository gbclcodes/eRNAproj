#!/bin/bash
  
#SBATCH -p amd-ep2                      
#SBATCH -q normal
#SBATCH -J DBA_6NJ                          
#SBATCH -c 1
#SBATCH --mem 50G                                      
#SBATCH -o /storage/gbcl/qiaolu/EpiData/DBA_6NJ/index.log
#SBATCH -e /storage/gbcl/qiaolu/EpiData/DBA_6NJ/index.err

cd /storage/gbcl/qiaolu/EpiData/DBA_6NJ/DBA_2J_C57BL_6NJ_dual_hybrid.based_on_GRCm38_N-masked
cat chr*.fa > DBA_6NJ.fa


cd /storage/gbcl/qiaolu/EpiData/ATAC_mapping/mapping

module load bowtie/2.4.2

bowtie2-build /storage/gbcl/qiaolu/EpiData/DBA_6NJ/DBA_2J_C57BL_6NJ_dual_hybrid.based_on_GRCm38_N-masked/DBA_6NJ.fa DBA_6NJ