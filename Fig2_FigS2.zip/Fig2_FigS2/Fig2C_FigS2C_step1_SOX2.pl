#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$indexdir,$hisat2dir,$picarddir,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"indexdir=s" => \$indexdir,
	"hisat2dir=s" => \$hisat2dir,
	"picarddir=s" => \$picarddir,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*_1.fastq.gz"`;
print join("\n",@samples)."\n";
foreach my $sample (@samples){
	chomp $sample;
	$sample =~ /.*\/(.*)\_1.fastq.gz/;
	my $sample_id = $1;
    
	if(!-e "$outputdir/$hisat2dir/$sample_id"){
		mkpath("$outputdir/$hisat2dir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$hisat2dir/$sample_id failed:\n$@";
			exit(1);
		}
	}
    
	open(SH,">$outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh") or die "$!\n";
	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
        if(-e "$inputdir/$sample_id\_2.fastq.gz"){
            print SH "hisat2 -x $indexdir -p $threads --dta --rg-id $sample_id --rg SM:$sample_id -1 $inputdir/$sample_id\_1.fastq.gz -2 $inputdir/$sample_id\_2.fastq.gz --summary-file $outputdir/$hisat2dir/$sample_id/mapping_summary.txt -S $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
            
        }else{
            print SH "hisat2 -x $indexdir -p $threads --dta --rg-id $sample_id --rg SM:$sample_id -U $inputdir/$sample_id\_1.fastq.gz --summary-file $outputdir/$hisat2dir/$sample_id/mapping_summary.txt -S $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
        }
	}
	
	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "samtools sort -@ $threads -o $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
	}

    if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "java -Xmx15g -jar $picarddir/picard.jar MarkDuplicates I=$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam O=$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam METRICS_FILE=$outputdir/$hisat2dir/$sample_id/${sample_id}.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n";
		print SH "samtools view -bS $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam -o $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
        print SH "samtools index $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
		print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam\n";
		print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam\n";
        print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
		print SH "rm $inputdir/$sample_id/$sample_id*fastq\n";
	}
    if(!-e "$outputdir/$hisat2dir/$sample_id/${sample_id}.bw" || -z "$outputdir/$hisat2dir/$sample_id/${sample_id}.bw"){
		print SH "bamCoverage -b $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam -of bigwig --binSize 100 --ignoreDuplicates --normalizeUsing BPM --numberOfProcessors $threads -o $outputdir/$hisat2dir/$sample_id/${sample_id}.bw\n";
       
    }
    
    open OUT,">$outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $sample_id			
#SBATCH -c 4
#SBATCH --mem 100G
#SBATCH -o $outputdir/$hisat2dir/$sample_id/%j.log
#SBATCH -e $outputdir/$hisat2dir/$sample_id/%j.err

date
source ~/.bashrc
module load hisat/2.2.1
module load samtools/1.14
sh $outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh
date
EOF
	close OUT;
	my $sb = `sbatch $outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl SOX2_sample_mapping_pipeline.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/SOX2KORNAseqData --outputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/SOX2KORNAseqData --indexdir /storage/gbcl/yuhua/yuhua_projects/enhProj/genomeanno/mousehisat2Index/GRCm38 --picarddir /storage/gbcl/yuhua/yuhua_projects/enhProj/software/picard-2.18.2 --hisat2dir hisat2file --threads 2

