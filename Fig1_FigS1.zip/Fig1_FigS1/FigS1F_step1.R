library(foreach)
library(doParallel)

expValNormalization <- function(expVec){
	expVec <- log2(expVec+1)/sum(log2(expVec+1))
	return(expVec)
}

JSscoreCal <- function(probVec,stdMat){
	HscoreVec <- c()
	probVec[which(probVec < 2e-100)] <- runif(length(which(probVec < 2e-100)),min=1e-100,max=2e-100)
	for(colIndex in seq(1,ncol(stdMat))){
		meanProb <- (probVec+stdMat[,colIndex])/2
		meanH <- -sum(meanProb*log2(meanProb))
		pop1H <- -sum(probVec*log2(probVec))
		pop2H <- -sum(stdMat[,colIndex]*log2(stdMat[,colIndex]))
		HscoreVec <- c(HscoreVec,(1-sqrt(meanH-(pop1H+pop2H)/2)))
	}
	JSscore <- max(HscoreVec)
	return(JSscore)
}

cl <- makeCluster(20)
registerDoParallel(cl)
enhExpDataMap <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_GSR_clean_td_0.01EPM.txt",sep=" ",header=TRUE,row.names=1,stringsAsFactors=FALSE)
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/enhancer_TPM.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
rownames(enhExpData) <- rownames(enhExpDataMap)
geneExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GENEData/stringtiefile_GSR/gene_TPM.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(geneExpData) <- geneExpData[,1]
geneInfo <- read.table(file="/media/yuhua/yuhua_projects/genomeanno/gencode.vM17.genetype.tab",sep="\t",header=FALSE,stringsAsFactors=FALSE)

tissueNames <- c("MIIOocyte","X2cell","X4cell","X8cell","morula","ICM","TE","EpiE65","ExeE65")
matchIndexes <- match(tissueNames,colnames(enhExpData))
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
enhExpData <- enhExpData[,matchIndexes]

bgMatrix <- matrix(0,nrow=length(tissueNames),ncol=length(tissueNames))
cat("The tissue number:",length(tissueNames),"\n")
for(tissueIter in seq(1,length(tissueNames))){
	randomNum <- runif(length(tissueNames),min=1e-100,max=2e-100)
	bgMatrix[tissueIter,tissueIter] <- 1
	bgMatrix[,tissueIter] <- bgMatrix[,tissueIter] + randomNum
}

# JS score calculation
enhExpDataNorm <- t(apply(enhExpData,1,expValNormalization))
enhJSscoreVec <- foreach(iter=1:nrow(enhExpDataNorm),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% JSscoreCal(enhExpDataNorm[iter,],bgMatrix)
names(enhJSscoreVec) <- rownames(enhExpDataNorm)
enhnonaIndexes <- which(!is.na(enhJSscoreVec))
enhJSscoreVec <- enhJSscoreVec[enhnonaIndexes]
write.table(enhJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/ENHData/enhancer_stage_specific_scores.txt",row.names=T,col.names=F,quote=F)

matchIndexes <- match(tissueNames,colnames(geneExpData))
matchIndexes <- matchIndexes[which(!is.na(matchIndexes))]
geneExpData <- geneExpData[,matchIndexes]

geneExpDataNorm <- t(apply(geneExpData,1,expValNormalization))
geneJSscoreVec <- foreach(iter=1:nrow(geneExpDataNorm),.combine=c,.multicombine=TRUE,.verbose=TRUE) %dopar% JSscoreCal(geneExpDataNorm[iter,],bgMatrix)
names(geneJSscoreVec) <- rownames(geneExpDataNorm)
genenonaIndexes <- which(!is.na(geneJSscoreVec))
geneJSscoreVec <- geneJSscoreVec[genenonaIndexes]

pcmatchIndexes <- grep('protein_coding',geneInfo[,2])
lncRNAmatchIndexes <- grep('processed_transcript|lincRNA|3prime_overlapping_ncrna|antisense|non_coding|sense_intronic|sense_overlapping|TEC|known_ncrna|macro_lncRNA|bidirectional_promoter_lncrna',geneInfo[,2])

pcmatchIndexes <- match(geneInfo[pcmatchIndexes,1],names(geneJSscoreVec))
pcmatchIndexes <- pcmatchIndexes[which(!is.na(pcmatchIndexes))]
pcJSscoreVec <- geneJSscoreVec[pcmatchIndexes]
write.table(pcJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/mRNA_stage_specific_scores.txt",row.names=T,col.names=F,quote=F)

lncRNAmatchIndexes <- match(geneInfo[lncRNAmatchIndexes,1],names(geneJSscoreVec))
lncRNAmatchIndexes <- lncRNAmatchIndexes[which(!is.na(lncRNAmatchIndexes))]
lncRNAJSscoreVec <- geneJSscoreVec[lncRNAmatchIndexes]
write.table(lncRNAJSscoreVec,file="/media/yuhua/yuhua_projects/enhProj/GENEData/lncRNA_stage_specific_scores.txt",row.names=T,col.names=F,quote=F)

exp_des_value <- as.numeric(c(enhJSscoreVec,lncRNAJSscoreVec,pcJSscoreVec))
exp_des_group <- rep(c("eRNA","lncRNA","mRNA"),c(length(enhJSscoreVec),length(lncRNAJSscoreVec),length(pcJSscoreVec)))
exp_des <- data.frame(cbind(exp_des_group,exp_des_value))
colnames(exp_des) <- c("Label","value")
exp_des$Label=factor(exp_des$Label,levels=c("eRNA","lncRNA","mRNA"))
exp_des$value <- as.numeric(exp_des_value)
exp_des <- exp_des[which(exp_des$value < 1),]


library(tidyverse)
library(ggplot2)
library(ggbeeswarm)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
df_means <- exp_des %>% group_by(Label) %>% summarise(value=mean(value))

pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/stage_specific_beeswarm_boxplot_ggplot2_GSR.pdf",width=10,height=10)
p <- ggplot(data=exp_des, aes(x=Label,y=value)) + geom_quasirandom(aes(color=Label),method="frowney",width=0.3,size=1e-20) + scale_color_manual(values=q4[c(1,2,4)]) + geom_boxplot(width=0.05,outlier.shape=NA,color="black",fill="white",linetype=2) + stat_summary(fun.y=mean, geom="point", shape=20, size=10,  alpha=0.7, color="black")
p <- p + xlab("") + ylab("JS score") + ggtitle("") + theme_classic()
p <- p + theme(panel.grid.major=element_blank(), panel.grid.minor = element_blank(),panel.background=element_blank(), rect=element_rect(linetype=1), axis.line=element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x=element_text(vjust = 0.6, angle = 45))
print(p)
dev.off()
