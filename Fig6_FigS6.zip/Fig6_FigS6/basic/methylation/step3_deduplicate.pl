#!/usr/bin/perl -w
use strict;
use Getopt::Long;

my ($inputdir,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"help!" => \$help,
);

my @samples = `find $inputdir -name "*pe_sorted.bam"`;
print join("\n",@samples)."\n";

foreach my $sample_in (@samples){
	chomp $sample_in;
	$sample_in =~ /.*\/(.*)\/.*sorted\.bam/;
	my $sample_id = $1;
	open(SH,">$inputdir/$sample_id/${sample_id}_deduplicate.sh") or die "$!\n";
    print SH "/storage/gbcl/qiaolu/Bismark-0.23.0/deduplicate_bismark -p --output_dir $inputdir/$sample_id --outfile ${sample_id}_1_bismark_bt2_pe_sorted $sample_in\n";
	close SH;
    
    open OUT,">$inputdir/$sample_id/submit_${sample_id}_deduplicate.sh";
    print OUT <<EOF;
#!/bin/bash
#SBATCH -p amd-ep2
#SBATCH -q normal
#SBATCH -J $sample_id
#SBATCH -c 1
#SBATCH --mem 60G
#SBATCH -o $inputdir/$sample_id/deduplicate.log
#SBATCH -e $inputdir/$sample_id/deduplicate.err

date
source ~/.bashrc
sh $inputdir/$sample_id/${sample_id}_deduplicate.sh
date
EOF
	close OUT;
	
	my $sb = `sbatch $inputdir/$sample_id/submit_${sample_id}_deduplicate.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}

# perl step3_deduplicate.pl --inputdir /storage/gbcl/yuhua/yuhua_projects/enhProj/DNAMETHData/mapping