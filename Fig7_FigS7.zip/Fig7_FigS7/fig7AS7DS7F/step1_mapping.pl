#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use File::Path;

my ($inputdir,$outputdir,$hisat2indexdir,$hisat2dir,$picarddir,$stringtiedir,$gfffile,$threads,$help);

GetOptions(
	"inputdir|i=s" => \$inputdir,
	"outputdir|o=s" => \$outputdir,
	"hisat2indexdir=s" => \$hisat2indexdir,
	"hisat2dir=s" => \$hisat2dir,
	"picarddir=s" => \$picarddir,
	"stringtiedir=s" => \$stringtiedir,
	"gfffile|gff=s" => \$gfffile,
	"threads=s" => \$threads,
	"help!" => \$help,
);

my @sample_p1s = `find $inputdir -name "*_1.clean.fq.gz"`;
print join("\n",@sample_p1s)."\n";
foreach my $sample_p1 (@sample_p1s){
	chomp $sample_p1;
	$sample_p1 =~ /.*\/(.*)\/.*.fq.gz/;
	my $sample_id = $1;
	my $sample_p2 = $sample_p1;
	$sample_p2 =~ s/_1.clean.fq.gz/_2.clean.fq.gz/;
	
	if(!-e "$outputdir/$hisat2dir/$sample_id"){
		mkpath("$outputdir/$hisat2dir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$hisat2dir/$sample_id failed:\n$@";
			exit(1);
		}
	}
	
    if(!-e "$outputdir/$stringtiedir/$sample_id"){
		mkpath("$outputdir/$stringtiedir/$sample_id",0644);
		if($@){
			print "Make path $outputdir/$stringtiedir/$sample_id failed:\n$@";
			exit(1);
		}
	}
	
	open(SH,">$outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh") or die "$!\n";
	
	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
	print SH "hisat2 -x $hisat2indexdir -p $threads --dta --rg-id $sample_id --rg SM:$sample_id -1 $sample_p1 -2 $sample_p2 --summary-file $outputdir/$hisat2dir/$sample_id/mapping_summary.txt -S $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
	}
	
	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "samtools sort -@ $threads -o $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
	}

	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "java -Xmx15g -jar $picarddir/picard.jar MarkDuplicates I=$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam O=$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam METRICS_FILE=$outputdir/$hisat2dir/$sample_id/${sample_id}.metricsFile VALIDATION_STRINGENCY=LENIENT REMOVE_DUPLICATES=true ASSUME_SORT_ORDER=coordinate\n";
	}
	if(!-e "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam" || -z "$outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam"){
		print SH "samtools view -bS $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam -o $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
		print SH "samtools view -bS $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam -o $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.bam\n";
		print SH "samtools index $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.bam\n";
		print SH "samtools index $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.bam\n";
		print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.unique.sam\n";
		print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sorted.sam\n";
		print SH "rm $outputdir/$hisat2dir/$sample_id/accepted_hits.sam\n";
	}
    
    open OUT,">$outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh";
    print OUT <<EOF;
#!/bin/bash

#SBATCH -p intel-e5,amd-ep2			
#SBATCH -q normal				
#SBATCH -J $sample_id			
#SBATCH -c 4
#SBATCH --mem 20G
#SBATCH -o $outputdir/$hisat2dir/$sample_id/%j.log
#SBATCH -e $outputdir/$hisat2dir/$sample_id/%j.err

date
source ~/.bashrc
module load hisat/2.2.1
module load samtools/1.14
module load stringtie/2.1.5
sh $outputdir/$hisat2dir/$sample_id/${sample_id}_mapping.sh
date
EOF
	close OUT;
	my $sb = `sbatch $outputdir/$hisat2dir/$sample_id/submit_${sample_id}_mapping.sh`;
	if($sb ne ""){
		print "$sb\n";
	}else{
		print "$sample_id is not successfully submitted\n";
	}
}
