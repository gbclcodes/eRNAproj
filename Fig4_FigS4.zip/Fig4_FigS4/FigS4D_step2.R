library(ggplot2)
library(RColorBrewer)

NANOGData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
NANOGData <- NANOGData[,3:ncol(NANOGData)]
NANOGSEData <- as.numeric(NANOGData[5,])
NANOGTEData <- as.numeric(NANOGData[6,])

yvalues <- as.numeric(c(NANOGSEData,NANOGTEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/NANOG_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

POU5F1Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
POU5F1Data <- POU5F1Data[,3:ncol(POU5F1Data)]
POU5F1SEData <- as.numeric(POU5F1Data[11,])
POU5F1TEData <- as.numeric(POU5F1Data[12,])

yvalues <- as.numeric(c(POU5F1SEData,POU5F1TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/POU5F1_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()

SOX2Data <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/SETE_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
SOX2Data <- SOX2Data[,3:ncol(SOX2Data)]
SOX2SEData <- as.numeric(SOX2Data[17,])
SOX2TEData <- as.numeric(SOX2Data[18,])

yvalues <- as.numeric(c(SOX2SEData,SOX2TEData))
locations <- rep(paste("loc",seq(1,300),sep=""),times=2)
grouplabels <- rep(c("SE","TE"),each=300)

plotdata <- data.frame(cbind(locations,yvalues,grouplabels))
colnames(plotdata) <- c("Label","Value","Group")
plotdata$Label <- factor(locations,levels=paste("loc",seq(1,300),sep=""))
plotdata$Value <- as.numeric(plotdata$Value)
plotdata$Group <- factor(grouplabels,levels=c("SE","TE"))

pdf(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/TFData/bowtie2file/TFPOL/SOX2_scaled_profile_fit.pdf",width=11,height=10)
p <- ggplot(plotdata,aes(x=Label,y=Value,group=grouplabels,color=grouplabels)) + geom_smooth(method="loess",span=0.6) + scale_color_manual(values=q4[c(1,2)])
p <- p + xlab("") + ylab("")
p <- p + theme(axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=4,vjust = 0.6, angle = 45),axis.text.y=element_text(size=4))
p <- p + theme(panel.background=element_rect(fill="white",color="black"), panel.grid=element_line(color="black",size=2), panel.grid.major=element_blank(),panel.grid.minor=element_blank())
p <- p + theme(legend.title=element_blank())
print(p)
dev.off()
