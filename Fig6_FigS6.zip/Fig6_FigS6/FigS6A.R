LenPos <- function(x){
	return(length(which(x > 1)))
}

LenNeg <- function(x){
	return(length(which(x < -1)))
}

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBAData),rownames(C57BLData))
C57BLData <- C57BLData[matchIndexes[which(!is.na(matchIndexes))],]
DBAData <- DBAData[which(!is.na(matchIndexes)),]
RatioData <- log2((C57BLData + 1)/(DBAData + 1))
lenVecPos <- apply(RatioData,1,LenPos)
lenVecNeg <- apply(RatioData,1,LenNeg)
C57BLData <- C57BLData[which(lenVecPos >= 3 | lenVecNeg >= 3),]
DBAData <- DBAData[which(lenVecPos >= 3 | lenVecNeg >= 3),]

AllData <- C57BLData + DBAData
maxVec <- apply(AllData,1,max)
C57BLData_XW <- rowSums(C57BLData[which(maxVec > 8),])
DBAData_XW <- rowSums(DBAData[which(maxVec > 8),])
RatioData_XW <- log2((C57BLData_XW + 1)/(DBAData_XW + 1))
C57BLData_XW <- C57BLData_XW[which(abs(RatioData_XW) > 1)]
DBAData_XW <- DBAData_XW[which(abs(RatioData_XW) > 1)]
RatioData_XW <- RatioData_XW[which(abs(RatioData_XW) > 1)]
RatioData_XW <- RatioData_XW[1:(length(RatioData_XW)-1)]

C57BLData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_C57BL_enhancer.csv",header=TRUE,row.names=1)
DBAData <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/RNAseq_DBA_enhancer.csv",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBAData),rownames(C57BLData))
C57BLData <- C57BLData[matchIndexes[which(!is.na(matchIndexes))],]
DBAData <- DBAData[which(!is.na(matchIndexes)),]
C57BLData <- rowSums(C57BLData)
DBAData <- rowSums(DBAData)
matchIndexes <- which(C57BLData > 0 | DBAData > 0)

C57BLData <- C57BLData[matchIndexes]
DBAData <- DBAData[matchIndexes]
AllData <- C57BLData + DBAData
RatioData <- log2((C57BLData + 1)/(DBAData + 1))
ClassData <- rep("Both",length(AllData))
matchIndexes <- match(names(RatioData_XW[which(RatioData_XW > 0)]),names(AllData))
Enh.M <- names(RatioData_XW[which(RatioData_XW > 0)])
ClassData[matchIndexes] <- "Maternal"
matchIndexes <- match(names(RatioData_XW[which(RatioData_XW < 0)]),names(AllData))
Enh.P <- names(RatioData_XW[which(RatioData_XW < 0)])
ClassData[matchIndexes] <- "Paternal"
resdata <- as.data.frame(cbind(AllData,RatioData,ClassData))
colnames(resdata) <- c("Num","Ratio","Class")
rownames(resdata) <- names(AllData)
resdata <- resdata[grep("Enh",rownames(resdata)),]
resdata$Num <- as.numeric(resdata$Num)
resdata$Ratio <- as.numeric(resdata$Ratio)
resdata$Class <- factor(resdata$Class,levels=c("Maternal","Both","Paternal"))
matchIndexes <- match(names(RatioData_XW),rownames(resdata))
for_label <- resdata[matchIndexes,]
for_label$gene_name <- rownames(for_label)

library(ggplot2)
library(ggrepel)
library(dplyr)
pdf("/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/NumVSRatio.pdf",width=8,height=6)
p <- ggplot(resdata,aes(x=Ratio,y=Num)) + geom_point(alpha=0.4,size=6,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red")) + geom_vline(xintercept=c(-1,1),lty=4,col="black",lwd=0.8) + geom_hline(yintercept = 1,lty=4,col="black",lwd=0.8)
p <- p + geom_point(size = 3, shape = 1, data = for_label)
p <- p + xlab(expression(log[2]("Fold Change"))) + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + scale_y_continuous(limits = c(0,700))
p <- p + scale_x_continuous(limits = c(-8,8))
p <- p + annotate(geom="text", x=-7, y=600, label=paste("Paternal:",length(which(resdata$Class=="Paternal")),sep=""), color="blue")
p <- p + annotate(geom="text", x=7, y=600, label=paste("Maternal:",length(which(resdata$Class=="Maternal")),sep=""), color="red")
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

write.table(Enh.M,file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/EnhM.txt",row.names=FALSE,col.names=FALSE,quote=FALSE)
write.table(Enh.P,file="/media/yuhua/yuhua_projects/enhProj/Fig5Data/Transcriptome/PolyACapturingRNAseeqData/EnhP.txt",row.names=FALSE,col.names=FALSE,quote=FALSE)


LenPos <- function(x){
	return(length(which(x > 1)))
}

LenNeg <- function(x){
	return(length(which(x < -1)))
}

C57BLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",sep=" ",header=TRUE,row.names=1)
DBAData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_p.txt",sep=" ",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBAData),rownames(C57BLData))
C57BLData <- C57BLData[matchIndexes[which(!is.na(matchIndexes))],]
DBAData <- DBAData[which(!is.na(matchIndexes)),]
RatioData <- log2((C57BLData + 1)/(DBAData + 1))
lenVecPos <- apply(RatioData,1,LenPos)
lenVecNeg <- apply(RatioData,1,LenNeg)
C57BLData <- C57BLData[which(lenVecPos >= 3 | lenVecNeg >= 3),]
DBAData <- DBAData[which(lenVecPos >= 3 | lenVecNeg >= 3),]

AllData <- C57BLData + DBAData
maxVec <- apply(AllData,1,max)
C57BLData_XW <- rowSums(C57BLData[which(maxVec > 8),])
DBAData_XW <- rowSums(DBAData[which(maxVec > 8),])
RatioData_XW <- log2((C57BLData_XW + 1)/(DBAData_XW + 1))
C57BLData_XW <- C57BLData_XW[which(abs(RatioData_XW) > 1)]
DBAData_XW <- DBAData_XW[which(abs(RatioData_XW) > 1)]
RatioData_XW <- RatioData_XW[which(abs(RatioData_XW) > 1)]
RatioData_XW <- RatioData_XW[1:(length(RatioData_XW)-1)]

C57BLData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_m.txt",sep=" ",header=TRUE,row.names=1)
DBAData <- read.table(file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/enhancer_counts_p.txt",sep=" ",header=TRUE,row.names=1)
matchIndexes <- match(rownames(DBAData),rownames(C57BLData))
C57BLData <- C57BLData[matchIndexes[which(!is.na(matchIndexes))],]
DBAData <- DBAData[which(!is.na(matchIndexes)),]
C57BLData <- rowSums(C57BLData)
DBAData <- rowSums(DBAData)
matchIndexes <- which(C57BLData > 0 | DBAData > 0)

C57BLData <- C57BLData[matchIndexes]
DBAData <- DBAData[matchIndexes]
AllData <- C57BLData + DBAData
RatioData <- log2((C57BLData + 1)/(DBAData + 1))
ClassData <- rep("Both",length(AllData))
matchIndexes <- match(names(RatioData_XW[which(RatioData_XW > 0)]),names(AllData))
Enh.M <- names(RatioData_XW[which(RatioData_XW > 0)])
ClassData[matchIndexes] <- "Maternal"
matchIndexes <- match(names(RatioData_XW[which(RatioData_XW < 0)]),names(AllData))
Enh.P <- names(RatioData_XW[which(RatioData_XW < 0)])
ClassData[matchIndexes] <- "Paternal"
resdata <- as.data.frame(cbind(AllData,RatioData,ClassData))
colnames(resdata) <- c("Num","Ratio","Class")
rownames(resdata) <- names(AllData)
resdata <- resdata[grep("Enh",rownames(resdata)),]
resdata$Num <- as.numeric(resdata$Num)
resdata$Ratio <- as.numeric(resdata$Ratio)
resdata$Class <- factor(resdata$Class,levels=c("Maternal","Both","Paternal"))
matchIndexes <- match(names(RatioData_XW),rownames(resdata))
for_label <- resdata[matchIndexes,]
for_label$gene_name <- rownames(for_label)

library(ggplot2)
library(ggrepel)
library(dplyr)
pdf("/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/NumVSRatio.pdf",width=8,height=6)
p <- ggplot(resdata,aes(x=Ratio,y=Num)) + geom_point(alpha=0.4,size=6,aes(color=Class)) + scale_color_manual(values=c("blue","grey","red")) + geom_vline(xintercept=c(-1,1),lty=4,col="black",lwd=0.8) + geom_hline(yintercept = 1,lty=4,col="black",lwd=0.8)
p <- p + geom_point(size = 3, shape = 1, data = for_label)
p <- p + xlab(expression(log[2]("Fold Change"))) + ylab("Number of Reads")
p <- p + theme(legend.title=element_blank())
p <- p + scale_y_continuous(limits = c(0,1500))
p <- p + scale_x_continuous(limits = c(-8,8))
p <- p + annotate(geom="text", x=-7, y=1400, label=paste("Paternal:",length(which(resdata$Class=="Paternal")),sep=""), color="blue")
p <- p + annotate(geom="text", x=7, y=1400, label=paste("Maternal:",length(which(resdata$Class=="Maternal")),sep=""), color="red")
p <- p + theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(),axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11))
print(p)
dev.off()

write.table(Enh.M,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/SuperM.txt",row.names=FALSE,col.names=FALSE,quote=FALSE)
write.table(Enh.M,file="/storage/gbcl/yuhua/yuhua_projects/enhProj/SpAllelicData/Transcriptome/XW/htseqcountfile/SuperP.txt",row.names=FALSE,col.names=FALSE,quote=FALSE)