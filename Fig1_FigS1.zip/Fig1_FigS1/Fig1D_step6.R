signalData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/lncRNA_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
plotData <- signalData[,2:ncol(signalData)]
plotdata <- data.frame(x=c(rep(seq(1,ncol(plotData)),times=nrow(plotData))),y=as.numeric(c(plotData[1,],plotData[2,],plotData[3,],plotData[4,],plotData[5,],plotData[6,],plotData[7,],plotData[8,],plotData[9,])),z=c(rep("2cell",ncol(plotData)),rep("4cell",ncol(plotData)),rep("8cell",ncol(plotData)),rep("EpiE65",ncol(plotData)),rep("ExeE65",ncol(plotData)),rep("ICM",ncol(plotData)),rep("MIIOocyte",ncol(plotData)),rep("morula",ncol(plotData)),rep("TE",ncol(plotData))))
plotdata$x <- as.numeric((plotdata$x))
plotdata$y <- as.numeric(plotdata$y)
plotdata$z <- factor(plotdata$z,levels=rev(c("MIIOocyte","2cell","4cell","8cell","morula","ICM","TE","EpiE65","ExeE65")))

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/lncRNA_scaled_profile.pdf")
p <- ggplot(plotdata, aes(x = x, y = y,color=z)) + geom_smooth(method="loess",span=0.3) + scale_color_manual(values = c(rev(wes_palette("Zissou1",8,type = "continuous")),"darkslateblue"))
p <- p + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
print(p)
dev.off()


signalData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/proteincoding_scaled_profile.tab",header=FALSE,stringsAsFactors=FALSE,skip=2)
plotData <- signalData[,2:ncol(signalData)]
plotdata <- data.frame(x=c(rep(seq(1,ncol(plotData)),times=nrow(plotData))),y=as.numeric(c(plotData[1,],plotData[2,],plotData[3,],plotData[4,],plotData[5,],plotData[6,],plotData[7,],plotData[8,],plotData[9,])),z=c(rep("2cell",ncol(plotData)),rep("4cell",ncol(plotData)),rep("8cell",ncol(plotData)),rep("EpiE65",ncol(plotData)),rep("ExeE65",ncol(plotData)),rep("ICM",ncol(plotData)),rep("MIIOocyte",ncol(plotData)),rep("morula",ncol(plotData)),rep("TE",ncol(plotData))))
plotdata$x <- as.numeric((plotdata$x))
plotdata$y <- as.numeric(plotdata$y)
plotdata$z <- factor(plotdata$z,levels=rev(c("MIIOocyte","2cell","4cell","8cell","morula","ICM","TE","EpiE65","ExeE65")))

library(ggplot2)
pdf("/media/yuhua/yuhua_projects/enhProj/GSRData/RNAseq_GSR/deepTools/proteincoding_scaled_profile.pdf")
p <- ggplot(plotdata, aes(x = x, y = y,color=z)) + geom_smooth(method="loess",span=0.3) + scale_color_manual(values = c(rev(wes_palette("Zissou1",8,type = "continuous")),"darkslateblue"))
p <- p + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))
print(p)
dev.off()
