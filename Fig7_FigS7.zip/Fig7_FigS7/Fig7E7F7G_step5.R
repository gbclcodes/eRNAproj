library(clusterProfiler)
library(org.Mm.eg.db)
library(enrichplot)

zgalist <- read.csv(file="/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/zgagenes.csv",header=TRUE,stringsAsFactors=FALSE)
zga_gmt <- read.gmt("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtie/ZGAgenes.gmt")
matchIndexes <- match(zgalist[1:100,2],zga_gmt[,2])
zga_gmt <- zga_gmt[matchIndexes,]
resdata <- read.csv("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/siENH_vs_siNC_2C.csv",header=TRUE,row.names=1,stringsAsFactors=FALSE)
maxVec <- apply(resdata[,seq(8,11)],1,max)
resdata <- resdata[which(maxVec > 0),]

matchIndexes <- match(zgalist[1:100,2],resdata[,1])
tarData <- resdata[matchIndexes[!is.na(matchIndexes)],]
write.csv(tarData,file="/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/ZGA_GSR.csv",row.names=TRUE,col.names=TRUE)

resdata <- resdata[order(resdata$stat,decreasing=TRUE),]
genenames <- resdata[,1]
genelist <- resdata$stat
names(genelist) <- genenames
gsea <- GSEA(genelist, TERM2GENE = zga_gmt, pvalueCutoff = 1,maxGSSize = 20000)

pdf("/media/yuhua/yuhua_projects/enhProj/InhouseRNAseqData/stringtienew/ZGA_GSEA_2C.pdf")
gseaplot2(gsea,1,title = "ZGA", color="red", base_size = 20, subplots = 1:2)
dev.off()
