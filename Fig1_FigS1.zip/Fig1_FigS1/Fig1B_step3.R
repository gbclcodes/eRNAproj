# Expr & ATAC
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
ATACData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW_ATAC/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(ATACData) <- ATACData[,1]
ATACData[,1] <- NULL
ATACMatchRowIndexes <- match(rownames(ATACData),rownames(enhExpData))
ATACMatchColIndexes <- match(colnames(enhExpData),colnames(ATACData))
enhExpData <- enhExpData[ATACMatchRowIndexes,]
ATACData <- ATACData[,ATACMatchColIndexes[which(!is.na(ATACMatchColIndexes))]]
ATACData <- ATACData[1:(nrow(ATACData)-5),]
enhExpData <- enhExpData[,which(!is.na(ATACMatchColIndexes))]
enhExpData <- enhExpData[1:(nrow(enhExpData)-5),]
colnames(ATACData) <- c("E2C","ICM","X2cell","X4cell","X8cell")

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(ATACData))){
	matchIndexes <- which(enhExpData[,i] > 0 | ATACData[,i] > 0)
	res <- cor.test(enhExpData[matchIndexes,i],ATACData[matchIndexes,i],method="pearson")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
statData_ATAC <- cbind(rep("ATAC",ncol(ATACData)),colnames(ATACData)[1:ncol(ATACData)],corvalues,pvalues)

# Expr & DNase
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
DNaseData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_DNase/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(DNaseData) <- DNaseData[,1]
DNaseData[,1] <- NULL
colnames(DNaseData) <- c("X2cell", "X4cell", "X8cell", "MIIOocyte", "morula")
DNaseMatchRowIndexes <- match(rownames(DNaseData),rownames(enhExpData))
DNaseMatchColIndexes <- match(colnames(enhExpData),colnames(DNaseData))
enhExpData <- enhExpData[DNaseMatchRowIndexes,]
DNaseData <- DNaseData[,DNaseMatchColIndexes[which(!is.na(DNaseMatchColIndexes))]]
DNaseData <- DNaseData[1:(nrow(DNaseData)-5),]
enhExpData <- enhExpData[,which(!is.na(DNaseMatchColIndexes))]
enhExpData <- enhExpData[1:(nrow(enhExpData)-5),]

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(DNaseData))){
	matchIndexes <- which(enhExpData[,i] > 3 | DNaseData[,i] > 3)
	res <- cor.test(enhExpData[,i],DNaseData[,i],method="spearman")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
statData_DNase <- cbind(rep("DNase",ncol(DNaseData)),colnames(DNaseData),corvalues,pvalues)

# Expr & H3K27ac
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
H3K27acData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW_H3K27ac/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(H3K27acData) <- H3K27acData[,1]
H3K27acData[,1] <- NULL
colnames(H3K27acData) <- c("L2C", "M8C", "MIIOocyte")
H3K27acMatchRowIndexes <- match(rownames(H3K27acData),rownames(enhExpData))
H3K27acMatchColIndexes <- match(colnames(enhExpData),colnames(H3K27acData))
enhExpData <- enhExpData[H3K27acMatchRowIndexes,]
H3K27acData <- H3K27acData[,H3K27acMatchColIndexes[which(!is.na(H3K27acMatchColIndexes))]]
H3K27acData <- H3K27acData[1:(nrow(H3K27acData)-5),]
enhExpData <- enhExpData[,which(!is.na(H3K27acMatchColIndexes))]
enhExpData <- enhExpData[1:(nrow(enhExpData)-5),]

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(H3K27acData))){
	matchIndexes <- which(enhExpData[,i] > 0 | H3K27acData[,i] > 0)
	res <- cor.test(enhExpData[matchIndexes,i],H3K27acData[matchIndexes,i],method="pearson")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
colnames(H3K27acData) <- c("X2cell", "X8cell", "MIIOocyte")
statData_H3K27ac <- cbind(rep("H3K27ac",ncol(H3K27acData)),colnames(H3K27acData),corvalues,pvalues)

# Expr & H3K9me3
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
H3K9me3Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K9me3/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(H3K9me3Data) <- H3K9me3Data[,1]
H3K9me3Data[,1] <- NULL
colnames(H3K9me3Data) <- colnames(enhExpData)
H3K9me3MatchRowIndexes <- match(rownames(H3K9me3Data),rownames(enhExpData))
enhExpData <- enhExpData[H3K9me3MatchRowIndexes,]
H3K9me3Data <- H3K9me3Data[1:(nrow(H3K9me3Data)-5),]
enhExpData <- enhExpData[1:(nrow(enhExpData)-5),]

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(H3K9me3Data))){
	matchIndexes <- which(enhExpData[,i] > 3 | H3K9me3Data[,i] > 3)
	res <- cor.test(enhExpData[matchIndexes,i],H3K9me3Data[matchIndexes,i],method="spearman")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
statData_H3K9me3 <- cbind(rep("H3K9me3",ncol(H3K9me3Data)),colnames(H3K9me3Data),corvalues,pvalues)

# Expr & H3K27me3
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
H3K27me3Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K27me3/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(H3K27me3Data) <- H3K27me3Data[,1]
H3K27me3Data[,1] <- NULL
colnames(H3K27me3Data) <- colnames(enhExpData)
H3K27me3MatchRowIndexes <- match(rownames(H3K27me3Data),rownames(enhExpData))
enhExpData <- enhExpData[H3K27me3MatchRowIndexes,]
H3K27me3Data <- H3K27me3Data[1:(nrow(H3K27me3Data)-5),]
enhExpData <- enhExpData[1:(nrow(enhExpData)-5),]

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(H3K27me3Data))){
	matchIndexes <- which(enhExpData[,i] > 3 | H3K9me3Data[,i] > 3)
	res <- cor.test(enhExpData[matchIndexes,i],H3K27me3Data[matchIndexes,i],method="spearman")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
statData_H3K27me3 <- cbind(rep("H3K27me3",ncol(H3K27me3Data)),colnames(H3K27me3Data),corvalues,pvalues)

# Expr & DNA methylation
enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
rownames(enhExpData) <- enhExpData[,1]
enhExpData[,1] <- NULL
H3K9me3Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K9me3/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
DNAMethData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR/deepTools/enhancer_DNAMeth_Signal.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
rownames(DNAMethData) <- H3K9me3Data[1:(nrow(H3K9me3Data)-5),1]
colnames(DNAMethData) <- c("E2C","EpiE65","ExeE65","ICM","X2cell","X4cell","X8cell","morula","TE","Zygote") 
DNAMethMatchRowIndexes <- match(rownames(DNAMethData),rownames(enhExpData))
DNAMethMatchColIndexes <- match(colnames(enhExpData),colnames(DNAMethData))
enhExpData <- enhExpData[DNAMethMatchRowIndexes,]
DNAMethData <- DNAMethData[,DNAMethMatchColIndexes[which(!is.na(DNAMethMatchColIndexes))]]
enhExpData <- enhExpData[,which(!is.na(DNAMethMatchColIndexes))]

corvalues <- c()
pvalues <- c()
for (i in seq(1,ncol(DNAMethData))){
	matchIndexes <- which(enhExpData[,i] > 6 & DNAMethData[,i] > 60)
	res <- cor.test(enhExpData[matchIndexes,i],DNAMethData[matchIndexes,i],method="spearman")
	corvalues <- c(corvalues,as.numeric(res$estimate))
	pvalues <- c(pvalues,res$p.value)
}
statData_DNAMeth <- cbind(rep("WGBS",ncol(DNAMethData)),colnames(DNAMethData),corvalues,pvalues)

# enhExpData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_XW/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
# rownames(enhExpData) <- enhExpData[,1]
# enhExpData[,1] <- NULL
# H3K9me3Data <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/htseqcountfile_GSR_H3K9me3/enhancer_counts.txt",sep="\t",header=TRUE,row.names=1,stringsAsFactors=FALSE)
# DNAMethData <- read.table(file="/media/yuhua/yuhua_projects/enhProj/GSRData/WGBS_GSR/deepTools/enhancer_DNAMeth_Signal.tab",sep=" ",header=TRUE,stringsAsFactors=FALSE)
# rownames(DNAMethData) <- H3K9me3Data[1:(nrow(H3K9me3Data)-5),1]
# colnames(DNAMethData) <- c("E2C","EpiE65","ExeE65","ICM","X2cell","X4cell","X8cell","morula","TE","Zygote")
# DNAMethData <- DNAMethData[,seq(2,ncol(DNAMethData))] 
# DNAMethMatchRowIndexes <- match(rownames(DNAMethData),rownames(enhExpData))
# DNAMethMatchColIndexes <- match(colnames(enhExpData),colnames(DNAMethData))
# enhExpData <- enhExpData[DNAMethMatchRowIndexes,]
# DNAMethData <- DNAMethData[,DNAMethMatchColIndexes[which(!is.na(DNAMethMatchColIndexes))]]
# enhExpData <- enhExpData[,which(!is.na(DNAMethMatchColIndexes))]
# res <- cor.test(enhExpData[,"E2C"],DNAMethData[,"E2C"],method="spearman")
# statData_DNAMeth <- rbind(statData_DNAMeth,c("WGBS","E2C",as.numeric(res$estimate),res$p.value))
# res <- cor.test(enhExpData[,"Zygote"],DNAMethData[,"Zygote"],method="spearman")
# statData_DNAMeth <- rbind(statData_DNAMeth,c("WGBS","Zygote",as.numeric(res$estimate),res$p.value))

statData <- as.data.frame(rbind(statData_ATAC,statData_DNase,statData_H3K27ac,statData_H3K9me3,statData_H3K27me3,statData_DNAMeth))
colnames(statData) <- c("epiName","stageName","corValue","pValue")
statData$corValue <- as.numeric(statData$corValue)
statData$pValue <- as.numeric(statData$pValue)
statData$pValue <- -log10(p.adjust(statData$pValue)+1e-200)
statData$epiName <- factor(statData$epiName,levels=c("ATAC","DNase","H3K27ac","H3K9me3","H3K27me3","WGBS"))
statData$stageName <- factor(statData$stageName,levels=c("MIIOocyte","E2C","X2cell", "X4cell", "X8cell","morula","ICM","TE","EpiE65","ExeE65"))

library(ggplot2)
pdf(file="/media/yuhua/yuhua_projects/enhProj/ENHData/EnhancerExprAndEpiSignalCorr.pdf",width=6,height=3)
p <- ggplot(statData, aes(x=stageName, y=epiName, size=pValue, color=corValue)) + geom_point() + scale_color_gradient(low="blue", high="yellow") + xlab("") + ylab("") + ggtitle("")
p <- p + theme(line=element_line(colour = "black",linetype=1), rect=element_rect(linetype=1), axis.line = element_line(colour = "black"),axis.title.x=element_text(size=14), axis.title.y=element_text(size=14),axis.text.x=element_text(size=11),axis.text.y=element_text(size=11),legend.position="none") + theme(axis.text.x = element_text(vjust = 0.6, angle = 45))
p <- p + theme_set(theme_bw())
print(p)
dev.off()
