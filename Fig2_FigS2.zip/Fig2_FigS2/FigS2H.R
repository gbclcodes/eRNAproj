tf.enh.motif.pairs.gsr <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/GSR/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
tf.enh.motif.pairs.gsr <- tf.enh.motif.pairs.gsr[grep("X2cell",tf.enh.motif.pairs.gsr[,4]),]
gsr.top10 <- sort(table(tf.enh.motif.pairs.gsr[,5]),decreasing=TRUE)[1:10]

tf.enh.motif.pairs.xw <- read.table(file="/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/XW/mememotiffile/TF_enhancer_network_final.txt",header=FALSE,stringsAsFactors=FALSE)
tf.enh.motif.pairs.xw <- tf.enh.motif.pairs.xw[grep("E2C|L2C",tf.enh.motif.pairs.xw[,4]),]
xw.top10 <- sort(table(tf.enh.motif.pairs.xw[,5]),decreasing=TRUE)[1:10]

num <- c(as.numeric(gsr.top10))
pos <- paste("C",seq(1,10))

df <- as.data.frame(cbind(num,pos))
colnames(df) <- c("num","pos")
df$pos <- factor(pos,levels=paste("C",seq(1,10)))
df$num <- as.numeric(num)


library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/top10TF2cellGSR.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=pos, y=num, fill=pos)) + geom_bar(stat="identity",position=position_dodge(),width=0.6) + scale_fill_manual(values = q4[c(rep(1,10))])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()

num <- c(as.numeric(xw.top10))
pos <- paste("C",seq(1,10))

df <- as.data.frame(cbind(num,pos))
colnames(df) <- c("num","pos")
df$pos <- factor(pos,levels=paste("C",seq(1,10)))
df$num <- as.numeric(num)


library(ggplot2)
library(RColorBrewer)
q4 = brewer.pal(4,'Set1')
pdf("/media/yuhua/yuhua_projects/enhProj/ENHData/enh_stage_group_files/top10TF2cellXW.pdf",width=6,height=5)
p <- ggplot(data=df, aes(x=pos, y=num, fill=pos)) + geom_bar(stat="identity",position=position_dodge(),width=0.6) + scale_fill_manual(values = q4[c(rep(1,10))])
p <- p + theme(panel.grid.minor.x=element_blank(), panel.grid.major.x=element_blank()) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black")) 
p <- p
print(p)
dev.off()